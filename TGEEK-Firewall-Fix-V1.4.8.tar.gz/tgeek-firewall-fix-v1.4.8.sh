#!/bin/sh
# TGEEK Firewall Fix V1.4.8 (2026-11-26) - Stable Guard / 特征库保护与 QUIC 独立运行
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
P=/usr/share/tgeek-firewall-fix
R=/usr/libexec/tgeek-rrd-guard
S=/usr/libexec/tgeek-smart-guard
I=/etc/init.d/tgeek-firewall-guard
C=$BASE/smart.conf
A=${1:-install}
log(){ echo "[TGEEK V1.4.8] $*"; }
fail(){ log "ERROR: $*" >&2; exit 1; }
[ "$A" != version ] || { echo 'TGEEK Firewall Fix V1.4.8'; exit 0; }
[ "$(id -u)" = 0 ] || fail 'root required'
W=$(mktemp -d /tmp/tgeek-v141.XXXXXX)
trap 'rm -rf "$W"' EXIT
trap 'exit 1' HUP INT TERM
cat > "$W/core" <<'TGEEK_V145_CORE'
#!/bin/sh
# TGEEK Firewall Fix V1.4.8 (2026-11-26)
# Retain V1.3 state paths and table names for safe in-place upgrades.
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
SELF=/usr/libexec/tgeek-time-guard
INIT=/etc/init.d/tgeek-time-guard
OLD=/etc/nftables.d/90-tgeek-time-guard.nft
INC=tgeek_time_guard_v13
log(){ echo "[TGEEK V1.4.8] $*"; }
fail(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Run as root'
mkdir -p "$BASE" /usr/libexec
ACTION=${1:-install}
MANAGED=/usr/share/tgeek-firewall-fix
CLI=/usr/bin/tgeek-firewall-fix
case "$ACTION" in
 version) echo 'TGEEK Firewall Fix V1.4.8'; exit 0;;
 oaf-status)
    echo '===== OAF ====='
    if [ -d /proc/sys/oaf ]; then
        for k in version enable lan_ifname tcp_rst test_mode user_mode work_mode; do
            [ ! -r /proc/sys/oaf/$k ] || { printf '%s=' "$k"; cat /proc/sys/oaf/$k; }
        done
        uci -q show appfilter.time || :
        uci -q show appfilter.global || :
        ubus -v list appfilter || :
    else echo 'OAF driver not loaded'; fi
    echo '===== FW4 forward ====='; nft list chain inet fw4 forward
    echo '===== Nikki hooks ====='; nft list table inet nikki 2>/dev/null | grep -E 'hook|tproxy|redirect' || :
    echo 'OAF application classification is independent of Time Guard; test the specific app.'
    exit 0;;
 verify) fw4 check; [ -x "$SELF" ] || fail 'Time Guard not installed'; "$SELF" preview; "$SELF" status; "$INIT" enabled || fail 'Boot service disabled'; "$INIT" status; exit $?;;
 install-all) sh "$0" install; sh "$0" compat-install; exit $?;;
esac
W=$(mktemp -d /tmp/tgeek-v13.XXXXXX)
trap 'rm -rf "$W"' EXIT
trap 'exit 1' HUP INT TERM
cat > "$W/guard" <<'TGEEK_TIME_MODULE'
#!/bin/sh
# TGEEK time guard: runtime FW4 rules are authoritative.
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
TABLE=tgeek_time_guard_v13
SELF=/usr/libexec/tgeek-time-guard
INIT=/etc/init.d/tgeek-time-guard
INC=tgeek_time_guard_v13
OLD=/etc/nftables.d/90-tgeek-time-guard.nft
LOCK=/tmp/tgeek-time-guard.lock
log(){ echo "[TGEEK TIME] $*"; }
fail(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'root required'
for c in nft uci ubus jsonfilter ip awk sed cmp flock; do command -v "$c" >/dev/null || fail "missing $c"; done
mkdir -p "$BASE"
work(){ W=$(mktemp -d /tmp/tgeek-time.XXXXXX); trap 'rm -rf "$W"' EXIT; trap 'exit 1' INT TERM HUP; }
lock(){ exec 9>"$LOCK"; flock -n 9 || exit 75; work; }
# Capture only supported timed MAC WAN-deny rules. Do not reinterpret arbitrary rules.
render(){
  LAN=$(ubus call network.interface.lan status | jsonfilter -e '@.l3_device')
  case "$LAN" in ''|*[!a-zA-Z0-9_.:-]*) fail 'LAN device unavailable or unsupported';; esac
  nft list chain inet fw4 forward > "$W/forward" || return 1
  nft list chain inet fw4 forward_lan > "$W/forward_lan" || return 1
  nft list chain inet fw4 reject_to_wan > "$W/reject" || return 1
  # Extract the actual destination device match from the FW4 zone chain.
  WAN=$(awk '/^[ \t]*oifname .*jump handle_reject/ {s=$0; sub(/^[ \t]*oifname /,"",s); sub(/ counter packets [0-9]+ bytes [0-9]+.*/,"",s); sub(/ jump handle_reject.*/,"",s); print s}' "$W/reject")
  [ -n "$WAN" ] || fail 'WAN device match not found'
  # Flatten simple quoted interface names or a quoted set, validate before reuse.
  printf '%s\n' "$WAN" | tr '{},' '   ' | tr ' ' '\n' | sed '/^$/d;s/^"//;s/"$//' | sort -u > "$W/wan"
  [ -s "$W/wan" ] || fail 'No WAN devices'
  if grep -Eq '[^a-zA-Z0-9_.:+-]' "$W/wan"; then fail 'Unsupported WAN device expression'; fi
  cp "$W/wan" "$W/route"
  if ip link show dev nikki >/dev/null 2>&1; then echo nikki >> "$W/route"; fi
  sort -u "$W/route" > "$W/route.sorted"
  ROUTE=$(awk 'BEGIN{printf "{ "} {if(NR>1)printf ", ";printf "\"%s\"",$0} END{print " }"}' "$W/route.sorted")
  # Only copy literal MAC + time/day, optional simple family/protocol.
  # Unknown match conditions are reported, never silently broadened.
  awk -v skip="$W/skipped" -v lan="$LAN" '
  /meta (hour|day)/ && /jump (reject|drop)_to_wan/ {
    original=$0; s=$0; sub(/^[ \t]+/,"",s); sub(/ counter packets [0-9]+ bytes [0-9]+.*/,"",s);
    sub(/ jump (reject|drop)_to_wan.*/,"",s);
    if (s !~ /ether saddr / || s !~ /meta hour /) {print original >>skip;next}
    family=""; proto="";
    if (s ~ /^iifname /) {prefix="iifname \"" lan "\" "; if(index(s,prefix)!=1){print original >>skip;next}; s=substr(s,length(prefix)+1)}
    if (s ~ /^meta nfproto (ipv4|ipv6) /) {split(s,a," ");family=a[3]; sub(/^meta nfproto (ipv4|ipv6) /,"",s)}
    if (s ~ /^meta l4proto (tcp|udp|ip) /) {split(s,a," ");proto=a[3];sub(/^meta l4proto (tcp|udp|ip) /,"",s)}
    if (s !~ /^ether saddr /) {print original >>skip;next}
    sub(/^ether saddr /,"",s); mac=s;sub(/ .*/,"",mac);sub(/^[^ ]+ /,"",s)
    if (mac !~ /^[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]$/) {print original >>skip;next}
    if (s !~ /^meta hour "[0-9][0-9]:[0-9][0-9](:[0-9][0-9])?"-"[0-9][0-9]:[0-9][0-9](:[0-9][0-9])?"( meta day ("[A-Za-z]+"|\{ "[A-Za-z]+"(, "[A-Za-z]+")* \}))?$/) {print original >>skip;next}
    if (proto=="ip") {print "WARNING: meta l4proto ip (protocol 0, not IPv4): " original >>skip;next}
    print tolower(mac) "|" family "|" proto "|" s
  }' "$W/forward" "$W/forward_lan" > "$W/rules.raw" || return 1
  sort -u "$W/rules.raw" > "$W/rules"
  if [ -s "$W/skipped" ] && [ "${1:-}" = preview ]; then cat "$W/skipped" >&2; fi
  ip -4 neigh show dev "$LAN" > "$W/neigh4" || return 1
  ip -6 neigh show dev "$LAN" > "$W/neigh6" || return 1
  : > "$W/pre"; : > "$W/fwd"
  while IFS='|' read -r mac family proto schedule; do
    [ -n "$mac" ] || continue
    fam=''; pr=''; [ -z "$family" ] || fam="meta nfproto $family "; [ -z "$proto" ] || pr="meta l4proto $proto "
    printf '        iifname "%s" %s%sether saddr %s fib daddr oifname %s %s counter drop\n' "$LAN" "$fam" "$pr" "$mac" "$ROUTE" "$schedule" >> "$W/pre"
    printf '        iifname "%s" oifname %s %s%sether saddr %s %s counter drop\n' "$LAN" "$ROUTE" "$fam" "$pr" "$mac" "$schedule" >> "$W/fwd"
    for v in 4 6; do
      [ "$v" != 4 ] || [ "$family" != ipv6 ] || continue
      [ "$v" != 6 ] || [ "$family" != ipv4 ] || continue
      p=ip; [ "$v" = 4 ] || p=ip6
      awk -v m="$mac" 'tolower($0) ~ ("lladdr " m " ") && $0 !~ /FAILED|INCOMPLETE/ {print $1}' "$W/neigh$v" | sort -u > "$W/addresses"
      while IFS= read -r addr; do
        [ -n "$addr" ] || continue
        case "$addr" in *[!0-9a-fA-F:.]*) continue;; esac
        # Link-local IPv6 is not WAN traffic.
        case "$addr" in fe80:*|FE80:*) continue;; esac
        printf '        iifname %s oifname "%s" %s%s daddr %s %s counter drop\n' "$ROUTE" "$LAN" "$pr" "$p" "$addr" "$schedule" >> "$W/fwd"
      done < "$W/addresses"
    done
  done < "$W/rules"
  {
    echo "table inet $TABLE {"
    echo '    chain prerouting { type filter hook prerouting priority -160; policy accept;'
    cat "$W/pre"; echo '    }'
    echo '    chain forward { type filter hook forward priority -10; policy accept;'
    cat "$W/fwd"; echo '    }'
    echo '}'
  } > "$W/table"
}
apply(){
  for opt in flow_offloading flow_offloading_hw; do
    [ "$(uci -q get firewall.@defaults[0].$opt || :)" != 1 ] || fail "Disable $opt; guard may be bypassed"
  done
  nft list flowtables > "$W/flowtables" || return 1
  if awk '/^table /{own=($3=="tgeek_smart_flow_v141")} /flowtable / && !own {bad=1} END{exit !bad}' "$W/flowtables"; then fail "Active flowtable: disable offloading"; fi
  render || return 1
  # Preserve counters when nothing has changed. Runtime table may have disappeared after flush.
  if [ -s "$W/skipped" ]; then
    cmp -s "$W/skipped" /tmp/tgeek-time-guard.skipped || cp "$W/skipped" /tmp/tgeek-time-guard.skipped
  else rm -f /tmp/tgeek-time-guard.skipped; fi
  if [ -f /tmp/tgeek-time-guard.applied ] && cmp -s "$W/table" /tmp/tgeek-time-guard.applied && nft list table inet "$TABLE" >/dev/null 2>&1; then return 0; fi
  : > "$W/transaction"
  if nft list table inet "$TABLE" >/dev/null 2>&1; then echo "delete table inet $TABLE" >> "$W/transaction"; fi
  cat "$W/table" >> "$W/transaction"
  nft -c -f "$W/transaction" || return 1
  nft -f "$W/transaction" || return 1
  cp "$W/table" /tmp/tgeek-time-guard.applied
  cp "$W/rules" /tmp/tgeek-time-guard.active-rules
  log "Applied $(wc -l < "$W/rules") timed MAC rules (IPv4/IPv6 where family permits)."
}
case "${1:-status}" in
 preview) lock; render preview; : > "$W/check"; if nft list table inet "$TABLE" >/dev/null 2>&1; then echo "delete table inet $TABLE" >> "$W/check"; fi; cat "$W/table" >> "$W/check"; nft -c -f "$W/check"; cat "$W/rules"; cat "$W/table"; [ ! -s "$W/skipped" ] || log 'WARNING: unsupported rules listed above';;
 sync) lock; apply;;
 loop) while :; do if "$SELF" sync >/tmp/tgeek-time-guard.last 2>&1; then rm -f /tmp/tgeek-time-guard.error; else rc=$?; [ "$rc" = 75 ] || cp /tmp/tgeek-time-guard.last /tmp/tgeek-time-guard.error; fi; sleep 15; done;;
 status) nft list table inet "$TABLE"; [ ! -f /tmp/tgeek-time-guard.error ] || { cat /tmp/tgeek-time-guard.error >&2; exit 1; }; [ ! -f /tmp/tgeek-time-guard.skipped ] || cat /tmp/tgeek-time-guard.skipped; [ ! -f /tmp/tgeek-time-guard.last ] || cat /tmp/tgeek-time-guard.last;;
 remove-runtime) lock; nft delete table inet "$TABLE" 2>/dev/null || :; rm -f /tmp/tgeek-time-guard.applied;;
 *) fail 'preview | sync | loop | status | remove-runtime';;
esac
TGEEK_TIME_MODULE
cat > "$W/compat" <<'TGEEK_COMPAT_MODULE'
#!/bin/sh
# TGEEK Firewall Fix V1.3 - optional Docker and wrtbwmon modules
set -u
umask 077
BASE=/root/tgeek-firewall-fix-v1.3
log(){ printf '[TGEEK] %s\n' "$*"; }
die(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || die 'Run as root'
command -v fw4 >/dev/null || die 'firewall4 missing'
command -v uci >/dev/null || die 'uci missing'
ACTION=${1:-install}
case "$ACTION" in install|fix|status|check|rollback) ;; *) die 'Usage: install | status | rollback';; esac
mkdir -p "$BASE" || exit 1
LOCK=/tmp/tgeek-firewall-fix-v1.3.lock
mkdir "$LOCK" 2>/dev/null || die 'Another execution active'
trap 'rmdir "$LOCK" 2>/dev/null || :' EXIT
trap 'exit 1' HUP INT TERM
cat > "$BASE/rrd.sh" <<'TGEEK_RRD_MODULE'
#!/bin/sh
# TGEEK firewall compatibility cleanup v1.1
set -eu
BASE=/root/tgeek-firewall-fix-v1.3/rrd-backups
ACTION=${1:-fix}
umask 077
log() { printf '[TGEEK] %s\n' "$*"; }
fail() { log "ERROR: $*"; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Run as root'
mkdir -p "$BASE"
case "$ACTION" in
install|fix) ACTION=fix;;
status|check) ACTION=status;;
rollback) ;;
*) fail 'Usage: sh script [install|fix|status|rollback]';;
esac
for c in iptables-save ip6tables-save fw4; do command -v "$c" >/dev/null || fail "Missing $c"; done
report() {
    V4=$(iptables-save) || fail 'Cannot read IPv4 rules'
    V6=$(ip6tables-save) || fail 'Cannot read IPv6 rules'
    printf '%s\n' "$V4" "$V6" | awk '/^-A / {n[$2]++} END {for (c in n) print n[c],c}'
    if printf '%s\n' "$V4" "$V6" | grep -q '^-A '; then
        log 'WARN: iptables rules remain; inspect chain counts above.'
    else
        log 'PASS: No IPv4/IPv6 iptables append rules remain.'
    fi
    if command -v uci >/dev/null; then
        uci -q show dockerd.globals | grep -E 'ip6?tables=' || :
    fi
    fw4 check || fail 'Firewall validation failed'
}
if [ "$ACTION" = status ]; then report; exit 0; fi
if [ ! -x /etc/init.d/wrtbwmon ]; then
    [ "$ACTION" != rollback ] || fail 'wrtbwmon absent; service rollback not applicable'
    log 'SKIP: wrtbwmon not installed; no service or rules changed.'
    report
    if printf '%s\n' "$V4" "$V6" | grep -q '^-A '; then
        log 'No automatic deletion: rule owner must be identified on this device.'
        exit 2
    fi
    exit 0
fi
case "$ACTION" in
rollback)
    [ -f "$BASE/latest" ] || fail 'No backup found'
    B=$(cat "$BASE/latest")
    [ -d "$B" ] || fail 'Backup missing'
    if [ "$(cat "$B/enabled")" = 1 ]; then /etc/init.d/wrtbwmon enable; else /etc/init.d/wrtbwmon disable; fi
    for f in usage.db usage.46.db usage.6.db; do if [ -f "$B/$f" ] && [ ! -e "/tmp/$f" ]; then cp -p "$B/$f" "/tmp/$f"; fi; done
    if [ "$(cat "$B/running")" = 1 ]; then /etc/init.d/wrtbwmon start; fi
    log 'Original wrtbwmon service state restored; live counters may restart.'
    exit 0;;
fix) ;;
*) fail 'Invalid action';;
esac
for c in iptables ip6tables iptables-save ip6tables-save fw4; do command -v "$c" >/dev/null || fail "Missing $c"; done
fw4 check || fail 'Existing firewall configuration invalid'
B="$BASE/$(date +%Y%m%d-%H%M%S)-$$"
mkdir "$B"
iptables-save -c > "$B/iptables.txt"
ip6tables-save -c > "$B/ip6tables.txt"
for f in /tmp/usage.db /tmp/usage.46.db /tmp/usage.6.db /etc/wrtbwmon.user /etc/config/wrtbwmon; do [ ! -f "$f" ] || cp -p "$f" "$B/"; done
if /etc/init.d/wrtbwmon enabled; then echo 1 > "$B/enabled"; else echo 0 > "$B/enabled"; fi
if pidof wrtbwmon >/dev/null 2>&1 || ps w | grep -q '[/]usr/sbin/wrtbwmon -'; then echo 1 > "$B/running"; else echo 0 > "$B/running"; fi
# Preserve the original active-state backup across repeated runs.
if [ ! -f "$BASE/latest" ] || [ "$(cat "$B/running")" = 1 ] || [ "$(cat "$B/enabled")" = 1 ]; then printf '%s\n' "$B" > "$BASE/latest"; fi
log "Backup: $B"
/etc/init.d/wrtbwmon stop || fail 'Could not stop wrtbwmon'
/etc/init.d/wrtbwmon disable || fail 'Could not disable wrtbwmon'
sleep 2
if pidof wrtbwmon >/dev/null 2>&1 || ps w | grep -q '[/]usr/sbin/wrtbwmon -'; then fail 'wrtbwmon still running; no manual rules removed'; fi
for IPT in iptables ip6tables; do
    for CHAIN in INPUT FORWARD OUTPUT; do
        TARGET="RRDIPT_$CHAIN"
        while "$IPT" -w 5 -t mangle -C "$CHAIN" -j "$TARGET" 2>/dev/null; do
            "$IPT" -w 5 -t mangle -D "$CHAIN" -j "$TARGET" || fail "Cannot detach $TARGET"
        done
        if "$IPT" -w 5 -t mangle -S "$TARGET" >/dev/null 2>&1; then
            "$IPT" -w 5 -t mangle -F "$TARGET" || fail "Cannot flush $TARGET"
            "$IPT" -w 5 -t mangle -X "$TARGET" || fail "Cannot delete $TARGET"
        fi
    done
done
iptables-save > "$B/after-v4.txt"
ip6tables-save > "$B/after-v6.txt"
if grep -q RRDIPT "$B/after-v4.txt" "$B/after-v6.txt"; then fail 'RRDIPT rules remain'; fi
fw4 check || fail 'Firewall validation failed'
if grep -h '^-A ' "$B/after-v4.txt" "$B/after-v6.txt"; then log 'RRDIPT removed, but other iptables rules remain; LuCI warning may persist.'; else log 'PASS: No IPv4/IPv6 iptables append rules remain.'; fi
if command -v docker >/dev/null; then docker ps || log 'Docker status unavailable'; fi
log 'Done. Refresh LuCI. Old traffic monitor is disabled; no router or Docker restart.'
log "Rollback: sh $0 rollback"
if grep -q '^-A ' "$B/after-v4.txt" "$B/after-v6.txt"; then exit 2; fi

TGEEK_RRD_MODULE
cat > "$BASE/docker.sh" <<'TGEEK_DOCKER_MODULE'
#!/bin/sh
# TGEEK Firewall Fix 1.2 - OpenWrt fw4 / Docker host-only migration
set -eu
set -f
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/docker-backups
LOCK=/tmp/tgeek-firewall-fix-v1.2.lock
INIT=/etc/init.d/dockerd
log(){ printf '[TGEEK] %s\n' "$*"; }
die(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || die 'Run as root.'
for c in uci fw4 nft docker iptables ip6tables iptables-save ip6tables-save jsonfilter; do command -v "$c" >/dev/null || die "Missing $c"; done
[ -x "$INIT" ] || die 'dockerd service not found.'
mkdir "$LOCK" 2>/dev/null || die 'Another execution is active (check lock).'
CHANGED=0
B=''
wait_docker(){ i=0; until docker info >/dev/null 2>&1; do i=$((i+1)); [ "$i" -lt 45 ] || return 1; sleep 1; done; }
start_previous(){ while IFS= read -r id; do [ -n "$id" ] || continue; docker start "$id" >/dev/null || return 1; done < "$B/running"; }
restore(){
  log "Restoring $B (firewall and dockerd config; later edits to these files will be overwritten)."
  "$INIT" stop || return 1
  uci -q revert firewall || :; uci -q revert dockerd || :
  cp -p "$B/firewall" /etc/config/firewall || return 1
  cp -p "$B/dockerd" /etc/config/dockerd || return 1
  fw4 check && /etc/init.d/firewall reload || return 1
  "$INIT" start && wait_docker && start_previous || return 1
  log 'Rollback complete.'
}
finish(){ rc=$?; trap - EXIT HUP INT TERM; if [ "$CHANGED" = 1 ]; then log 'Migration failed; attempting rollback.'; restore || log 'ERROR: automatic rollback failed; use backup path above.'; fi; rmdir "$LOCK" 2>/dev/null || :; exit "$rc"; }
trap finish EXIT
trap 'exit 1' HUP INT TERM
status(){
  uci show dockerd.globals | grep -E 'iptables|ip6tables' || :
  if [ -f /tmp/dockerd/daemon.json ]; then for key in iptables ip6tables; do printf '%s=' "$key"; jsonfilter -i /tmp/dockerd/daemon.json -e "@.$key" || :; done; fi
  uci -q show firewall.docker || :
  docker ps -a || :
  for s in iptables-save ip6tables-save; do log "$s rule counts:"; "$s" | awk '/^-A /{n[$2]++} END{for(k in n)print n[k],k}'; done
  fw4 check
}
case "${1:-install}" in
 status) status; exit;;
 rollback) [ -s "$BASE/latest" ] || die 'No backup'; B=$(cat "$BASE/latest"); [ -f "$B/firewall" ] && [ -f "$B/dockerd" ] || die 'Invalid backup'; restore || die 'Rollback failed'; exit;;
 install) ;;
 *) die 'Usage: install | status | rollback';;
esac
# Scope: host/none containers only, standard empty docker0 bridge. No generic port migration.
[ -z "$(uci changes firewall)$(uci changes dockerd)" ] || die 'Commit or revert pending UCI changes first.'
[ -z "$(uci -q get dockerd.globals.alt_config_file || :)" ] || die 'Custom daemon configuration requires manual migration.'
fw4 check || die 'Existing firewall invalid.'
wait_docker || die 'Docker unavailable.'
[ "$(uci -q get firewall.docker.name || :)" = docker ] || die 'Expected existing firewall.docker zone.'
[ "$(docker network inspect -f '{{index .Options "com.docker.network.bridge.name"}}' bridge)" = docker0 ] || die 'Nonstandard default bridge.'
[ "$(docker network inspect -f '{{range .IPAM.Config}}{{.Subnet}}{{end}}' bridge)" = 172.17.0.0/16 ] || die 'Nonstandard subnet.'
[ "$(docker network inspect -f '{{.EnableIPv6}}' bridge)" = false ] || die 'IPv6-enabled bridge requires separate design.'
for n in $(docker network ls --format '{{.Name}}'); do case "$n" in bridge|host|none) ;; *) die "Custom network $n requires manual migration";; esac; done
for id in $(docker ps -aq); do
  mode=$(docker inspect -f '{{.HostConfig.NetworkMode}}' "$id")
  case "$mode" in host|none) ;; *) die "Container $id uses $mode; migrate its ports and networks first";; esac
done
# Require WAN masquerade and a restrictive WAN policy; do not change WAN settings.
WAN=''; for z in $(uci show firewall | sed -n 's/^firewall\.\([^=]*\)=zone$/\1/p'); do
  if [ "$(uci -q get "firewall.$z.name" || :)" = wan ]; then WAN=$z; fi
done
[ -n "$WAN" ] || die 'WAN zone absent.'
[ "$(uci -q get "firewall.$WAN.masq" || :)" = 1 ] || die 'WAN masquerade is not enabled.'
case "$(uci -q get "firewall.$WAN.input" || :)" in REJECT|DROP) ;; *) die 'WAN input is not restrictive.';; esac
case "$(uci -q get "firewall.$WAN.forward" || :)" in REJECT|DROP) ;; *) die 'WAN forwarding is not restrictive.';; esac
# Generate a deletion plan for known Docker 27.3 empty-default-bridge rules only.
# Unknown/custom rules mentioning Docker cause a preflight failure, not deletion.
plan(){
 awk '
 /^\*/ {t=substr($0,2)}
 /^:FORWARD DROP/ && t=="filter" {bad=1; print "FORWARD policy DROP requires review" > "/dev/stderr"}
 /^-A / {
   if ($0 !~ /DOCKER|docker0/ && $0 !~ /172\.17\.0\.0\/16/) next
   ok=0
   if(t=="nat" && ($0=="-A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER" || $0=="-A OUTPUT ! -d 127.0.0.0/8 -m addrtype --dst-type LOCAL -j DOCKER" || $0=="-A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE" || $0=="-A DOCKER -i docker0 -j RETURN")) ok=1
   if(t=="filter" && ($0=="-A FORWARD -j DOCKER-USER" || $0=="-A FORWARD -j DOCKER-ISOLATION-STAGE-1" || $0=="-A FORWARD -o docker0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT" || $0=="-A FORWARD -o docker0 -j DOCKER" || $0=="-A FORWARD -i docker0 ! -o docker0 -j ACCEPT" || $0=="-A FORWARD -i docker0 -o docker0 -j ACCEPT" || $0=="-A DOCKER-ISOLATION-STAGE-1 -i docker0 ! -o docker0 -j DOCKER-ISOLATION-STAGE-2" || $0=="-A DOCKER-ISOLATION-STAGE-1 -j RETURN" || $0=="-A DOCKER-ISOLATION-STAGE-2 -o docker0 -j DROP" || $0=="-A DOCKER-ISOLATION-STAGE-2 -j RETURN" || $0=="-A DOCKER-USER -j RETURN" || $0 ~ /^-A DOCKER-USER -i [a-zA-Z0-9_.:-]+ -o docker0 -j REJECT( --reject-with icmp-port-unreachable)?$/)) ok=1
   if(!ok){bad=1;print "Unrecognized Docker-related rule: " $0 > "/dev/stderr"} else {sub(/^-A /,"-D "); print t, $0}
 }
 END{exit bad?1:0}' "$1" > "$2"
}
mkdir -p "$BASE"
B="$BASE/$(date +%Y%m%d-%H%M%S)-$$"; mkdir "$B"
cp -p /etc/config/firewall "$B/firewall"; cp -p /etc/config/dockerd "$B/dockerd"
docker ps -q > "$B/running"
iptables-save > "$B/iptables"; ip6tables-save > "$B/ip6tables"
nft list ruleset > "$B/nftables"
plan "$B/iptables" "$B/plan" || die 'Unsafe to clean automatically.'
# This device has no Docker IPv6 chains. Refuse unexpected IPv6 Docker rules.
if grep -Eq 'DOCKER|docker0' "$B/ip6tables"; then die 'Unexpected IPv6 Docker rules; manual review required.'; fi
printf '%s\n' "$B" > "$BASE/latest"
log "Backup: $B"
CHANGED=1
# Keep existing Docker network association. Add explicit device binding.
uci -q del_list firewall.docker.device=docker0 || :
uci add_list firewall.docker.device=docker0
# Dedicated prefix for future explicitly named Docker bridges; never match br-lan.
uci -q del_list firewall.docker.device=tgd-+ || :
uci add_list firewall.docker.device=tgd-+
uci set firewall.docker.input=REJECT
uci set firewall.docker.output=ACCEPT
uci set firewall.docker.forward=REJECT
# Permit DNS to router; preserve existing explicit LAN/WAN rules.
uci set firewall.tgeek_docker_dns=rule
uci set firewall.tgeek_docker_dns.name='TGEEK-Docker-DNS'
uci set firewall.tgeek_docker_dns.src=docker
uci set firewall.tgeek_docker_dns.proto='tcp udp'
uci set firewall.tgeek_docker_dns.dest_port=53
uci set firewall.tgeek_docker_dns.target=ACCEPT
uci set firewall.tgeek_docker_wan=forwarding
uci set firewall.tgeek_docker_wan.src=docker
uci set firewall.tgeek_docker_wan.dest=wan
uci commit firewall
fw4 check
/etc/init.d/firewall reload
log 'Restarting Docker; running containers will be restored.'
"$INIT" stop
# Remove only known leftover rules, if Docker did not remove them on stop.
iptables-save > "$B/after-stop"
plan "$B/after-stop" "$B/cleanup" || die 'Unexpected rule after stopping Docker.'
while IFS= read -r line; do [ -n "$line" ] || continue; set -- $line; table=$1; shift; iptables -t "$table" "$@" || die 'Targeted cleanup failed'; done < "$B/cleanup"
for t in filter nat; do
  for c in DOCKER DOCKER-USER DOCKER-ISOLATION-STAGE-1 DOCKER-ISOLATION-STAGE-2; do
    if iptables -t "$t" -S "$c" >/dev/null 2>&1; then iptables -t "$t" -X "$c" || die "Nonempty or referenced chain $t/$c"; fi
  done
done
uci set dockerd.globals.iptables=0
uci set dockerd.globals.ip6tables=0
uci commit dockerd
"$INIT" start
wait_docker || die 'Docker did not restart.'
start_previous || die 'Previous running container could not start.'
for key in iptables ip6tables; do [ "$(jsonfilter -i /tmp/dockerd/daemon.json -e "@.$key")" = false ] || die "Effective $key not false"; done
/etc/init.d/firewall reload
fw4 check
nft list chain inet fw4 forward_docker | grep -q accept_to_wan || die 'Docker WAN forwarding missing.'
iptables-save > "$B/final-ipv4"; ip6tables-save > "$B/final-ipv6"
if grep -Eq 'DOCKER|docker0|172\.17\.0\.0/16' "$B/final-ipv4" "$B/final-ipv6"; then die 'Docker-related rules remain.'; fi
while IFS= read -r id; do [ -z "$id" ] || [ "$(docker inspect -f '{{.State.Running}}' "$id")" = true ] || die "Container $id not running"; done < "$B/running"
CHANGED=0
if grep -q '^-A ' "$B/final-ipv4" "$B/final-ipv6"; then log 'WARN: other iptables rules remain; not modified.'; else log 'PASS: no iptables append rules remain.'; fi
log 'PASS: Docker firewall disabled; fw4 owns default bridge forwarding/NAT.'
log 'For new custom bridges: name them tgd-* or explicitly add device to firewall zone; publish ports via LuCI DNAT or host INPUT rules.'
docker ps

TGEEK_DOCKER_MODULE

report(){
  result=0
  for cmd in iptables-save ip6tables-save; do
    if ! command -v "$cmd" >/dev/null; then log "SKIP: $cmd unavailable; cannot verify this family"; result=2; continue; fi
    out=$("$cmd") || { log "ERROR: $cmd failed"; result=2; continue; }
    if printf '%s\n' "$out" | grep -q '^-A '; then
      log "WARN: $cmd rules remain"; printf '%s\n' "$out" | awk '/^-A /{n[$2]++} END{for(k in n)print n[k],k}'; result=2
    else log "PASS: $cmd has no append rules"; fi
  done
  if command -v docker >/dev/null; then
    uci -q show dockerd.globals | grep -E 'ip6?tables=' || :
    docker ps || result=2
  else log 'SKIP: Docker CLI absent'; fi
  fw4 check || return 1
  return "$result"
}
if [ "$ACTION" = status ] || [ "$ACTION" = check ]; then report; exit $?; fi
if [ "$ACTION" = rollback ]; then
  rc=0
  for module in rrd docker; do
    if [ -f "$BASE/$module.applied" ]; then
      if sh "$BASE/$module.sh" rollback; then rm -f "$BASE/$module.applied"; else rc=1; fi
    fi
  done
  log 'Rollback restores module configuration snapshots; Docker rollback overwrites subsequent firewall edits.'
  exit "$rc"
fi
fw4 check || die 'Existing firewall invalid'
rc=0
if command -v docker >/dev/null && [ -x /etc/init.d/dockerd ]; then
  if [ "$(uci -q get dockerd.globals.iptables)" = 0 ] && [ "$(uci -q get dockerd.globals.ip6tables)" = 0 ] && command -v jsonfilter >/dev/null && [ "$(jsonfilter -i /tmp/dockerd/daemon.json -e '@.iptables' 2>/dev/null)" = false ] && [ "$(jsonfilter -i /tmp/dockerd/daemon.json -e '@.ip6tables' 2>/dev/null)" = false ]; then
    log 'SKIP: Docker automatic firewall already disabled; existing migration not modified.'
  elif [ -f "$BASE/docker.applied" ]; then
    log 'WARN: Docker previously migrated; rollback before a new migration.'; rc=2
  else
    if sh "$BASE/docker.sh" install; then touch "$BASE/docker.applied"; else log 'WARN: Docker migration refused or failed; inspect module output.'; rc=2; fi
  fi
elif command -v docker >/dev/null || [ -x /etc/init.d/dockerd ]; then
  log 'WARN: incomplete Docker installation; no Docker changes.'; rc=2
else log 'SKIP: Docker not installed'; fi
if /usr/libexec/tgeek-rrd-guard fix; then :; else rc=2; fi
report; r=$?
[ "$r" = 0 ] || rc=$r
log "Finished (code $rc). No router reboot. Unknown rules are not removed."
exit "$rc"
TGEEK_COMPAT_MODULE
chmod 755 "$W/guard" "$W/compat"
case "$ACTION" in
 compat-install) sh "$W/compat" install; exit $?;;
 compat-status) sh "$W/compat" status; exit $?;;
 compat-rollback) sh "$W/compat" rollback; exit $?;;
 preview|dry-run) "$W/guard" preview; exit $?;;
 status) [ -x "$SELF" ] || fail 'Time Guard not installed'; "$SELF" status; exit $?;;
 sync) [ -x "$SELF" ] || fail 'Time Guard not installed'; "$SELF" sync; exit $?;;
 install|upgrade|rollback|uninstall) ;;
 *) fail 'install | install-all | upgrade | preview | status | sync | verify | version | oaf-status | rollback | uninstall | compat-install | compat-status | compat-rollback';;
esac
[ -z "$(uci changes firewall)" ] || fail 'Save or revert pending firewall edits in LuCI first'
MLOCK=/tmp/tgeek-v13-install.lock
mkdir "$MLOCK" 2>/dev/null || fail 'Another install active'
trap 'rm -rf "$W"; rmdir "$MLOCK" 2>/dev/null || :' EXIT
if [ "$ACTION" = rollback ] || [ "$ACTION" = uninstall ]; then
    [ -f "$BASE/installed" ] || fail 'No managed installation'
    [ ! -x "$INIT" ] || { "$INIT" stop || :; "$INIT" disable || :; }
    uci -q delete "firewall.$INC" || :
    uci commit firewall
    if [ -f "$BASE/original-legacy.nft" ]; then cp -p "$BASE/original-legacy.nft" "$OLD"; fi
    fw4 check && /etc/init.d/firewall reload || fail 'Rollback reload failed; inspect fw4 check'
    "$SELF" remove-runtime || fail 'Runtime cleanup failed; retry rollback'
    rm -f "$SELF" "$INIT" "$BASE/installed"
    log 'Time Guard removed; original LuCI rules and Docker configuration retained. Compatibility rollback is separate.'
    exit 0
fi
# Do not overwrite unowned files or an unrelated include.
if [ ! -f "$BASE/installed" ]; then
    [ ! -e "$SELF" ] && [ ! -e "$INIT" ] || fail 'Existing unowned Time Guard files'
    [ -z "$(uci -q get firewall.$INC || :)" ] || fail 'Include name already exists'
fi
fw4 check || fail 'Existing firewall invalid'
"$W/guard" preview > "$W/preview" || fail 'Cannot render rules'
cat "$W/preview"
# Refuse active flow offload: established offloaded flows can skip hooks.
for opt in flow_offloading flow_offloading_hw; do
    [ "$(uci -q get firewall.@defaults[0].$opt || :)" != 1 ] || fail "Disable $opt in LuCI before installing"
done
if nft list flowtables | grep -q 'flowtable '; then fail 'Active flowtable detected'; fi
B="$BASE/backup-$(date +%Y%m%d-%H%M%S)-$$"
mkdir "$B"
cp -p /etc/config/firewall "$B/firewall"
for f in "$SELF" "$INIT" "$OLD"; do [ ! -f "$f" ] || cp -p "$f" "$B/$(basename "$f")"; done
if [ -f "$OLD" ]; then
    # Only replace the earlier TGEEK sample, not other custom firewall content.
    awk 'NF && $0 !~ /^[ \t]*#/ {if ($0 ~ /^chain tgeek_time_forward \{/ || $0 ~ /^[ \t]*type filter hook forward priority -10; policy accept;/ || $0 ~ /^[ \t]*iifname .*meta hour .*counter drop[ \t]*$/ || $0 ~ /^[ \t]*}[ \t]*$/) next; bad=1} END{exit bad}' "$OLD" || fail 'Legacy file contains unknown rules; inspect manually'
    grep -q '^chain tgeek_time_forward {' "$OLD" || fail 'Legacy file not recognized'
fi
rollback_install(){
    log "Install failed; restoring $B"
    [ ! -x "$INIT" ] || { "$INIT" stop || :; "$INIT" disable || :; }
    uci -q revert firewall || :
    cp -p "$B/firewall" /etc/config/firewall
    if [ -f "$B/$(basename "$OLD")" ]; then cp -p "$B/$(basename "$OLD")" "$OLD"; fi
    if [ -f "$B/$(basename "$SELF")" ]; then cp -p "$B/$(basename "$SELF")" "$SELF"; else rm -f "$SELF"; fi
    if [ -f "$B/$(basename "$INIT")" ]; then cp -p "$B/$(basename "$INIT")" "$INIT"; else rm -f "$INIT"; fi
    fw4 check && /etc/init.d/firewall reload || log 'ERROR: restore reload failed'
    if [ -f "$BASE/installed" ]; then "$INIT" enable && "$INIT" start || :; else nft delete table inet tgeek_time_guard_v13 2>/dev/null || :; fi
}
# Every failure after this point triggers rollback, including interrupted install.
DONE=0
trap 'r=$?; trap - EXIT; if [ "$DONE" = 0 ]; then rollback_install; fi; rm -rf "$W"; rmdir "$MLOCK" 2>/dev/null || :; exit "$r"' EXIT
[ ! -x "$INIT" ] || "$INIT" stop
cp "$W/guard" "$SELF"; chmod 755 "$SELF"
cat > "$INIT" <<'TGEEK_PROCD'
#!/bin/sh /etc/rc.common
START=96
STOP=10
USE_PROCD=1
start_service(){
    procd_open_instance
    procd_set_param command /usr/libexec/tgeek-time-guard loop
    procd_set_param respawn 3600 5 0
    procd_close_instance
}
TGEEK_PROCD
chmod 755 "$INIT"
"$SELF" sync
uci set "firewall.$INC=include"
uci set "firewall.$INC.type=script"
uci set "firewall.$INC.path=$SELF"
# fw4 invokes script with no arguments, so use dedicated entry wrapper instead.
cat > "$BASE/reload.sh" <<'TGEEK_RELOAD'
#!/bin/sh
nft delete table inet tgeek_smart_flow_v141 2>/dev/null || :
/usr/libexec/tgeek-time-guard sync || logger -t tgeek-time-guard 'Reload sync deferred to service'
TGEEK_RELOAD
chmod 755 "$BASE/reload.sh"
uci set "firewall.$INC.path=$BASE/reload.sh"
uci set "firewall.$INC.fw4_compatible=1"
uci commit firewall
if [ -f "$OLD" ]; then
    [ -f "$BASE/original-legacy.nft" ] || cp -p "$OLD" "$BASE/original-legacy.nft"
    rm -f "$OLD"
fi
fw4 check
/etc/init.d/firewall reload
"$SELF" sync
"$INIT" enable
"$INIT" start
rm -f /tmp/tgeek-time-guard.error
# Remove only previous named test table after successful replacement.
if nft list table inet tgeek_time_guard >/dev/null 2>&1; then nft delete table inet tgeek_time_guard; fi
touch "$BASE/installed"
DONE=1
if [ ! -e "$CLI" ] || grep -q 'TGEEK-FIREWALL-FIX-MANAGED' "$CLI"; then
    cat > "$CLI" <<'TGEEK_CLI'
#!/bin/sh
# TGEEK-FIREWALL-FIX-MANAGED
exec /usr/share/tgeek-firewall-fix/install.sh "$@"
TGEEK_CLI
    chmod 755 "$CLI"
else log "WARN: $CLI already exists; use $MANAGED/install.sh"; fi
log "PASS: Time Guard installed. Backup: $B"
"$SELF" status

TGEEK_V145_CORE
cat > "$W/smart" <<'TGEEK_V145_SMART'
#!/bin/sh
# TGEEK Smart Offload and OAF Connection Guard V1.4.8
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
CONF=$BASE/smart.conf
STATE=/tmp/tgeek-smart-v141
TABLE=tgeek_smart_flow_v141
CUT=tgeek_oaf_cut_v141
log(){ echo "[TGEEK SMART] $*"; case "$*" in "Connection Guard triggered"*|"Software flowtable updated"*|"Cleanup time budget"*) logger -t tgeek-smart "$*" 2>/dev/null || :;; esac; }
remove(){ nft delete table inet "$1" 2>/dev/null || :; }
get(){ uci -q get "$1" || :; }
validmac(){ awk 'tolower($0) ~ /^[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]$/ {print tolower($0)}' | sort -u; }
listmac(){ awk -F= -v type="$1" '$2==type {s[$1]=1;next} /\.mac=/ {k=$1;sub(/\.mac$/,"",k);if(s[k]){v=$2;gsub(/\047/,"",v);print v}}' "$W/oaf" | validmac; }
minus(){ awk 'FILENAME==ARGV[1]{a[$0]=1;next}!a[$0]' "$1" "$2"; }
joinset(){ awk 'BEGIN{printf "{ "} {if(NR>1)printf ", ";printf "%s",$0} END{print " }"}' "$1"; }
qset(){ awk 'BEGIN{printf "{ "} {if(NR>1)printf ", ";printf "\"%s\"",$0} END{print " }"}' "$1"; }
readconf(){ MODE=off; CONNECTION=1; [ ! -f "$CONF" ] || { MODE=$(sed -n 's/^mode=//p' "$CONF"); CONNECTION=$(sed -n 's/^connection=//p' "$CONF"); }; case "$MODE" in smart|off) ;; *) return 1;; esac; case "$CONNECTION" in 0|1) ;; *) return 1;; esac; }
setup(){ mkdir -p "$STATE"; exec 8>"$STATE/lock"; flock -n 8 || exit 75; W=$(mktemp -d /tmp/tgeek-smart.XXXXXX); trap 'rm -rf "$W"' EXIT; trap 'exit 1' HUP INT TERM; mkdir "$W/uci"; }
collect(){
  LAN=$(ubus call network.interface.lan status | jsonfilter -e '@.l3_device') || return 1
  case "$LAN" in ''|*[!a-zA-Z0-9_.:-]*) return 1;; esac
  ip link show dev "$LAN" >/dev/null 2>&1 || return 1
  nft list chain inet fw4 reject_to_wan > "$W/reject" || return 1
  awk '/^[ \t]*oifname .*jump handle_reject/ {s=$0; sub(/^[ \t]*oifname /,"",s); sub(/ counter packets [0-9]+ bytes [0-9]+.*/,"",s); sub(/ jump handle_reject.*/,"",s); print s}' "$W/reject" | tr '{},' '   ' | tr ' ' '\n' | sed '/^$/d;s/^"//;s/"$//' | sort -u > "$W/wan"
  [ -s "$W/wan" ] || return 1
  if grep -Eq '[^a-zA-Z0-9_.:+-]' "$W/wan"; then return 1; fi
  while read -r dev; do ip link show dev "$dev" >/dev/null 2>&1 || return 1; done < "$W/wan"
  cp "$W/wan" "$W/routes"; if ip link show dev nikki >/dev/null 2>&1; then echo nikki >> "$W/routes"; fi
  WAN=$(qset "$W/wan"); ROUTES=$(qset "$W/routes")
  { echo "$LAN"; cat "$W/wan"; } | sort -u > "$W/devices"
  ip -4 neigh show dev "$LAN" > "$W/n4" || return 1
  ip -6 neigh show dev "$LAN" > "$W/n6" || return 1
  awk '$0 !~ /FAILED|INCOMPLETE/ {for(i=1;i<NF;i++)if($i=="lladdr")print tolower($(i+1))}' "$W/n4" "$W/n6" | validmac > "$W/known"
  # Capture committed OAF config, no sourcing arbitrary content.
  : > "$W/oaf"; : > "$W/targets"; : > "$W/exclude"; : > "$W/white"; : > "$W/policy"
  GLOBAL=0; ACTIVE=0; SCOPE=none; NATIVE=0; QUIC=0
  if [ -f /etc/config/appfilter ]; then
    uci -q -t "$W/uci" show appfilter > "$W/oaf" || return 1
    GLOBAL=$(sed -n "s/^appfilter.global.enable='\([01]\)'$/\1/p" "$W/oaf")
    QUIC=$(sed -n "s/^appfilter.global.disable_quic='\([01]\)'$/\1/p" "$W/oaf")
    UM=$(sed -n "s/^appfilter.global.user_mode='\([01]\)'$/\1/p" "$W/oaf")
    OLAN=$(sed -n "s/^appfilter.global.lan_ifname='\([^']*\)'$/\1/p" "$W/oaf")
    HNAT=$(sed -n "s/^appfilter.global.disable_hnat='\([01]\)'$/\1/p" "$W/oaf")
    ACTIVE=$(cat /proc/sys/oaf/enable 2>/dev/null || echo unknown)
    RUNTIME_UM=$(cat /proc/sys/oaf/user_mode 2>/dev/null || echo unknown)
    listmac whitelist > "$W/white"; listmac af_user > "$W/selected"
    # A malformed list cannot safely determine whom to disconnect.
    for kind in whitelist af_user; do
      expected=$(awk -F= -v t="$kind" '$2==t{n++}END{print n+0}' "$W/oaf")
      valid=$(awk -F= -v t="$kind" '$2==t{s[$1]=1;next} /\.mac=/{k=$1;sub(/\.mac$/, "", k);if(s[k]){gsub(/\047/,"",$2);if($2 ~ /^[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]$/)n++}} END{print n+0}' "$W/oaf")
      if [ "$expected" != "$valid" ]; then UM=unknown; fi
    done
    if [ "$GLOBAL" = 1 ] || [ "$ACTIVE" = 1 ]; then
      if [ "$OLAN" != "$LAN" ] || { [ "$ACTIVE" = 1 ] && [ "$RUNTIME_UM" != "$UM" ]; } || ! grep -q '^appfilter.rule=rule$' "$W/oaf" || ! grep -q '^appfilter.rule.app_list=' "$W/oaf"; then SCOPE=unknown
      elif [ "$UM" = 1 ]; then SCOPE=selected; minus "$W/white" "$W/selected" > "$W/targets"; cp "$W/targets" "$W/exclude"
      elif [ "$UM" = 0 ]; then SCOPE=all; minus "$W/white" "$W/known" > "$W/targets"
      else SCOPE=unknown; fi
      [ "$HNAT" != 1 ] || NATIVE=1
    elif [ "$GLOBAL" != 0 ] || { [ "$ACTIVE" != 0 ] && [ "$ACTIVE" != unknown ]; }; then SCOPE=unknown; fi
    grep -E '^appfilter\.(rule\.|time\.|global\.work_mode=|global\.user_mode=)' "$W/oaf" | sort > "$W/policy" || :
  elif [ -r /proc/sys/oaf/enable ] && [ "$(cat /proc/sys/oaf/enable)" = 1 ]; then SCOPE=unknown; ACTIVE=1; fi
  # Runtime FW4 timed rules: extract all simple MACs; any ambiguity disables smart.
  nft list table inet fw4 > "$W/fw" || return 1
  awk '/meta (hour|day)/ {print}' "$W/fw" > "$W/timed"
  awk '/meta (hour|day)/ {for(i=1;i<NF;i++)if($i=="ether" && $(i+1)=="saddr"){print $(i+2);break}}' "$W/timed" | validmac > "$W/timedmac"
  # More than one MAC, inverted matches, or rules without literal MAC: fail closed for acceleration.
  if awk '/meta (hour|day)/ {n=0;for(i=1;i<NF;i++)if($i=="ether" && $(i+1)=="saddr" && $(i+2) ~ /^[0-9a-fA-F:]+$/ && length($(i+2))==17)n++;if(n!=1)bad=1} END{exit !bad}' "$W/timed"; then NATIVE=1; fi
  cat "$W/timedmac" >> "$W/exclude"; sort -u "$W/exclude" -o "$W/exclude"
  # All-user / unrecognized OAF or vendor disables acceleration: safe fallback.
  if [ "$SCOPE" = all ] || [ "$SCOPE" = unknown ]; then NATIVE=1; fi
}
render(){
  : > "$W/flow"
  if [ "$MODE" = smart ] && [ "$NATIVE" = 0 ] && [ ! -s /tmp/tgeek-time-guard.error ] && [ ! -s /tmp/tgeek-time-guard.skipped ]; then
    nft list table inet tgeek_time_guard_v13 >/dev/null 2>&1 || return 0
    DEV=$(qset "$W/devices")
    {
      echo "table inet $TABLE {"
      echo "  flowtable ft { hook ingress priority filter; devices = $DEV; counter; }"
      echo '  chain eligible { type filter hook forward priority 10; policy accept;'
      if [ -s "$W/exclude" ]; then echo "    iifname \"$LAN\" ether saddr $(joinset "$W/exclude") return"; fi
      # Only initiate bidirectional offload from LAN side after native FW4 verdict.
      echo "    iifname \"$LAN\" oifname $WAN ct state established meta mark 0 ct mark 0 meta l4proto { tcp, udp } counter flow add @ft"
      echo '  }'; echo '}'
    } > "$W/flow"
  fi
}
flow_apply(){
  if [ ! -s "$W/flow" ]; then remove "$TABLE"; rm -f "$STATE/flow"; return 0; fi
  if [ -f "$STATE/flow" ] && cmp -s "$W/flow" "$STATE/flow" && nft list table inet "$TABLE" >/dev/null 2>&1; then return 0; fi
  : > "$W/tx"; if nft list table inet "$TABLE" >/dev/null 2>&1; then echo "delete table inet $TABLE" >> "$W/tx"; fi
  cat "$W/flow" >> "$W/tx"
  if ! nft -c -f "$W/tx" || ! nft -f "$W/tx"; then remove "$TABLE"; rm -f "$STATE/flow"; return 1; fi
  cp "$W/flow" "$STATE/flow"; log "Software flowtable updated; excluded $(wc -l < "$W/exclude") MAC(s); old flowtable retired."
}
addresses(){
  awk 'FILENAME==ARGV[1]{m[$0]=1;next} $0 !~ /FAILED|INCOMPLETE/ {for(i=1;i<NF;i++)if($i=="lladdr" && m[tolower($(i+1))] && $1 ~ /^[0-9a-fA-F:.]+$/ && tolower($1) !~ /^fe80:/)print $1}' "$W/cutmac" "$1" | sort -u
}

# V1.4.8: Feature Guard. No network download, no OAF config change.
FEATURE=/etc/appfilter/feature.cfg
FB=$BASE/feature-v148
# Only the documented symlink (or a not-yet-created boot link) is supported.
feature_path(){
  [ -d /etc/appfilter ] && [ ! -L /etc/appfilter ] && [ ! -L "$FEATURE" ] || return 1
  [ ! -e "$FEATURE" ] || [ -f "$FEATURE" ] || return 1
  if [ -L /tmp/feature.cfg ]; then [ "$(readlink /tmp/feature.cfg)" = "$FEATURE" ] || return 1
  elif [ -e /tmp/feature.cfg ]; then return 1; fi
}
feature_valid(){
  [ -f "$1" ] && [ -s "$1" ] || return 1
  size=$(wc -c < "$1") || return 1
  [ "$size" -le 4194304 ] || return 1
  # Validate record boundaries and unique IDs, not vendor-specific DPI payloads.
  awk '
    /^[[:space:]]*($|#)/{next}
    /^[0-9]+[ \t]+[^:]+:\[.*\][ \t\r]*$/ {if($1 !~ /^[1-9][0-9]*$/ || $1>65535 || seen[$1]++)bad=1; n++;next}
    {bad=1}
    END{exit (bad||n<1||n>4096)}' "$1"
}
feature_hash(){
  local h; h=$(sha256sum < "$1") || return 1; h=${h%% *}
  case "$h" in ''|*[!0-9a-f]*) return 1;; esac
  [ "${#h}" = 64 ] || return 1; printf '%s\n' "$h"
}
feature_snapshot(){
  feature_path || return 1
  [ -f "$FEATURE" ] && [ -s "$FEATURE" ] || return 1
  cp "$FEATURE" "$W/feature" && feature_valid "$W/feature" && cmp -s "$FEATURE" "$W/feature"
}
feature_note(){
  printf 'state=%s reason=%s last_sync=%s\n' "$1" "$2" "$(date +%s)" > "$STATE/feature.status.new"
  mv "$STATE/feature.status.new" "$STATE/feature.status"
  key="$1 $2"
  if [ "$(cat "$STATE/feature.event" 2>/dev/null || :)" != "$key" ]; then
    printf '%s\n' "$key" > "$STATE/feature.event"
    logger -t tgeek-feature-v148 "$key" 2>/dev/null || :
  fi
}
feature_saved(){
  fh=$(cat "$FB/current" 2>/dev/null) || return 1
  case "$fh" in ''|*[!0-9a-f]*) return 1;; esac
  [ "${#fh}" = 64 ] || return 1
  saved="$FB/$fh.cfg"
  [ ! -L "$saved" ] && feature_valid "$saved" && [ "$(feature_hash "$saved")" = "$fh" ]
}
feature_commit(){
  # W/feature is a validated snapshot; pointer swap commits one complete generation.
  feature_valid "$W/feature" && feature_path && cmp -s "$FEATURE" "$W/feature" || return 1
  [ ! -L "$FB" ] || return 1
  mkdir -p "$FB" && chmod 700 "$FB" || return 1
  newhash=$(feature_hash "$W/feature") || return 1
  oldhash=$(cat "$FB/current" 2>/dev/null || :)
  if [ "$oldhash" = "$newhash" ] && feature_saved; then return 0; fi
  cp "$W/feature" "$FB/.candidate.$$" && chmod 600 "$FB/.candidate.$$" && [ "$(feature_hash "$FB/.candidate.$$")" = "$newhash" ] && mv -f "$FB/.candidate.$$" "$FB/$newhash.cfg" || return 1
  if feature_saved && [ "$fh" != "$newhash" ]; then printf '%s\n' "$fh" > "$FB/previous.new" && mv "$FB/previous.new" "$FB/previous" || return 1; fi
  printf '%s\n' "$newhash" > "$FB/current.new" && mv "$FB/current.new" "$FB/current" || return 1
  # Keep content-addressed generations; no automatic deletion of user backups.
  logger -t tgeek-feature-v148 "backup sha256=$newhash" 2>/dev/null || :
}
feature_ids_only(){ awk '/^[0-9]+[ \t]+[^:]+:\[/{print $1}' "$1" | sort -u; }
feature_restore(){
  feature_path && feature_saved || return 1
  # Never overwrite a nonempty live file, even if malformed: an external
  # update may be in progress. Malformed files are reported for manual review.
  [ ! -s "$FEATURE" ] || return 1
  stage=$(mktemp /etc/appfilter/.tgeek-feature.XXXXXX) || return 1
  if cp "$saved" "$stage" && chmod 644 "$stage" && [ "$(feature_hash "$stage")" = "$fh" ] && feature_path && [ ! -s "$FEATURE" ] && mv -f "$stage" "$FEATURE"; then
    printf '%s\n' "$(date +%s) $fh" > "$FB/last-restore.new" && mv "$FB/last-restore.new" "$FB/last-restore" || :
    printf '%s\n' "$(date +%s) $fh" > "$STATE/feature.recovered"
    feature_note recovered empty-or-missing
    logger -t tgeek-feature-v148 "restored sha256=$fh; native OAF reload not forced" 2>/dev/null || :
    return 0
  fi
  rm -f "$stage"; return 1
}
feature_tick(){
  [ -f /etc/config/appfilter ] || { feature_note skipped no-oaf; return 0; }
  if ! feature_path; then feature_note blocked unsupported-path; return 1; fi
  if feature_snapshot; then
    rm -f "$STATE/feature.bad"
    hash=$(feature_hash "$W/feature")
    if feature_saved; then
      if [ "$hash" = "$fh" ]; then rm -f "$STATE/feature.candidate"; feature_note healthy verified-backup; return 0; fi
      # A shorter or changed-ID catalog needs explicit administrator approval.
      feature_ids_only "$saved" > "$W/oldids"; feature_ids_only "$W/feature" > "$W/newids"
      if awk 'FILENAME==ARGV[1]{a[$1]=1;next}!($1 in a){bad=1}END{exit !bad}' "$W/newids" "$W/oldids"; then
        rm -f "$STATE/feature.candidate"; feature_note pending changed-id-set; return 1
      fi
    elif [ -e "$FB/current" ]; then feature_note blocked invalid-backup; return 1
    else
      # Initial automatic backup must cover the configured selected IDs.
      sed -n 's/^appfilter.rule.app_list=//p' "$W/oaf" | tr "' " '\n\n' | awk '/^[1-9][0-9]*$/' | sort -u > "$W/requiredids"
      feature_ids_only "$W/feature" > "$W/newids"
      if awk 'FILENAME==ARGV[1]{a[$1]=1;next}!($1 in a){bad=1}END{exit !bad}' "$W/newids" "$W/requiredids"; then feature_note pending missing-configured-ids; return 1; fi
    fi
    # Two separate observations at least 5 s apart; no backup during preview.
    now=$(date +%s); prev=; since=0
    if [ -f "$STATE/feature.candidate" ]; then read -r prev since < "$STATE/feature.candidate" || :; fi
    case "$since" in ''|*[!0-9]*) since=0;; esac
    if [ "$prev" = "$hash" ] && [ "$now" -ge "$since" ] && [ $((now-since)) -ge 5 ]; then
      if feature_commit; then rm -f "$STATE/feature.candidate"; feature_note healthy backup-created; return 0; fi
      feature_note blocked backup-write-failed; return 1
    fi
    if [ "$prev" != "$hash" ] || [ "$now" -lt "$since" ]; then printf '%s %s\n' "$hash" "$now" > "$STATE/feature.candidate"; fi
    feature_note pending awaiting-stable-snapshot; return 1
  fi
  rm -f "$STATE/feature.candidate"
  if [ -s "$FEATURE" ]; then rm -f "$STATE/feature.bad"; feature_note blocked malformed-or-changing; return 1; fi
  now=$(date +%s); since=$(cat "$STATE/feature.bad" 2>/dev/null || echo 0)
  case "$since" in ''|*[!0-9]*) since=0;; esac
  if [ "$since" = 0 ] || [ "$now" -lt "$since" ]; then echo "$now" > "$STATE/feature.bad"; feature_note pending empty-or-missing; return 1; fi
  [ $((now-since)) -ge 5 ] || return 1
  if feature_restore; then rm -f "$STATE/feature.bad"; return 0; fi
  feature_note blocked no-verified-backup-or-restore-failed; return 1
}
feature_status(){
  cat "$STATE/feature.status" 2>/dev/null || :
  if feature_path && feature_valid "$FEATURE"; then echo "live_sha256=$(feature_hash "$FEATURE") live_ids=$(feature_ids_only "$FEATURE" | wc -l)"; else echo 'live=invalid-or-missing'; fi
  if feature_saved; then echo "backup_sha256=$fh backup_ids=$(feature_ids_only "$saved" | wc -l)"; else echo 'backup=missing-or-invalid'; fi
  [ ! -f "$FB/last-restore" ] || { printf 'last_restore='; cat "$FB/last-restore"; echo 'Native DPI reload not forced; verify native filtering after restoration.'; }
}
feature_verify(){
  feature_status
  [ -f /etc/config/appfilter ] || return 0
  feature_path && [ -L /tmp/feature.cfg ] && feature_valid "$FEATURE" && feature_saved && cmp -s "$FEATURE" "$saved" || return 2
  echo 'PASS: live feature and verified backup match (not proof of kernel reload)'
}

# QUIC compatibility: opt-in via committed OAF disable_quic only. No app
# ID/domain is hard-coded. The set lease is a fail-open safety mechanism.
QTABLE=tgeek_quic_guard_v145
quic_off(){
  remove "$QTABLE"
  rm -f "$STATE/quic.layout"
  printf 'state=inactive reason=%s last_sync=%s\n' "${1:-app-guard-inactive}" "$(date +%s)" > "$STATE/quic.status"
}
quic_layout(){
  cat > "$W/quic.layout" <<EOFQ
table inet $QTABLE {
  set clients { type ether_addr; flags timeout; timeout 25s; }
  counter quic4 { }
  counter quic6 { }
  chain quic_out {
    fib daddr type { local, broadcast, multicast, anycast } return
    ip daddr { 0.0.0.0/8, 10.0.0.0/8, 127.0.0.0/8, 169.254.0.0/16, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 240.0.0.0/4 } return
    ip6 daddr { ::/128, ::1/128, fc00::/7, fe80::/10, ff00::/8 } return
    meta nfproto ipv4 counter name quic4 drop
    meta nfproto ipv6 counter name quic6 drop
  }
  chain pre {
    type filter hook prerouting priority -190; policy accept;
    iifname "$LAN" ether saddr @clients udp dport 443 fib daddr oifname $ROUTES jump quic_out
  }
  chain forward {
    type filter hook forward priority -30; policy accept;
    iifname "$LAN" oifname $ROUTES ether saddr @clients udp dport 443 jump quic_out
  }
}
EOFQ
}
quic_apply(){
  if [ "$QUIC" != 1 ]; then quic_off switch-off-or-unknown; return 0; fi
  if [ "$(cat /proc/sys/oaf/lan_ifname 2>/dev/null || :)" != "$LAN" ]; then quic_off runtime-lan-mismatch; return 1; fi
  if ! sed -n 's/^appfilter.rule.app_list=//p' "$W/oaf" | tr "' " '\n\n' | awk '/^[1-9][0-9]*$/ && $0<=65535{ok=1}END{exit !ok}'; then quic_off no-configured-apps; return 0; fi
  # Use configured selected MACs, even before neighbor discovery; all-user
  # mode uses known neighbors minus whitelist, identical to precision scope.
  if [ ! -s "$W/targets" ]; then quic_off no-targets; return 0; fi
  quic_layout
  : > "$W/qtx"
  if [ ! -f "$STATE/quic.layout" ] || ! cmp -s "$W/quic.layout" "$STATE/quic.layout" || ! nft list table inet "$QTABLE" >/dev/null 2>&1; then
    if nft list table inet "$QTABLE" >/dev/null 2>&1; then echo "delete table inet $QTABLE" >> "$W/qtx"; fi
    cat "$W/quic.layout" >> "$W/qtx"
  fi
  # Flush and populate in ONE transaction; no unprotected intermediate set.
  echo "flush set inet $QTABLE clients" >> "$W/qtx"
  echo "add element inet $QTABLE clients $(joinset "$W/targets")" >> "$W/qtx"
  if ! nft -c -f "$W/qtx" || ! nft -f "$W/qtx"; then
    quic_off nft-error
    logger -t tgeek-quic 'QUIC transaction failed; removed owned table (or lease expires)' 2>/dev/null || :
    return 1
  fi
  cp "$W/quic.layout" "$STATE/quic.layout"
  printf 'state=active switch=1 scope=%s targets=%s lease=25s last_sync=%s\n' "$SCOPE" "$(wc -l < "$W/targets")" "$(date +%s)" > "$STATE/quic.status"
}
quic_status(){
  printf 'OAF disable_quic=%s runtime_enable=%s\n' "$(get appfilter.global.disable_quic)" "$(cat /proc/sys/oaf/enable 2>/dev/null || echo unknown)"
  cat "$STATE/quic.status" 2>/dev/null || echo 'QUIC Guard: awaiting sync'
  nft list table inet "$QTABLE" 2>/dev/null || :
}
quic_verify(){
  readconf
  quic_status
  if [ "$CONNECTION" != 1 ] || [ "$(get appfilter.global.disable_quic)" != 1 ] || [ "$(cat /proc/sys/oaf/enable 2>/dev/null || echo 0)" != 1 ] || [ "$(get appfilter.global.enable)" != 1 ]; then
    if nft list table inet "$QTABLE" >/dev/null 2>&1; then echo 'WARN: QUIC table remains; wait for sync/lease'; return 2; fi
    echo 'PASS: QUIC inactive'; return 0
  fi
  stamp=$(sed -n 's/.* last_sync=\([0-9]*\)$/\1/p' "$STATE/quic.status" 2>/dev/null || :)
  case "$stamp" in ''|*[!0-9]*) echo 'WARN: missing QUIC heartbeat'; return 2;; esac
  now=$(date +%s)
  if [ "$now" -lt "$stamp" ] || [ $((now-stamp)) -gt 20 ]; then echo 'WARN: stale QUIC heartbeat'; return 2; fi
  if grep -Eq '^state=inactive reason=(no-targets|no-configured-apps) ' "$STATE/quic.status"; then
    if nft list table inet "$QTABLE" >/dev/null 2>&1; then echo 'WARN: unexpected QUIC table'; return 2; fi
    echo 'PASS: no eligible targets/apps'; return 0
  fi
  if ! grep -q '^state=active ' "$STATE/quic.status" || ! nft list table inet "$QTABLE" >/dev/null 2>&1; then echo 'WARN: QUIC requested but not active'; return 2; fi
  if ! nft list set inet "$QTABLE" clients 2>/dev/null | grep -q 'elements ='; then echo 'WARN: QUIC target lease empty'; return 2; fi
  echo 'PASS: QUIC table and target lease present; verify real traffic using counters'
}
quic_stats(){
  cat "$STATE/quic.status" 2>/dev/null || :
  echo 'FAMILY | PACKETS | BYTES (current table lifetime; not app attribution)'
  if ! nft list table inet "$QTABLE" >/dev/null 2>&1; then echo 'Inactive: no current counters'; return 0; fi
  nft list counters table inet "$QTABLE" | awk '$1=="counter"&&$2~/^quic[46]$/{id=$2} $1=="packets"&&$3=="bytes"&&id!=""{printf "IPv%s | %s | %s\n",substr(id,5),$2,$4;id=""}'
}
# App Precision Guard: no broad device interruption, no conntrack flush.
APP=tgeek_app_precision_v143
precision_off(){
  if nft list table inet "$APP" >/dev/null 2>&1; then
    read_counters > "$W/direct.final"
    if nft delete table inet "$APP" 2>/dev/null; then archive_counters "$W/direct.final"; fi
  fi
  rm -f "$STATE/precision.layout" "$STATE/precision.policy" "$STATE/precision.status"
}
precision_status(){
  cat "$STATE/precision.status" 2>/dev/null || echo 'Precision Guard: awaiting sync'
  nft list table inet "$APP" 2>/dev/null || :
}
precision_verify(){
  readconf
  precision_status
  [ "$CONNECTION" = 1 ] || { echo 'PASS: precision intentionally disabled'; return 0; }
  if [ "$(cat /proc/sys/oaf/enable 2>/dev/null || echo 0)" != 1 ]; then
    if nft list table inet "$APP" >/dev/null 2>&1; then echo 'WARN: inactive OAF; wait for next sync'; return 2; fi
    echo 'PASS: OAF inactive'; return 0
  fi
  if ! grep -q '^state=active ' "$STATE/precision.status" 2>/dev/null || ! nft list table inet "$APP" >/dev/null 2>&1; then echo 'WARN: active OAF but precision not ready'; return 2; fi
  stamp=$(sed -n 's/.* last_sync=\([0-9]*\)$/\1/p' "$STATE/precision.status")
  case "$stamp" in ''|*[!0-9]*) echo 'WARN: missing heartbeat'; return 2;; esac
  now=$(date +%s)
  if [ "$now" -lt "$stamp" ] || [ $((now-stamp)) -gt 20 ]; then echo 'WARN: stale precision heartbeat'; return 2; fi
  if grep -q 'mark_mode=skipped' "$STATE/precision.status"; then echo 'WARN: direct mark guard disabled (driver/mark conflict); proxy matching only'; return 2; fi
  if [ -f /etc/config/nikki ] && grep -Eq 'requested_ids=[1-9][0-9]* .*proxy_api=(unavailable|missing-curl|bad-port|bad-secret|empty-or-invalid)' "$STATE/precision.status"; then echo 'WARN: proxy API not verified'; return 2; fi
  if grep -Eq 'missing_ids=[1-9][0-9]*' "$STATE/precision.status"; then echo 'WARN: requested app IDs absent from loaded feature catalog'; return 2; fi
  echo 'PASS: precision table and status present; real application playback test still required'
}
# Feature catalog is authoritative. No app IDs/domains are hard-coded.
# Snapshot the active file; no download or modification of OAF data.
precision_ids(){
  : > "$W/ids"; : > "$W/hostrules"; : > "$W/catalog"; : > "$W/selectedcatalog"
  feature_snapshot || return 1
  if [ "${1:-runtime}" != preview ]; then [ -L /tmp/feature.cfg ] && feature_saved && cmp -s "$W/feature" "$saved" || return 1; fi
  awk '/^[0-9]+[ \t]+[^:]+:\[/ {id=$1;if(id!~/^[1-9][0-9]*$/||id>65535)next;n=$0;sub(/^[0-9]+[ \t]+/,"",n);sub(/:\[.*/,"",n);gsub(/[[:cntrl:]]/," ",n);if(id in names && names[id]!=n)bad[id]=1;names[id]=n}END{for(i in names)if(!bad[i])printf "%s\t%s\n",i,names[i]}' "$W/feature" | sort -n > "$W/catalog"
  [ -s "$W/catalog" ] || return 1
  sed -n 's/^appfilter.rule.app_list=//p' "$W/oaf" | tr "' " '\n\n' | awk '/^[1-9][0-9]*$/ && $0<=65535 {print}' | sort -u > "$W/requested"
  awk 'FILENAME==ARGV[1]{a[$1]=1;next} $1 in a' "$W/requested" "$W/catalog" > "$W/selectedcatalog"
  awk '{print $1}' "$W/selectedcatalog" > "$W/ids"
  # Parse literal host clauses for ALL catalog apps, including allowed apps,
  # so a shared host does not become an exclusive blocked-app signature.
  # Only a host-only clause is sufficient; payload/URI/dictionary clauses are
  # retained as ambiguity evidence, never translated into host-only blocking.
  awk '
    FILENAME==ARGV[1]{valid[$1]=1;next}
    /^[0-9]+[ \t]+[^:]+:\[/ && ($1 in valid) {
      id=$1; x=$0;sub(/^[^:]+:\[/,"",x);sub(/\][ \t\r]*$/,"",x)
      n=split(x,cl,",");for(i=1;i<=n;i++){
        k=split(cl[i],f,";");p=tolower(f[1]);h=tolower(f[4]);sub(/\.$/,"",h)
        if((p!="tcp"&&p!="udp")||length(h)<4||h!~/^[a-z0-9][a-z0-9.-]*[a-z0-9]$/||h~/\.\./||h~/\.-|-\./||h~/^[0-9.]+$/)continue
        ok=1;for(j=5;j<=k;j++)if(f[j]!="")ok=0
        for(j=2;j<=3;j++)if(f[j]!=""&&f[j]!~/^[0-9]+(-[0-9]+)?$/)ok=0
        printf "%s\t%s\t%s\t%s\t%s\t%s\n",id,p,(f[2]==""?"*":f[2]),(f[3]==""?"*":f[3]),h,ok
      }
    }' "$W/catalog" "$W/feature" | sort -u > "$W/hostrules"
  sha256sum < "$W/feature" > "$W/feature.hash"
}
# Feature host matching is deliberately a safe subset of OAF DPI. A bare
# literal matches a whole DNS label; a dotted literal matches exact/suffix.
# Protocol and port constraints must match. Conflicting owners => abstain.
feature_host_match(){
  awk -v h="$1" -v s="$2" -v p="$3" -v sp="$4" -v dp="$5" '
    function hostname(x){x=tolower(x);sub(/\.$/,"",x);return x~/^[a-z0-9][a-z0-9.-]*[a-z0-9]$/&&x!~/\.\./?x:""}
    function matchhost(x,y,labels,n){if(x=="")return 0;if(index(y,"."))return x==y||(length(x)>length(y)&&substr(x,length(x)-length(y),length(y)+1)=="." y);n=split(x,labels,".");return n>=2&&labels[n-1]==y&&labels[n]~/^[a-z][a-z]+$/}
    function portmatch(x,v, a,n){if(x=="*")return 1;if(x!~/^[0-9]+(-[0-9]+)?$/)return -1;n=split(x,a,"-");if(a[1]<1||a[1]>65535||(n==2&&(a[2]<a[1]||a[2]>65535)))return -1;return n==1?v==a[1]:v>=a[1]&&v<=a[2]}
    BEGIN{h=hostname(h);s=hostname(s)}
    $2==p && (matchhost(h,$5)||matchhost(s,$5)) {a=portmatch($3,sp);b=portmatch($4,dp);if(a==0||b==0)next;owners[$1]=1;if($6==1&&a==1&&b==1)eligible[$1]=1}
    END{n=0;for(i in owners){n++;id=i}if(n==1&&eligible[id])print id;else if(n>1)print "ambiguous"}' "$W/hostrules"
}
# Named counter objects share statistics across pre/forward rules.
# The mark set and client set have short leases; the per-ID rules alone
# cannot block anything when the guardian stops refreshing the sets.
precision_layout(){
  {
    cat <<EOF2
table inet $APP {
  set clients { type ether_addr; flags timeout; timeout 25s; }
  set a4 { type ipv4_addr; flags timeout; timeout 25s; }
  set a6 { type ipv6_addr; flags timeout; timeout 25s; }
  set apps { type mark; flags timeout; timeout 25s; }
  set proxy4 { type ipv4_addr . ipv4_addr . inet_proto . inet_service . inet_service; flags timeout; timeout 25s; }
  set proxy6 { type ipv6_addr . ipv6_addr . inet_proto . inet_service . inet_service; flags timeout; timeout 25s; }
EOF2
    while read -r appid; do echo "  counter app_$appid { }"; done < "$W/marks"
    echo '  chain mark_pre {'
    while read -r appid; do echo "    ct mark $appid counter name app_$appid drop"; done < "$W/marks"
    echo '  }'
    echo '  chain mark_forward {'
    while read -r appid; do
      echo "    ct mark $appid meta l4proto tcp counter name app_$appid reject with tcp reset"
      echo "    ct mark $appid meta l4proto udp counter name app_$appid drop"
    done < "$W/marks"
    cat <<EOF2
  }
  chain pre {
    type filter hook prerouting priority -160; policy accept;
    iifname "$LAN" fib daddr type local return
    iifname "$LAN" meta l4proto { tcp, udp } th dport { 53, 853 } return
    iifname "$LAN" ether saddr @clients fib daddr oifname $ROUTES ct mark @apps meta l4proto { tcp, udp } jump mark_pre
    iifname "$LAN" ether saddr @clients fib daddr oifname $ROUTES meta l4proto { tcp, udp } ip saddr . ip daddr . meta l4proto . th sport . th dport @proxy4 counter drop
    iifname "$LAN" ether saddr @clients fib daddr oifname $ROUTES meta l4proto { tcp, udp } ip6 saddr . ip6 daddr . meta l4proto . th sport . th dport @proxy6 counter drop
  }
  chain forward {
    type filter hook forward priority -20; policy accept;
    iifname "$LAN" meta l4proto { tcp, udp } th dport { 53, 853 } return
    oifname "$LAN" meta l4proto { tcp, udp } th sport { 53, 853 } return
    iifname "$LAN" oifname $ROUTES ether saddr @clients ct mark @apps meta l4proto { tcp, udp } jump mark_forward
    iifname $ROUTES oifname "$LAN" ip daddr @a4 ct mark @apps meta l4proto { tcp, udp } jump mark_forward
    iifname $ROUTES oifname "$LAN" ip6 daddr @a6 ct mark @apps meta l4proto { tcp, udp } jump mark_forward
  }
}
EOF2
  } > "$W/layout"
}
# Counters: direct packets/bytes, API matched/closed/failed, exact tuples added.
# Archive current-generation direct counters on an intentional table removal.
read_counters(){
  nft list counters table inet "$APP" 2>/dev/null | awk '$1=="counter"&&$2~/^app_[0-9]+$/{id=substr($2,5)} $1=="packets"&&$3=="bytes"&&id!=""{print id,$2,$4;id=""}'
}
archive_counters(){
  [ -f "$STATE/direct.total" ] || : > "$STATE/direct.total"
  awk '{p[$1]+=$2;b[$1]+=$3}END{for(i in p)printf "%s %.0f %.0f\n",i,p[i],b[i]}' "$STATE/direct.total" "$1" > "$STATE/direct.new"
  mv "$STATE/direct.new" "$STATE/direct.total"
}
precision_stats(){
  echo '=== OAF feature-driven application statistics (since upgrade/reboot/current feature snapshot) ==='
  cat "$STATE/precision.status" 2>/dev/null || :
  [ -f "$STATE/selected.catalog" ] || { echo 'No active feature catalog observed yet'; return 0; }
  echo 'ID | NAME | MARK_PACKETS | MARK_BYTES | PROXY_MATCHED | PROXY_CLOSED | PROXY_FAILED | TUPLES_ADDED'
  # Read-only output: merge archived + current using an awk input stream.
  { [ ! -f "$STATE/direct.total" ] || awk '{print "D",$0}' "$STATE/direct.total"; read_counters | awk '{print "D",$0}'; [ ! -f "$STATE/proxy.total" ] || awk '{print "P",$0}' "$STATE/proxy.total"; awk '{print "C",$0}' "$STATE/selected.catalog"; } | awk -v all="${1:-hits}" '
    $1=="D"{p[$2]+=$3;b[$2]+=$4;next}$1=="P"{m[$2]+=$3;c[$2]+=$4;f[$2]+=$5;t[$2]+=$6;next}
    $1=="C"{id=$2;n=$0;sub(/^C [0-9]+[ \t]+/,"",n);total++;if(p[id]||m[id])hit++;if(all=="all"||p[id]||m[id])printf "%s | %s | %.0f | %.0f | %.0f | %.0f | %.0f | %.0f\n",id,n,p[id],b[id],m[id],c[id],f[id],t[id]}
    END{printf "Selected apps: %d; observed hits: %d\n",total,hit}'
  echo 'Mark counters = packets dropped/rejected by TGEEK; proxy counters = API actions, not packet counts. No hit does not prove failure.'
}

mark_safe(){
  # The installed 5.3.2 driver has been observed with plain app IDs. Other
  # layouts and flag bits are not assumed. Reject detectable mark writers.
  mark_reason=unsupported-driver
  grep -Eq '(^|[^0-9])5\.3\.2([^0-9]|$)' /proc/sys/oaf/version 2>/dev/null || return 1
  mark_reason=mark-writer-or-unverified-rules
  nft list ruleset > "$W/allrules" 2>/dev/null || return 1
  if grep -Eq 'ct mark set|ct mark map|CONNMARK' "$W/allrules"; then return 1; fi
  for cmd in iptables-save ip6tables-save; do
    if command -v "$cmd" >/dev/null; then
      "$cmd" > "$W/legacy" 2>/dev/null || return 1
      if grep -Eq -- '-j CONNMARK|--set-xmark|--set-mark' "$W/legacy"; then return 1; fi
    fi
  done
  # Known routing mark consumers: conservatively do not trust ambiguous IDs.
  if [ -x /etc/init.d/mwan3 ] && /etc/init.d/mwan3 enabled >/dev/null 2>&1; then mark_reason=mwan3-enabled; return 1; fi
  mark_reason=plain-id-layout
  return 0
}
# Atomic replacement of live sets; refresh short lease even with no policy change.
precision_sets(){
  for s in clients a4 a6 apps; do
    echo "flush set inet $APP $s"
    case "$s" in clients) f="$W/cutmac";; apps) f="$W/marks";; *) f="$W/$s";; esac
    if [ -s "$f" ]; then echo "add element inet $APP $s $(joinset "$f")"; fi
  done
}
precision_apply(){
  precision_layout
  : > "$W/ptx"; : > "$W/direct.replaced"
  rebuild=0
  if [ ! -f "$STATE/precision.layout" ] || ! cmp -s "$W/layout" "$STATE/precision.layout" || ! nft list table inet "$APP" >/dev/null 2>&1; then
    rebuild=1
    if nft list table inet "$APP" >/dev/null 2>&1; then read_counters > "$W/direct.replaced"; echo "delete table inet $APP" >> "$W/ptx"; fi
    cat "$W/layout" >> "$W/ptx"
  fi
  precision_sets >> "$W/ptx"
  cat "$W/policy" "$W/white" "$W/cutmac" "$W/ids" "$W/a4" "$W/a6" "$W/hostrules" "$W/feature.hash" > "$W/ppolicy"
  if [ "$rebuild" = 0 ] && { [ ! -f "$STATE/precision.policy" ] || ! cmp -s "$W/ppolicy" "$STATE/precision.policy"; }; then
    echo "flush set inet $APP proxy4" >> "$W/ptx"; echo "flush set inet $APP proxy6" >> "$W/ptx"
  fi
  if ! nft -c -f "$W/ptx" || ! nft -f "$W/ptx"; then precision_off precision-nft-error; return 1; fi
  if [ "$rebuild" = 1 ]; then archive_counters "$W/direct.replaced"; fi
  cp "$W/layout" "$STATE/precision.layout"; cp "$W/ppolicy" "$STATE/precision.policy"
}
# Query a conntrack snapshot by exact original 5-tuple. Only unique matches
# are eligible; the application mark is not inferred from an IP or port.
ct_index(){
  : > "$W/ctindex"
  [ -r /proc/net/nf_conntrack ] || return 0
  awk '$3=="tcp"||$3=="udp" {a=b=c=d=m="";for(i=1;i<=NF;i++){if(a==""&&$i~/^src=/)a=substr($i,5);if(b==""&&$i~/^dst=/)b=substr($i,5);if(c==""&&$i~/^sport=/)c=substr($i,7);if(d==""&&$i~/^dport=/)d=substr($i,7);if($i~/^mark=/)m=substr($i,6)}if(a!=""&&b!=""&&c!=""&&d!=""&&m~/^[0-9]+$/)print a,b,$3,c,d,m}' /proc/net/nf_conntrack > "$W/ctindex" || : > "$W/ctindex"
}
ct_lookup(){ awk -v s="$1" -v d="$2" -v p="$3" -v sp="$4" -v dp="$5" '$1==s&&$2==d&&$3==p&&$4==sp&&$5==dp{n++;m=$6}END{if(n==1)print m}' "$W/ctindex"; }
valid_tuple(){
  case "$1" in ''|*[!0-9a-fA-F:.]*) return 1;; esac
  case "$2" in tcp|udp) ;; *) return 1;; esac
  for portnum in "$3" "$4"; do
    case "$portnum" in ''|0*|*[!0-9]*) return 1;; esac
    [ "${#portnum}" -le 5 ] && [ "$portnum" -ge 1 ] && [ "$portnum" -le 65535 ] || return 1
  done
  case "$4" in 53|853) return 1;; esac
}
external_destination(){
  case "$1" in *:*) fam=-6;; *) fam=-4;; esac
  # Preserve local router, LAN, multicast, and unknown paths. Only accept a
  # route whose device is a known WAN/Nikki interface; no changes to routing.
  dstdev=$(ip "$fam" route get "$1" 2>/dev/null | awk 'NR==1&&$1!="local"&&$1!="broadcast"&&$1!="multicast"&&$1!="unreachable"&&$1!="blackhole"{for(i=1;i<NF;i++)if($i=="dev"){print $(i+1);exit}}')
  [ -n "$dstdev" ] && grep -Fxq "$dstdev" "$W/routes"
}
proxy_tuple(){
  tsrc=$1; tdst=$2; tproto=$3; tsp=$4; tdp=$5
  [ -n "$6" ] || return 0
  case "$tsrc" in *:*) setname=proxy6;; *) setname=proxy4;; esac
  case "$setname:$tdst" in proxy4:*:*) return 0;; proxy6:*:*) :;; proxy6:*) return 0;; esac
  if nft add element inet "$APP" "$setname" "{ $tsrc . $tdst . $tproto . $tsp . $tdp timeout 25s }" 2>/dev/null; then tuples=$((tuples+1)); fi
}
# Reduce fork overhead: select controlled IPs once using existing LuCI JSON decoder.
# If the decoder is unavailable, preserve the original jsonfilter traversal.
proxy_prefilter(){
  timeout 2 lua - "$W/connections" "$W/ips" <<'TGEEK_PROXY_LUA'
local j=require('luci.jsonc')
local f=assert(io.open(arg[1], 'rb')); local raw=f:read('*a'); f:close()
local r=j.parse(raw); assert(type(r)=='table' and type(r.connections)=='table')
local targets={}; for ip in io.lines(arg[2]) do targets[ip]=true end
for _,obj in ipairs(r.connections) do
  if type(obj)=='table' and type(obj.metadata)=='table' then
    local ip=obj.metadata.sourceIP
    if type(ip)=='string' then
      ip=ip:gsub('^::ffff:([0-9.]+)$','%1')
      if targets[ip] then io.write(assert(j.stringify(obj)), '\n') end
    end
  end
end
TGEEK_PROXY_LUA
}
precision_proxy(){
  matched=0; closed=0; failed=0; tuples=0; partial=0; api=disabled; ambiguous=0; unverified=0; classified_mark=0; classified_host=0; scan_total=0; scan_done=0; scan_mode=none
  : > "$W/proxy.events"
  [ -s "$W/ids" ] && [ -s "$W/ips" ] && [ -f /etc/config/nikki ] || return 0
  command -v curl >/dev/null || { api=missing-curl; return 0; }
  port=$(get nikki.mixin.api_port); [ -n "$port" ] || port=9090
  case "$port" in *[!0-9]*) api=bad-port; return 0;; esac
  [ "${#port}" -le 5 ] && [ "$port" -ge 1 ] && [ "$port" -le 65535 ] || { api=bad-port; return 0; }
  secret=$(get nikki.mixin.api_secret)
  case "$secret" in *[![:print:]]*) api=bad-secret; return 0;; esac
  printf 'Authorization: Bearer %s\n' "$secret" > "$W/auth"
  url="http://127.0.0.1:$port"; api=unavailable
  curl -q -fsS --noproxy '*' --connect-timeout 1 --max-time 2 --max-filesize 4194304 -H "@$W/auth" "$url/connections" -o "$W/connections" 2>/dev/null || return 0
  if command -v lua >/dev/null && proxy_prefilter > "$W/objects" 2>/dev/null; then
    scan_mode=target-prefilter
  else
    scan_mode=legacy
    jsonfilter -i "$W/connections" -e '@.connections[*]' > "$W/objects" 2>/dev/null || { if grep -Eq '"connections"[[:space:]]*:[[:space:]]*\[[[:space:]]*\]' "$W/connections"; then api=ok; else api=empty-or-invalid; fi; return 0; }
  fi
  api=ok; ct_index
  # Rotate bounded scan to avoid permanently starving later entries on busy routers.
  count=$(wc -l < "$W/objects"); scan_total=$count; [ "$count" -gt 0 ] || return 0
  offset=$(cat "$STATE/proxy.offset" 2>/dev/null || echo 0)
  case "$offset" in ''|*[!0-9]*) offset=0;; esac
  [ "${#offset}" -le 8 ] || offset=0
  offset=$((offset%count)); processed=0
  awk -v o="$offset" 'NR>o{print}' "$W/objects" > "$W/rotated"
  awk -v o="$offset" 'NR<=o{print}' "$W/objects" >> "$W/rotated"
  limit=$(($(date +%s)+3))
  while IFS= read -r obj; do
    [ "$(date +%s)" -lt "$limit" ] || { partial=1; break; }
    processed=$((processed+1))
    client=$(jsonfilter -s "$obj" -e '@.metadata.sourceIP' 2>/dev/null) || continue
    case "$client" in ::ffff:*.*) client=${client#::ffff:};; esac
    grep -Fxq "$client" "$W/ips" || continue
    dst=$(jsonfilter -s "$obj" -e '@.metadata.destinationIP' 2>/dev/null || :)
    proto=$(jsonfilter -s "$obj" -e '@.metadata.network' 2>/dev/null || :)
    sp=$(jsonfilter -s "$obj" -e '@.metadata.sourcePort' 2>/dev/null || :)
    dp=$(jsonfilter -s "$obj" -e '@.metadata.destinationPort' 2>/dev/null || :)
    if ! valid_tuple "$dst" "$proto" "$sp" "$dp"; then unverified=$((unverified+1)); continue; fi
    ctmark=$(ct_lookup "$client" "$dst" "$proto" "$sp" "$dp")
    appid=; via=host
    # A verified OAF mark wins over host inference, including allowed apps.
    if [ "$markmode" = exact-id ] && [ -n "$ctmark" ] && awk -v m="$ctmark" '$1==m{f=1}END{exit !f}' "$W/catalog"; then
      grep -Fxq "$ctmark" "$W/ids" || continue
      appid=$ctmark; via=mark
    else
      host=$(jsonfilter -s "$obj" -e '@.metadata.host' 2>/dev/null || :)
      sniff=$(jsonfilter -s "$obj" -e '@.metadata.sniffHost' 2>/dev/null || :)
      appid=$(feature_host_match "$host" "$sniff" "$proto" "$sp" "$dp")
      if [ "$appid" = ambiguous ]; then ambiguous=$((ambiguous+1)); continue; fi
      [ -n "$appid" ] && grep -Fxq "$appid" "$W/ids" || continue
    fi
    if ! external_destination "$dst"; then unverified=$((unverified+1)); continue; fi
    id=$(jsonfilter -s "$obj" -e '@.id' 2>/dev/null) || continue
    printf '%s\n' "$id" | grep -Eq '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' || continue
    [ "$(cat /proc/sys/oaf/enable 2>/dev/null || :)" = 1 ] || break
    matched=$((matched+1)); before=$tuples
    if [ "$via" = mark ]; then classified_mark=$((classified_mark+1)); else classified_host=$((classified_host+1)); fi
    proxy_tuple "$client" "$dst" "$proto" "$sp" "$dp" "$ctmark"
    if curl -q -fsS --noproxy '*' --connect-timeout 1 --max-time 1 -H "@$W/auth" -X DELETE "$url/connections/$id" -o /dev/null 2>/dev/null; then closed=$((closed+1)); printf '%s 1 1 0 %s\n' "$appid" "$((tuples-before))" >> "$W/proxy.events"; else failed=$((failed+1)); printf '%s 1 0 1 %s\n' "$appid" "$((tuples-before))" >> "$W/proxy.events"; fi
  done < "$W/rotated"
  scan_done=$processed
  echo "$(((offset+processed)%count))" > "$STATE/proxy.offset"
  if [ -s "$W/proxy.events" ]; then
    [ -f "$STATE/proxy.total" ] || : > "$STATE/proxy.total"
    awk '{m[$1]+=$2;c[$1]+=$3;f[$1]+=$4;t[$1]+=$5}END{for(i in m)printf "%s %.0f %.0f %.0f %.0f\n",i,m[i],c[i],f[i],t[i]}' "$STATE/proxy.total" "$W/proxy.events" > "$STATE/proxy.new"
    mv "$STATE/proxy.new" "$STATE/proxy.total"
    logger -t tgeek-precision "proxy matched=$matched closed=$closed failed=$failed tuple_add=$tuples via_mark=$classified_mark via_feature=$classified_host partial=$partial" 2>/dev/null || :
  fi
}

connection_apply(){
  if [ "$CONNECTION" != 1 ] || [ "$GLOBAL" != 1 ] || [ "$ACTIVE" != 1 ] || { [ "$SCOPE" != all ] && [ "$SCOPE" != selected ]; } || [ "$(cat /proc/sys/oaf/work_mode 2>/dev/null || :)" != 0 ]; then
    quic_off inactive-or-unsupported; precision_off inactive-or-unsupported; echo "state=inactive-or-unsupported active=$ACTIVE scope=$SCOPE" > "$STATE/precision.status"; return 0
  fi
  qrc=0; quic_apply || qrc=1
  if [ "$FEATURE_READY" != 1 ] || ! precision_ids; then precision_off feature-unavailable; log 'Feature unavailable or pending validation; QUIC independent'; echo 'state=feature-unavailable' > "$STATE/precision.status"; return 1; fi
  # Reset counters when feature bytes change: an ID may have been reassigned.
  if [ ! -f "$STATE/feature.hash" ] || ! cmp -s "$W/feature.hash" "$STATE/feature.hash"; then
    precision_off
    rm -f "$STATE/direct.total" "$STATE/proxy.total" "$STATE/proxy.offset"
    cp "$W/feature.hash" "$STATE/feature.hash"
  fi
  cp "$W/selectedcatalog" "$STATE/selected.catalog.new"; mv "$STATE/selected.catalog.new" "$STATE/selected.catalog"
  awk 'FILENAME==ARGV[1]{a[$0]=1;next}a[$0]' "$W/known" "$W/targets" > "$W/cutmac"
  addresses "$W/n4" > "$W/a4"; addresses "$W/n6" > "$W/a6"
  cat "$W/a4" "$W/a6" > "$W/ips"
  : > "$W/marks"; markmode=skipped-unverified-or-conflict
  if mark_safe; then cp "$W/ids" "$W/marks"; markmode=exact-id; fi
  if ! precision_apply; then echo 'state=nft-error' > "$STATE/precision.status"; return 1; fi
  precision_proxy
  printf 'state=active mark_mode=%s mark_reason=%s targets=%s ids=%s requested_ids=%s feature_ids=%s missing_ids=%s host_rules=%s proxy_api=%s matched=%s closed=%s failed=%s tuples=%s via_mark=%s via_feature=%s ambiguous=%s unverified=%s partial=%s scan_mode=%s scan_done=%s scan_total=%s last_sync=%s\n' "$markmode" "$mark_reason" "$(wc -l < "$W/cutmac")" "$(wc -l < "$W/marks")" "$(wc -l < "$W/requested")" "$(wc -l < "$W/ids")" "$(($(wc -l < "$W/requested")-$(wc -l < "$W/ids")))" "$(wc -l < "$W/hostrules")" "$api" "$matched" "$closed" "$failed" "$tuples" "$classified_mark" "$classified_host" "$ambiguous" "$unverified" "$partial" "$scan_mode" "$scan_done" "$scan_total" "$(date +%s)" > "$STATE/precision.status"
  return "$qrc"
}

mark_audit(){
  readconf; collect || return 1
  feature_snapshot || return 1
  feature_ids_only "$W/feature" > "$W/audit.ids"
  awk 'FILENAME==ARGV[1]{a[$0]=1;next}a[$0]' "$W/known" "$W/targets" > "$W/cutmac"
  addresses "$W/n4" > "$W/a4"; addresses "$W/n6" > "$W/a6"; cat "$W/a4" "$W/a6" > "$W/ips"
  [ -r /proc/net/nf_conntrack ] || { echo 'conntrack proc unavailable'; return 2; }
  if mark_safe; then echo "mark_policy=exact-id reason=$mark_reason"; else echo "mark_policy=skipped reason=$mark_reason"; fi
  awk 'FILENAME==ARGV[1]{id[$1]=1;next}FILENAME==ARGV[2]{ip[$1]=1;next}
    {s="";m="";for(i=1;i<=NF;i++){if(s==""&&$i~/^src=/)s=substr($i,5);if($i~/^mark=/)m=substr($i,6)}if(s in ip && m~/^[0-9]+$/ && m!=0)n[m]++}
    END{for(m in n){v=m+0;kind="unknown";a="-";if(v in id){kind="plain-id";a=v}else if(v>=2147483648 && v<=2147549183 && (v-2147483648) in id){kind="high-bit-candidate";a=v-2147483648}else if(v==1073741824){kind="flag-only"}printf "mark=%.0f count=%d class=%s candidate_id=%s\n",v,n[m],kind,a}}' "$W/audit.ids" "$W/ips" /proc/net/nf_conntrack
  echo 'Composite marks are diagnostic only; no automatic bitmask or routing-mark rewrite.'
}

case "${1:-status}" in
 mark-audit) setup; mark_audit; exit $?;;
 feature-status) feature_status; exit 0;;
 feature-verify) feature_verify; exit $?;;
 feature-backup) setup; feature_snapshot && feature_commit || { log 'ERROR: invalid/unstable feature or backup failed'; exit 1; }; feature_note healthy manual-backup; feature_status; exit 0;;
 feature-restore) setup; feature_restore || { log 'ERROR: only an empty/missing file with verified backup can be restored'; exit 1; }; feature_status; exit 0;;
 status) readconf; echo "mode=$MODE connection_guard=$CONNECTION"; cat "$STATE/status" 2>/dev/null || :; nft list table inet "$TABLE" 2>/dev/null || :; precision_status; quic_status; exit 0;;
 cut-status|app-status) precision_status; exit 0;;
 app-verify) precision_verify; exit $?;;
 app-stats) precision_stats "${2:-hits}"; exit 0;;
 quic-status) quic_status; exit 0;;
 quic-verify) quic_verify; exit $?;;
 quic-stats) quic_stats; exit $?;;
 remove) setup; remove "$TABLE"; remove "$CUT"; quic_off removed; precision_off; rm -f "$STATE/precision.status"; rm -f "$STATE/flow" "$STATE/active" "$STATE/policy" "$STATE/targets" "$STATE/status"; exit 0;;
 sync|preview) ;; test-cut) echo "V1.4.8: bulk test-cut retired; use app-status and sync"; exit 1;; *) exit 1;;
esac
setup; readconf
# Native flowtables would bypass the guard. Do not silently operate in mixed mode.
if [ "$1" != preview ] && { [ "$(get firewall.@defaults[0].flow_offloading)" = 1 ] || [ "$(get firewall.@defaults[0].flow_offloading_hw)" = 1 ]; }; then remove "$TABLE"; quic_off safety-stop; precision_off; log 'Native LuCI offloading enabled: use tgeek-firewall-fix flow-smart instead'; exit 1; fi
if ! collect; then if [ "$1" != preview ]; then remove "$TABLE"; quic_off safety-stop; precision_off; fi; log 'Topology/config unavailable; smart acceleration disabled'; exit 1; fi
render
if [ "$1" = preview ]; then echo "native_software=$(get firewall.@defaults[0].flow_offloading)"; echo "mode=$MODE scope=$SCOPE active=$ACTIVE fallback=$NATIVE"; cat "$W/exclude"; cat "$W/flow"; : > "$W/marks"; if precision_ids preview && [ -s "$W/ids" ]; then cp "$W/ids" "$W/marks"; else echo 1 > "$W/marks"; fi; precision_layout; : > "$W/precheck"; if nft list table inet "$APP" >/dev/null 2>&1; then echo "delete table inet $APP" >> "$W/precheck"; fi; cat "$W/layout" >> "$W/precheck"; nft -c -f "$W/precheck" || { log "Precision nft validation failed; no rules changed"; exit 1; }; echo "PASS: precision nft layout check"; quic_layout; : > "$W/qpreview"; if nft list table inet "$QTABLE" >/dev/null 2>&1; then echo "delete table inet $QTABLE" >> "$W/qpreview"; fi; cat "$W/quic.layout" >> "$W/qpreview"; if [ -s "$W/targets" ]; then echo "add element inet $QTABLE clients $(joinset "$W/targets")" >> "$W/qpreview"; else echo "add element inet $QTABLE clients { 02:00:00:00:00:01 }" >> "$W/qpreview"; fi; nft -c -f "$W/qpreview" || { log "QUIC nft validation failed; no rules changed"; exit 1; }; echo "PASS: QUIC nft layout check (switch=$QUIC)"; exit 0; fi
# Any third-party flowtable is outside our control. Refuse to add another one.
nft list flowtables > "$W/ft" || { remove "$TABLE"; quic_off safety-stop; precision_off; exit 1; }
if awk '/^table /{owned=($3=="tgeek_smart_flow_v141")} /flowtable / && !owned {bad=1} END{exit !bad}' "$W/ft"; then remove "$TABLE"; quic_off safety-stop; precision_off; log 'Foreign flowtable detected; cannot guarantee filtering'; exit 1; fi
# Remove only the legacy bulk-cut table. Precision guard never recreates it.
remove "$CUT"
flow_apply || { quic_off flow-error; precision_off; exit 1; }
printf 'scope=%s active=%s fallback=%s excluded=%s\n' "$SCOPE" "$ACTIVE" "$NATIVE" "$(wc -l < "$W/exclude")" > "$STATE/status"
FEATURE_READY=0
if feature_tick; then FEATURE_READY=1; fi
connection_apply

TGEEK_V145_SMART
cat > "$W/rrd" <<'TGEEK_V145_RRD'
#!/bin/sh
# TGEEK RRDIPT Guard V1.4.8 - exact known rule cleanup only
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/rrd-guard-v141
ACTION=${1:-status}
log(){ printf '[TGEEK RRD] %s\n' "$*"; [ "$ACTION" = status ] || logger -t tgeek-rrd "$*" 2>/dev/null || :; }
[ "$(id -u)" = 0 ] || exit 1
mkdir -p "$BASE"
exec 9>/tmp/tgeek-rrd-v141.lock
flock -n 9 || exit 75
W=$(mktemp -d /tmp/tgeek-rrd.XXXXXX)
trap 'rm -rf "$W"' EXIT
trap 'exit 1' HUP INT TERM
INIT=/etc/init.d/wrtbwmon
# Match executable or interpreter's script argument, not arbitrary shell arguments.
pids(){
 for p in /proc/[0-9]*; do
   [ -r "$p/cmdline" ] || continue
   tr '\000' '\n' < "$p/cmdline" 2>/dev/null | awk 'NR==1{a=$0} NR==2{b=$0} END{exit !((a=="/usr/sbin/wrtbwmon" || a=="wrtbwmon") || (a ~ /(^|\/)(sh|ash|bash|busybox)$/ && b=="/usr/sbin/wrtbwmon"))}' && echo "${p##*/}"
 done
 return 0
}
# Only actual backend pairs; also detect independent legacy rules if present.
backends(){
 for c in iptables ip6tables iptables-legacy ip6tables-legacy iptables-nft ip6tables-nft; do
   command -v "$c-save" >/dev/null 2>&1 || continue
   echo "$c"
 done
}
# Accept only mangle chains with exact known names; refuse unknown callers or jumps
# from owned chains into third-party chains. No broad flush/restore.
plan(){
 awk '
 function owned(s){return s=="RRDIPT_INPUT"||s=="RRDIPT_OUTPUT"||s=="RRDIPT_FORWARD"}
 /^\*/{tab=substr($0,2)}
 /^:/ {c=$1;sub(/^:/,"",c);if(owned(c)){if(tab!="mangle")bad=1;else print "chain " c}}
 /^-A /{c=$2;t="";for(i=3;i<NF;i++)if($i=="-j"||$i=="-g"||$i=="--jump"||$i=="--goto")t=$(i+1);
 if(owned(t)){if(tab=="mangle" && NF==4 && $3=="-j" && t=="RRDIPT_" c && (c=="INPUT"||c=="OUTPUT"||c=="FORWARD"))print "jump " c " " t;else bad=1}
 if(owned(c) && (tab!="mangle" || (t!="" && t!="RETURN" && t!="ACCEPT")))bad=1
 } END{exit bad}' "$1"
}
scan(){
 : > "$W/dirty"; : > "$W/failed"
 available=$(backends)
 [ -n "$available" ] || { echo "No iptables-save backends available" >> "$W/failed"; return 0; }
 for c in $available; do
   if ! "$c-save" > "$W/$c.save" 2>"$W/$c.err"; then echo "$c-save" >> "$W/failed"; continue; fi
   if grep -Eq '(^:RRDIPT_|[[:space:]]RRDIPT_)' "$W/$c.save"; then
      echo "$c" >> "$W/dirty"
      if ! plan "$W/$c.save" > "$W/$c.plan"; then echo "$c: unexpected RRDIPT references" >> "$W/failed"; fi
   fi
 done
}
links(){ for f in /etc/rc.d/[SK][0-9][0-9]wrtbwmon; do [ ! -L "$f" ] || printf '%s\n' "$f"; done; }
scan
pids > "$W/pids"; links > "$W/links"
case "$ACTION" in
 status)
   if command -v opkg >/dev/null; then opkg list-installed | grep -E '^(wrtbwmon|luci-app-wrtbwmon) ' || :; fi
   [ ! -e /usr/sbin/wrtbwmon ] || echo 'wrtbwmon binary exists'
   [ ! -e "$INIT" ] || echo 'wrtbwmon init exists'
   echo 'Processes:'; cat "$W/pids"; echo 'Boot links:'; cat "$W/links"; echo 'RRDIPT backends:'; for family in iptables ip6tables; do command -v "$family-save" >/dev/null 2>&1 || echo "$family-save unavailable (other backends may still be checked)"; done; cat "$W/dirty"; cat "$W/failed"
   if [ -s "$W/dirty" ] || [ -s "$W/pids" ] || [ -s "$W/links" ] || [ -s "$W/failed" ]; then exit 2; fi
   log 'PASS: no detected RRDIPT rules/processes/startup links (available backends only)'; exit 0;;
 rollback)
   [ -f "$BASE/original/enabled" ] || { log 'No V1.4.8 RRD snapshot'; exit 0; }
   if [ -x "$INIT" ]; then
     if [ "$(cat "$BASE/original/enabled")" = 1 ]; then "$INIT" enable; else "$INIT" disable; fi
     if [ "$(cat "$BASE/original/running")" = 1 ]; then "$INIT" start; fi
   else log 'wrtbwmon absent; service not restored'; fi
   log 'Original service state restored where possible; no whole-table restore'; exit 0;;
 fix|install) ;;
 *) exit 1;;
esac
if [ ! -s "$W/dirty" ] && [ ! -s "$W/pids" ] && [ ! -s "$W/links" ]; then
 [ ! -s "$W/failed" ] || { cat "$W/failed"; exit 2; }; exit 0
fi
# One durable snapshot, no unlimited flash writes on each recurrence.
if [ ! -d "$BASE/original" ]; then
 mkdir "$W/original"
 if [ -x "$INIT" ] && "$INIT" enabled; then echo 1; else echo 0; fi > "$W/original/enabled"
 if [ -s "$W/pids" ]; then echo 1; else echo 0; fi > "$W/original/running"
 cp "$W/links" "$W/original/links"
 for f in "$W"/*.save /tmp/usage.db /tmp/usage.46.db /tmp/usage.6.db; do [ ! -f "$f" ] || cp -p "$f" "$W/original/"; done
 cp -a "$W/original" "$BASE/original.new.$$"; mv "$BASE/original.new.$$" "$BASE/original"
fi
if [ -x "$INIT" ]; then "$INIT" disable || { log 'Disable failed'; exit 1; }; if command -v timeout >/dev/null; then timeout 8 "$INIT" stop || log 'Stop timed out; checking processes'; else "$INIT" stop || log 'Stop returned nonzero; checking processes'; fi; fi
# Delete only matching wrtbwmon boot links, including dangling symlinks.
while IFS= read -r f; do
 [ -L "$f" ] || continue
 case "$(readlink "$f")" in ../init.d/wrtbwmon|/etc/init.d/wrtbwmon) rm -f "$f";; *) log "Unknown link target: $f; retained";; esac
done < "$W/links"
pids > "$W/pids"
if [ -s "$W/pids" ]; then
 while read -r p; do pids | grep -Fxq "$p" || continue; kill -TERM "$p" 2>/dev/null || :; kill -CONT "$p" 2>/dev/null || :; done < "$W/pids"
 sleep 2
 pids > "$W/pids"
 while read -r p; do pids | grep -Fxq "$p" || continue; kill -KILL "$p" 2>/dev/null || :; done < "$W/pids"
 sleep 1
fi
if [ -n "$(pids)" ]; then log 'Process still present; refusing cleanup'; exit 1; fi
scan
rc=0
[ ! -s "$W/failed" ] || { cat "$W/failed"; rc=2; }
# Snapshot every recurrence in /tmp only, overwrite previous one.
for c in $(cat "$W/dirty"); do
  command -v "$c" >/dev/null || { log "$c missing"; rc=2; continue; }
  # Re-read since nft and default aliases can point to same ruleset.
  "$c-save" > "$W/current" || { rc=2; continue; }
  if ! plan "$W/current" > "$W/current.plan"; then log "$c unknown RRDIPT references: not removed"; rc=2; continue; fi
  [ -s "$W/current.plan" ] || continue
  cp "$W/current" "/tmp/tgeek-rrd-last-$c.save"
  ok=1
  for ch in INPUT FORWARD OUTPUT; do
    n=0
    while "$c" -w 5 -t mangle -C "$ch" -j "RRDIPT_$ch" 2>/dev/null; do
       if [ "$n" -ge 100 ] || ! "$c" -w 5 -t mangle -D "$ch" -j "RRDIPT_$ch"; then ok=0; break; fi
       n=$((n+1))
    done
  done
  [ "$ok" = 1 ] || { rc=2; continue; }
  for ch in INPUT FORWARD OUTPUT; do
    if "$c" -w 5 -t mangle -S "RRDIPT_$ch" >/dev/null 2>&1; then
      if ! "$c" -w 5 -t mangle -F "RRDIPT_$ch" || ! "$c" -w 5 -t mangle -X "RRDIPT_$ch"; then rc=2; fi
    fi
  done
  log "Cleaned known $c RRDIPT chains"
done
scan
if [ -s "$W/dirty" ] || [ -s "$W/failed" ]; then log 'WARN: residual or unverifiable rules'; cat "$W/dirty" "$W/failed"; rc=2; else log 'PASS: RRDIPT removed; unrelated rules untouched'; fi
exit "$rc"

TGEEK_V145_RRD
cat > "$W/oaf-helper" <<'TGEEK_V146_OAF'
#!/bin/sh
# TGEEK OAF LuCI compatibility V1.4.8
set -eu
umask 077
B=/root/tgeek-firewall-fix-v1.3/time-guard/oaf146
STATE=/tmp/tgeek-oaf-v146
CTL=/usr/lib/lua/luci/controller/appfilter.lua
VIEW=/usr/lib/lua/luci/view/admin_network/app_filter.htm
HELP=/usr/libexec/tgeek-oaf-compat
ACTION=${1:-status}; shift || :
log(){ echo "[TGEEK OAF] $*"; }
fail(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'root required'
get(){ uci -q get "$1" || :; }
mode(){ [ "$(get appfilter.global.tgeek_all_apps)" = 1 ] && echo 1 || echo 0; }
[ -f /etc/config/appfilter ] || { case "$ACTION" in sync|status|verify) log 'SKIP: OAF not installed'; exit 0;; *) fail 'OAF not installed';; esac; }
mkdir -p "$STATE"
exec 9>"$STATE/lock"; flock -n 9 || exit 75
W=$(mktemp -d /tmp/tgeek-oaf146.XXXXXX)
TIMELOCK=/var/lock/oaf-time-sync
TIMEOWN=0
cleanup(){ if [ "$TIMEOWN" = 1 ] && [ "$(cat "$TIMELOCK/pid" 2>/dev/null || :)" = "$$" ]; then rm -f "$TIMELOCK/pid"; rmdir "$TIMELOCK" 2>/dev/null || :; fi; rm -rf "$W"; }
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
mkdir "$W/uci"
# Read/write private UCI staging; never commit pending LuCI edits.
u(){ uci -t "$W/uci" "$@"; }
# Separate validation from pipelines to ensure invalid input is rejected.
normalize(){ tr ' ,\t' '\n\n\n' > "$W/raw"; awk 'NF{if($0!~/^[1-9][0-9]*$/ || $0>65535)bad=1; else print $0} END{if(bad)exit 1}' "$W/raw" > "$W/valid" || return 1; sort -nu "$W/valid"; }
catalog(){
 [ -s /tmp/feature.cfg ] || return 1
 cp /tmp/feature.cfg "$W/feature" || return 1
 awk '/^[0-9]+[ \t]+[^:]+:\[/ {if($1!~/^[1-9][0-9]*$/ || $1>65535 || seen[$1]++)bad=1; print $1} END{if(bad || !NR)exit 1}' "$W/feature" > "$W/catalog.raw" || return 1
 sort -nu "$W/catalog.raw" > "$W/catalog"
 [ -s "$W/catalog" ] && [ "$(wc -l < "$W/catalog")" -le 4096 ] || return 1
}
current(){ u -q get appfilter.rule.app_list | normalize; }
# Read a committed option directly using isolated staging before edits.
ug(){ u -q get "$1" || :; }
setlist(){ key=$1; file=$2; u -q delete "$key" >/dev/null 2>&1 || :; if [ -s "$file" ]; then awk -v k="$key" '{print "add_list " k "=" $1}' "$file" > "$W/batch"; u batch < "$W/batch" >/dev/null; fi; }
status(){
 echo "mode=$(mode) disable_quic=$(get appfilter.global.disable_quic) enable=$(get appfilter.global.enable)"
 if catalog; then echo "feature_ids=$(wc -l < "$W/catalog")"; fi
 current > "$W/current"; echo "configured_ids=$(wc -l < "$W/current")"
 [ ! -f "$STATE/last" ] || cat "$STATE/last"
 if [ -f "$B/installed" ]; then echo 'luci_patch=installed'; else echo 'luci_patch=not-installed'; fi
}
read_rpc(){
 timeout 5 ubus call appfilter get_app_filter '{}' > "$W/rpc" 2>/dev/null || return 1
 # Empty list accepted only if the JSON contains app_list; reject malformed response.
 grep -q '"app_list"[[:space:]]*:' "$W/rpc" || return 1
 jsonfilter -i "$W/rpc" -e '@.app_list[*]' > "$W/rpc.raw" 2>/dev/null || [ ! -s "$W/rpc.raw" ] || return 1
 normalize < "$W/rpc.raw" > "$W/rpc.ids" || return 1
 cmp -s "$W/expected" "$W/rpc.ids" || return 1
 timeout 5 ubus call appfilter get_app_filter_base '{}' > "$W/base" 2>/dev/null || return 1
 for k in enable work_mode record_enable; do
   actual=$(jsonfilter -i "$W/base" -e "@.data.$k" 2>/dev/null || :)
   [ "$actual" = "$(get appfilter.global.$k)" ] || return 1
 done
}
reload_oaf(){
 timeout 20 /etc/init.d/appfilter restart > "$W/restart.log" 2>&1 || return 1
 i=0; while [ "$i" -lt 5 ]; do if read_rpc; then return 0; fi; i=$((i+1)); sleep 1; done
 return 1
}
# Roll back only the transaction's own snapshot when no concurrent edit is detected.
restore(){
 if [ -f "$W/committed" ] && cmp -s "$W/committed" /etc/config/appfilter; then
   cp -p "$W/original" /etc/config/appfilter.tgeek-restore.$$ && mv -f /etc/config/appfilter.tgeek-restore.$$ /etc/config/appfilter || return 1
   timeout 20 /etc/init.d/appfilter restart >/dev/null 2>&1 || return 1
   return 0
 fi
 return 1
}
finish_apply(){
 # Avoid overwriting simultaneous external changes or pending staging.
 [ -z "$(uci changes appfilter)" ] && cmp -s "$W/original" /etc/config/appfilter || fail 'Concurrent or pending UCI changes; retry'
 if [ -z "$(u changes appfilter)" ]; then read_rpc || fail 'Unchanged UCI but RPC readback failed'; log 'No changes; RPC verified'; return 0; fi
 cp -p "$W/original" "$B/last-transaction.appfilter.new"
 mv -f "$B/last-transaction.appfilter.new" "$B/last-transaction.appfilter"
 if ! u commit appfilter; then fail 'UCI commit failed'; fi
 cp -p /etc/config/appfilter "$W/committed"
 if ! current > "$W/check" || ! cmp -s "$W/check" "$W/expected"; then restore || log 'WARN: automatic restore failed'; fail 'UCI app_list readback failed'; fi
 for kv in "$@"; do key=${kv%%=*}; value=${kv#*=}; if [ "$(get "$key")" != "$value" ]; then restore || log 'WARN: automatic restore failed'; fail "UCI readback failed: $key"; fi; done
 # Restart only on actual changes, not on every periodic tick.
 if ! reload_oaf; then restore || log 'WARN: automatic restore failed'; fail 'OAF restart/RPC readback failed; check original config backup'; fi
 printf 'last_apply=ok epoch=%s ids=%s\n' "$(date +%s)" "$(wc -l < "$W/expected")" > "$STATE/last"
 log 'PASS: UCI and OAF RPC readback match (not proof of DPI traffic coverage)'
}
case "$ACTION" in
 status) status; exit 0;;
 verify)
  status; [ -f "$B/installed" ] || fail 'LuCI patch not installed'
  sha256sum -c "$B/patched.sha256" || fail 'LuCI files changed; do not overwrite automatically'
  current > "$W/expected"; if [ "$(mode)" = 1 ]; then catalog || fail 'Invalid feature catalog'; cmp -s "$W/expected" "$W/catalog" || fail 'All-app list differs from feature catalog'; fi
  read_rpc || fail 'OAF RPC readback differs'; log 'PASS: LuCI patch and OAF RPC'; exit 0;;
 base|list|sync) ;;
 *) fail 'base | list | sync | status | verify';;
esac
# Sync only if the explicitly installed compatibility layer is owned and active.
[ -f "$B/installed" ] || { [ "$ACTION" = sync ] && exit 0; fail 'LuCI patch not installed'; }
[ "$ACTION" != sync ] || [ "$(mode)" = 1 ] || exit 0
sha256sum -c "$B/patched.sha256" >/dev/null 2>&1 || fail 'LuCI patch changed; run luci-status'
[ -z "$(uci changes appfilter)" ] || fail 'Commit/revert pending appfilter changes first'
[ "$(ug appfilter.global)" = global ] && [ "$(ug appfilter.rule)" = rule ] || fail 'Unsupported OAF config layout'
# Serialize mutations with the independent weekday synchronizer.
mkdir -p /var/lock
if ! mkdir "$TIMELOCK" 2>/dev/null; then log '时间规则正在同步，请稍后重试'; exit 75; fi
printf '%s\n' "$$" > "$TIMELOCK/pid" || { rmdir "$TIMELOCK" 2>/dev/null || :; fail '无法建立时间同步锁'; }
TIMEOWN=1
cp -p /etc/config/appfilter "$W/original"
current > "$W/old" || fail 'Invalid current app list'
oldmode=$(mode)
case "$ACTION" in
 base)
  [ "$#" = 5 ] || fail 'Expected five settings'
  for v in "$@"; do case "$v" in 0|1) ;; *) fail 'Invalid setting';; esac; done
  en=$1; work=$2; rec=$3; quic=$4; newmode=$5
  if [ "$newmode" = 1 ]; then
    catalog || fail 'Invalid feature catalog'
    if [ "$oldmode" != 1 ]; then setlist appfilter.rule.tgeek_specific "$W/old"; u set appfilter.rule.tgeek_specific_saved=1; fi
    cp "$W/catalog" "$W/expected"
  elif [ "$oldmode" = 1 ]; then
    [ "$(ug appfilter.rule.tgeek_specific_saved)" = 1 ] || fail 'Original specific selection missing'
    ug appfilter.rule.tgeek_specific | normalize > "$W/expected" || fail 'Invalid saved selection'
  else cp "$W/old" "$W/expected"; fi
  if ! cmp -s "$W/old" "$W/expected"; then setlist appfilter.rule.app_list "$W/expected"; fi
  for kv in "enable=$en" "work_mode=$work" "record_enable=$rec" "disable_quic=$quic" "tgeek_all_apps=$newmode"; do
    k=${kv%%=*}; v=${kv#*=}; [ "$(ug appfilter.global.$k)" = "$v" ] || u set "appfilter.global.$kv"
  done
  finish_apply "appfilter.global.enable=$en" "appfilter.global.work_mode=$work" "appfilter.global.record_enable=$rec" "appfilter.global.disable_quic=$quic" "appfilter.global.tgeek_all_apps=$newmode";;
 list)
  [ "$#" = 1 ] || fail 'Expected application ID list'
  # In all mode the original web page may send a stale checkbox list after base save.
  if [ "$oldmode" = 1 ]; then
    catalog || fail 'Invalid feature catalog'
    cp "$W/catalog" "$W/expected"
    cmp -s "$W/old" "$W/expected" && read_rpc || fail 'All-app list is not synchronized'
    log 'All mode: verified effective list; ignore stale checkbox list'; exit 0
  fi
  printf '%s\n' "$1" | normalize > "$W/expected" || fail 'Invalid application ID list'
  catalog || fail 'Invalid feature catalog'
  awk 'FILENAME==ARGV[1]{a[$1]=1;next}!($1 in a){bad=1}END{exit bad}' "$W/catalog" "$W/expected" || fail 'Unknown application ID'
  cmp -s "$W/old" "$W/expected" || setlist appfilter.rule.app_list "$W/expected"
  finish_apply;;
 sync)
  catalog || fail 'Invalid feature catalog'
  cp "$W/catalog" "$W/expected"
  cmp -s "$W/old" "$W/expected" && exit 0
  # Prevent repeated service restarts on a persistent incompatibility.
  hash=$(sha256sum < "$W/feature"); now=$(date +%s)
  if [ -f "$STATE/sync.attempt" ]; then read -r when oldhash rest < "$STATE/sync.attempt" || :; case "${when:-}" in ''|*[!0-9]*) when=0;; esac; [ "${oldhash:-}" != "${hash%% *}" ] || [ "$((now-when))" -ge 300 ] || exit 0; fi
  printf '%s %s\n' "$now" "${hash%% *}" > "$STATE/sync.attempt"
  setlist appfilter.rule.app_list "$W/expected"; finish_apply;;
esac
TGEEK_V146_OAF
cat > "$W/oaf-patcher" <<'TGEEK_V146_LUA'
-- TGEEK V1.4.8 patch generator: only known legacy controller + view shapes.
local function read(p)
 local f=assert(io.open(p,'rb')); local s=f:read('*a'); f:close(); return s
end
local function write(p,s)
 local f=assert(io.open(p,'wb')); assert(f:write(s)); assert(f:close())
end
local ctl,view,out=arg[1],arg[2],arg[3]
local c,v=read(ctl),read(view)
assert(not c:find('TGEEK_OAF_V146',1,true),'controller already patched')
assert(c:find('function set_app_filter_base()',1,true) and c:find('function get_app_filter_base()',1,true) and c:find('function set_app_filter()',1,true) and c:find('function get_app_filter()',1,true),'unsupported controller shape')
for _,x in ipairs({'luci.http.formvalue("disable_quic")','luci.http.formvalue("app_filter_mode")','"get_app_filter_base"','"set_app_filter_base"','"set_app_filter"'}) do assert(c:find(x,1,true),'missing controller anchor '..x) end
for _,x in ipairs({'app_filter_mode: appFilterMode','disable_quic: quicProtocol','data.data.app_filter_mode','data.data.disable_quic','app_list: selectedAppsStr'}) do assert(v:find(x,1,true),'missing view anchor '..x) end
-- Append overrides inside the existing controller module. The original index and routes remain intact.
c=c..[=[

-- TGEEK_OAF_V146 BEGIN
local tgeek146_native_get_list = get_app_filter
local function tgeek146_cursor()
    return require("luci.model.uci").cursor()
end
local function tgeek146_reply(ok, msg)
    luci.http.prepare_content("application/json")
    luci.http.write_json({ok=ok, message=msg})
end
local function tgeek146_run(action, params)
    local command = "/usr/libexec/tgeek-oaf-compat " .. action
    for _,p in ipairs(params) do
        -- No unvalidated user text is ever passed to the shell.
        if type(p) ~= "string" or not p:match("^[0-9,]*$") then return false end
        command = command .. " '" .. p .. "'"
    end
    return require("luci.sys").call(command .. " >/tmp/tgeek-oaf-v146-luci.last 2>&1") == 0
end
function get_app_filter_base()
    local cursor=tgeek146_cursor()
    local ok, resp=pcall(utl.ubus,"appfilter","get_app_filter_base",{})
    if not ok or type(resp)~="table" or type(resp.data)~="table" then
        luci.http.prepare_content("application/json")
        luci.http.write_json({ok=false,message="OAF RPC unavailable"}); return
    end
    resp.data.disable_quic=tonumber(cursor:get("appfilter","global","disable_quic"))==1 and 1 or 0
    resp.data.app_filter_mode=tonumber(cursor:get("appfilter","global","tgeek_all_apps"))==1 and 1 or 0
    luci.http.prepare_content("application/json")
    luci.http.write_json(resp)
end
function set_app_filter_base()
    local params={}
    for _,k in ipairs({"enable","work_mode","record_enable","disable_quic","app_filter_mode"}) do
        local val=luci.http.formvalue(k)
        if val~="0" and val~="1" then tgeek146_reply(false,"Invalid setting: "..k); return end
        params[#params+1]=val
    end
    local ok=tgeek146_run("base",params)
    tgeek146_reply(ok,ok and "Settings verified" or "Save failed; see /tmp/tgeek-oaf-v146-luci.last")
end
function set_app_filter()
    local val=luci.http.formvalue("app_list")
    if type(val)~="string" or #val>30000 or not val:match("^[0-9,]*$") or val:find(",,") or val:match("^,") or val:match(",$") then
        tgeek146_reply(false,"Invalid application IDs"); return
    end
    local ok=tgeek146_run("list",{val})
    tgeek146_reply(ok,ok and "Application list verified" or "Save failed; see /tmp/tgeek-oaf-v146-luci.last")
end
function get_app_filter()
    local cursor=tgeek146_cursor()
    if tonumber(cursor:get("appfilter","global","tgeek_all_apps"))~=1 then return tgeek146_native_get_list() end
    -- Keep the original checkbox selection in the UI while all mode is active.
    -- The actual effective list remains appfilter.rule.app_list.
    local raw=cursor:get_list("appfilter","rule","tgeek_specific") or {}
    local result={}
    for _,id in ipairs(raw) do if tonumber(id) then result[#result+1]=tonumber(id) end end
    luci.http.prepare_content("application/json")
    if #result==0 then luci.http.write('{"app_list":[],"tgeek_all_apps":1}') else luci.http.write_json({app_list=result,tgeek_all_apps=1}) end
end
-- TGEEK_OAF_V146 END
]=]
local function inject(anchor)
 local pos,stop=v:find(anchor,1,true); assert(pos and not v:find(anchor,stop+1,true),'ambiguous view callback '..anchor)
 local pre=v:sub(1,pos-1); assert(pre:match('function%s*%(x,%s*data%)%s*{%s*$'),'unexpected callback shape '..anchor)
 local guard='if (!x || x.status !== 200 || !data || data.ok !== true) { alert((data && data.message) || "OAF save failed; check TGEEK log"); return; }\n                '
 v=pre..guard..v:sub(pos)
end
inject('console.log("set ok");')
inject('console.log("Base filter settings updated");')
local old='In this mode, after the rule takes effect, all apps will be unable to connect to the network, similar to scheduled internet disconnection'
local a,b=v:find(old,1,true)
if a then v=v:sub(1,a-1)..'All recognized applications in the current feature library are filtered; unknown traffic and router management are not intentionally blocked'..v:sub(b+1) end
-- Add an explicit explanation independent of translations.
local tag='<!-- TGEEK_OAF_V146: all mode means all feature IDs, not device disconnection -->'
v=v..'\n'..tag..'\n'
assert(loadfile(ctl),'original Lua controller syntax invalid')
write(out..'/controller',c); write(out..'/view',v)
assert(loadfile(out..'/controller'),'patched Lua syntax invalid')
TGEEK_V146_LUA
cat > "$W/time-model" <<'TGEEK_V147_TIME_MODEL'
local M = {}
local json = require 'luci.jsonc'
local fs = require 'nixio.fs'
local util = require 'luci.util'
local nixio = require 'nixio'

local STATE = '/etc/oaf-time-sync.json'
local LOCK = '/var/lock/oaf-time-sync'

local function copy(value)
    return json.parse(json.stringify(value))
end

local function sorted_days(value)
    if type(value) ~= 'table' then error('星期列表无效') end
    local result, seen = {}, {}
    for _, day in ipairs(value) do
        day = tonumber(day)
        if not day or day % 1 ~= 0 or day < 0 or day > 6 then
            error('星期必须为 0–6（周日为 0）')
        end
        if not seen[day] then
            seen[day] = true
            result[#result + 1] = day
        end
    end
    table.sort(result)
    return result
end

local function minute(value)
    if type(value) ~= 'string' then error('时间无效') end
    local hour, min = value:match('^(%d%d):(%d%d)$')
    hour, min = tonumber(hour), tonumber(min)
    if not hour or hour > 23 or not min or min > 59 then
        error('时间格式应为 HH:MM')
    end
    return hour * 60 + min
end

function M.validate(request)
    if type(request) ~= 'table' or tonumber(request.mode) ~= 0 then
        error('仅固定时间模式使用独立星期规则')
    end
    if type(request.time_list) ~= 'table' or #request.time_list < 1 or #request.time_list > 64 then
        error('请添加 1–64 个时间段')
    end

    local result = { mode = 0, weekday_list = {}, time_list = {} }
    local union = {}
    for _, item in ipairs(request.time_list) do
        if type(item) ~= 'table' then error('时间段格式无效') end
        local weekdays = sorted_days(item.weekday_list)
        if #weekdays == 0 then error('每段至少选择一个星期') end
        if minute(item.start) >= minute(item['end']) then
            error('结束时间须晚于开始时间；跨午夜请拆成两段')
        end
        for _, day in ipairs(weekdays) do union[day] = true end
        result.time_list[#result.time_list + 1] = {
            start = item.start,
            ['end'] = item['end'],
            weekday_list = weekdays
        }
    end
    for day = 0, 6 do
        if union[day] then result.weekday_list[#result.weekday_list + 1] = day end
    end
    return result
end

function M.compile(request, weekday)
    local ranges, seen = {}, {}
    for _, item in ipairs(request.time_list) do
        for _, day in ipairs(item.weekday_list) do
            if day == weekday then
                local key = item.start .. '-' .. item['end']
                if not seen[key] then
                    seen[key] = true
                    ranges[#ranges + 1] = { start = item.start, ['end'] = item['end'] }
                end
                break
            end
        end
    end
    table.sort(ranges, function(a, b)
        return a.start .. a['end'] < b.start .. b['end']
    end)

    if #ranges == 0 then
        -- Native OAF expects a non-empty interval list. Use yesterday as a non-matching weekday.
        return {
            mode = 0,
            weekday_list = { (weekday + 6) % 7 },
            time_list = { { start = '00:00', ['end'] = '23:59' } }
        }
    end
    return { mode = 0, weekday_list = { weekday }, time_list = ranges }
end

local function signature(value)
    local ranges = {}
    for _, item in ipairs(value.time_list or {}) do
        ranges[#ranges + 1] = tostring(item.start) .. '-' .. tostring(item['end'])
    end
    table.sort(ranges)
    return tostring(value.mode) .. '|' .. table.concat(sorted_days(value.weekday_list or {}), ',') .. '|' .. table.concat(ranges, ',')
end

local function raw_get()
    local result = util.ubus('appfilter', 'get_app_filter_time', {})
    if type(result) ~= 'table' or type(result.data) ~= 'table' then
        error('无法读取原生 appfilter 时间配置')
    end
    return result
end

local function apply(payload)
    local before = raw_get().data
    if signature(before) == signature(payload) then return true end
    local result = util.ubus('appfilter', 'set_app_filter_time', payload)
    if type(result) ~= 'table' or (result.code ~= nil and tonumber(result.code) ~= 0) then
        error('原生 appfilter 拒绝时间设置')
    end
    if signature(raw_get().data) ~= signature(payload) then
        error('原生 appfilter 读回核对失败')
    end
    return true
end

local function load_state()
    local content = fs.readfile(STATE)
    if not content then return nil end
    local decoded = json.parse(content)
    if type(decoded) ~= 'table' then error('规则文件无法解析') end
    return M.validate(decoded)
end

local function save_state(request)
    local temp = STATE .. '.new'
    assert(fs.writefile(temp, json.stringify(request)), '规则写入失败')
    assert(fs.rename(temp, STATE), '规则文件原子替换失败')
end

local function locked(callback)
    if not fs.mkdir(LOCK) then
        local owner = tonumber(fs.readfile(LOCK .. '/pid') or '')
        local stat = fs.stat(LOCK)
        local stale = owner and not nixio.kill(owner, 0)
        if not owner and stat and os.time() - stat.mtime > 30 then stale = true end
        if stale then
            fs.unlink(LOCK .. '/pid')
            fs.rmdir(LOCK)
        end
        if not stale or not fs.mkdir(LOCK) then
            return nil, '时间规则正在同步，请稍后重试'
        end
    end
    if not fs.writefile(LOCK .. '/pid', tostring(nixio.getpid())) then
        fs.rmdir(LOCK)
        return nil, '无法创建同步锁'
    end
    local ok, value = pcall(callback)
    fs.unlink(LOCK .. '/pid')
    fs.rmdir(LOCK)
    if not ok then return nil, tostring(value) end
    return value
end

function M.sync()
    return locked(function()
        local request = load_state()
        if request then apply(M.compile(request, tonumber(os.date('%w')))) end
        return true
    end)
end

function M.get()
    local result, err = locked(function()
        local request = load_state()
        if not request then return raw_get() end
        apply(M.compile(request, tonumber(os.date('%w'))))
        local response = raw_get()
        response.data.mode = 0
        response.data.time_list = copy(request.time_list)
        response.data.weekday_list = copy(request.weekday_list)
        response.data.time_sync_compat = 1
        return response
    end)
    return result or { code = -1, message = err }
end

function M.set(request)
    local result, err = locked(function()
        if type(request) ~= 'table' then error('提交内容无效') end
        if tonumber(request.mode) ~= 0 then
            local native = util.ubus('appfilter', 'set_app_filter_time', request)
            if type(native) ~= 'table' or (native.code ~= nil and tonumber(native.code) ~= 0) then
                error('原生时间模式保存失败')
            end
            if tonumber(raw_get().data.mode) ~= tonumber(request.mode) then
                error('模式切换读回核对失败')
            end
            if fs.access(STATE) then assert(fs.unlink(STATE), '清理固定时间规则失败') end
            return { code = 0, message = '已切换原生时间模式' }
        end

        local validated = M.validate(request)
        local before = raw_get().data
        local old_state = fs.readfile(STATE)
        local ok, why = pcall(function()
            save_state(validated)
            apply(M.compile(validated, tonumber(os.date('%w'))))
        end)
        if not ok then
            if old_state then
                fs.writefile(STATE, old_state)
            else
                fs.unlink(STATE)
            end
            local restored = pcall(apply, before)
            error(tostring(why) .. (restored and '；原生时间配置已尝试还原' or '；警告：原生配置回滚未确认'))
        end
        return { code = 0, message = '时间规则已保存，当天规则已同步并读回核对' }
    end)
    return result or { code = -1, message = err }
end

M.signature = signature
return M
TGEEK_V147_TIME_MODEL
cat > "$W/time-front" <<'TGEEK_V147_TIME_FRONT'
/* TGEEK OAF TIME SYNC V2.1.1 BEGIN */
(function () {
    'use strict';

    var originalSubmit = submitHandle;
    var originalGetTimeFormData = getTimeFormData;
    var originalRenderTimeData = renderTimeData;
    var busy = false;
    var dayOrder = [1, 2, 3, 4, 5, 6, 0];

    function getBody() {
        return document.getElementById('timeTableBody');
    }

    function getRows() {
        var body = getBody();
        return body ? Array.prototype.slice.call(body.rows).filter(function (row) {
            return row.querySelector('.start-time') && row.querySelector('.end-time');
        }) : [];
    }

    /*
     * V2.1.1: reuse the original OAF weekday controls in the first table cell.
     * Do not append a new TH/TD and do not create a second weekday column.
     * The original labels, order, CSS and horizontal layout remain untouched.
     */
    function legacyWeekdayInputs(row) {
        if (!row || !row.cells || !row.cells.length) return [];
        var cell = row.cells[0];
        var inputs = cell.querySelectorAll('input[name="weekday"]');
        if (!inputs || inputs.length !== 7) {
            inputs = cell.querySelectorAll('input[type="checkbox"]');
        }

        var byDay = {};
        Array.prototype.forEach.call(inputs, function (input) {
            var value = Number(input.value);
            if (value >= 0 && value <= 6 && Math.floor(value) === value && !byDay[value]) {
                byDay[value] = input;
            }
        });

        return dayOrder.map(function (day) { return byDay[day]; }).filter(Boolean);
    }

    function rowHasLegacyWeekdays(row) {
        var inputs = legacyWeekdayInputs(row);
        return inputs.length === 7;
    }

    function selectedDays(row) {
        return legacyWeekdayInputs(row).filter(function (input) {
            return input.checked;
        }).map(function (input) {
            return Number(input.value);
        }).sort(function (a, b) { return a - b; });
    }

    function ensureAllRows() {
        var rows = getRows();
        var valid = true;
        rows.forEach(function (row) {
            var inputs = legacyWeekdayInputs(row);
            row.setAttribute('data-oaf-v211-weekday-ready', inputs.length === 7 ? '1' : '0');
            if (inputs.length !== 7) valid = false;
        });
        return valid;
    }

    function applyStoredWeekdays() {
        ensureAllRows();
        var rows = getRows();
        var list = (time_data && time_data.time_list) || [];
        var globalDays = (time_data && Array.isArray(time_data.weekday_list)) ?
            time_data.weekday_list.map(Number) : [];

        rows.forEach(function (row, index) {
            var inputs = legacyWeekdayInputs(row);
            if (inputs.length !== 7) return;
            var item = list[index] || {};
            var stored = Array.isArray(item.weekday_list) ? item.weekday_list.map(Number) : globalDays;
            inputs.forEach(function (input) {
                input.checked = stored.indexOf(Number(input.value)) !== -1;
            });
        });
    }

    /* Fixed-time mode reads each row's original weekday controls independently. */
    getTimeFormData = function () {
        var mode = document.getElementById('timeMode').value;
        if (mode !== '0') return originalGetTimeFormData.apply(this, arguments);

        var rows = getRows();
        var list = rows.map(function (row) {
            return {
                start: row.querySelector('.start-time').value,
                end: row.querySelector('.end-time').value,
                weekday_list: selectedDays(row)
            };
        });
        var union = {};
        list.forEach(function (item) {
            item.weekday_list.forEach(function (day) { union[day] = true; });
        });

        return {
            mode: 0,
            weekday_list: Object.keys(union).map(Number).sort(function (a, b) { return a - b; }),
            time_list: list
        };
    };

    function canonical(list) {
        return JSON.stringify((list || []).map(function (item) {
            return [String(item.start), String(item.end), (item.weekday_list || []).map(Number).sort(function (a, b) { return a - b; }).join(',')];
        }).sort(function (a, b) {
            return JSON.stringify(a).localeCompare(JSON.stringify(b));
        }));
    }

    submitHandle = function () {
        if (document.getElementById('timeMode').value !== '0') {
            return originalSubmit.apply(this, arguments);
        }
        if (busy) return;

        var error = document.getElementById('errorContainer');
        var rows = getRows();
        if (!rows.length || !ensureAllRows()) {
            error.textContent = '未找到原版星期控件，请勿保存。请确认使用原生 OAF 时间页面后重试。';
            return;
        }

        var payload = getTimeFormData();
        var list = payload.time_list || [];
        error.textContent = '';

        if (!list.length || list.length > 64) {
            error.textContent = '请添加 1–64 个时间段。';
            return;
        }
        for (var i = 0; i < list.length; i++) {
            var item = list[i];
            if (!item.weekday_list.length || !item.start || !item.end || item.start >= item.end) {
                error.textContent = '每段至少选择一个星期，结束时间须晚于开始时间；跨午夜请拆成两段。';
                return;
            }
        }

        busy = true;
        error.textContent = '正在保存并核对独立星期规则……';
        var timer = setTimeout(function () {
            busy = false;
            error.textContent = '请求超时，请刷新页面核对保存结果。';
        }, 15000);

        function finish(message) {
            clearTimeout(timer);
            busy = false;
            error.textContent = message;
        }

        new XHR().post("<%=url('admin/network/set_app_filter_time')%>",
            { data: JSON.stringify(payload) }, function (x, result) {
                if (!busy) return;
                if (!x || x.status !== 200 || !result || Number(result.code) !== 0) {
                    finish((result && result.message) || '保存失败，请检查后台日志。');
                    return;
                }
                new XHR().get("<%=url('admin/network/get_app_filter_time')%>", null,
                    function (rx, readback) {
                        if (!busy) return;
                        if (!rx || rx.status !== 200 || !readback || !readback.data ||
                            !readback.data.time_sync_compat || Number(readback.data.mode) !== 0 ||
                            canonical(readback.data.time_list) !== canonical(list)) {
                            finish((readback && readback.message) || '读回配置不一致，尚未确认保存成功。');
                            return;
                        }
                        time_data = readback.data;
                        originalRenderTimeData.apply(this, arguments);
                        applyStoredWeekdays();
                        finish('已保存并核对：已沿用原版星期排版，各时间段独立星期已保留。');
                    });
            });
    };

    renderTimeData = function () {
        var result = originalRenderTimeData.apply(this, arguments);
        setTimeout(applyStoredWeekdays, 0);
        return result;
    };

    function init() {
        ensureAllRows();
        applyStoredWeekdays();
        var body = getBody();
        if (body && typeof MutationObserver !== 'undefined') {
            var observer = new MutationObserver(function () {
                ensureAllRows();
            });
            observer.observe(body, { childList: true, subtree: true });
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
/* TGEEK OAF TIME SYNC V2.1.1 END */
TGEEK_V147_TIME_FRONT
cat > "$W/time-runner" <<'TGEEK_V147_TIME_RUNNER'
#!/usr/bin/lua
local module = require 'luci.model.oaf_time_sync'
local nixio = require 'nixio'
local last_error = ''
while true do
    local ok, err = module.sync()
    if not ok and err ~= last_error then
        io.stderr:write(tostring(err or 'unknown sync error') .. '\n')
        io.stderr:flush()
    end
    last_error = ok and '' or tostring(err or '')
    nixio.nanosleep(10)
end
TGEEK_V147_TIME_RUNNER
cat > "$W/time-init" <<'TGEEK_V147_TIME_INIT'
#!/bin/sh /etc/rc.common

START=99
STOP=10
USE_PROCD=1

start_service() {
    procd_open_instance
    procd_set_param command /usr/bin/oaf-time-sync-run
    procd_set_param respawn 3600 5 5
    procd_set_param stderr 1
    procd_close_instance
}
TGEEK_V147_TIME_INIT
cat > "$W/oaf-cn-time" <<'TGEEK_V147_CN_TIME'
local function read(p) local f=assert(io.open(p,'rb')); local s=f:read('*a'); f:close(); return s end
local function write(p,s) local f=assert(io.open(p,'wb')); assert(f:write(s)); assert(f:close()) end
local dir, timepage, frontend, legacy=arg[1],arg[2],arg[3],arg[4]
local c,v,t=read(dir..'/controller'),read(dir..'/view'),read(timepage)
local function literal(s,a,b)
 local x,y=s:find(a,1,true); if not x then return s,0 end
 local n=0; local parts={}; local pos=1
 while x do parts[#parts+1]=s:sub(pos,x-1); parts[#parts+1]=b; n=n+1; pos=y+1; x,y=s:find(a,pos,true) end
 parts[#parts+1]=s:sub(pos); return table.concat(parts),n
end
for _,pair in ipairs({
 {'OAF RPC unavailable','OAF 后台服务暂不可用，请检查服务状态。'},
 {'Invalid setting: ','设置参数无效：'},
 {'Settings verified','设置已保存并核对成功。'},
 {'Save failed; see /tmp/tgeek-oaf-v146-luci.last','保存失败，请检查日志：/tmp/tgeek-oaf-v146-luci.last'},
 {'Invalid application IDs','应用 ID 无效，请刷新特征库后重试。'},
 {'Application list verified','应用名单已保存并核对成功。'}
}) do c=literal(c,pair[1],pair[2]) end
v=literal(v,'OAF save failed; check TGEEK log','保存失败，请检查 TGEEK 日志。')
for _,pair in ipairs({{'Settings saved successfully','设置已保存并核对成功'},{'Settings successful','设置成功'},{'Set successfully','设置成功'},{'Setting successful','设置成功'}}) do v=literal(v,pair[1],pair[2]) end
local explain='在限制时间内，过滤当前特征库中能够识别的所有应用。未知流量及路由器管理连接不主动按应用阻断。开启 QUIC 拦截时，仍会限制受控设备的外网 UDP 443。'
for _,old in ipairs({'All recognized applications in the current feature library are filtered; unknown traffic and router management are not intentionally blocked','In this mode, after the rule takes effect, all apps will be unable to connect to the network, similar to scheduled internet disconnection'}) do v=literal(v,old,explain) end
assert(v:find(explain,1,true),'找不到全应用说明，拒绝修改未知页面')
-- Translate the actual option labels, not just a CSS overlay. Preserve values and attributes.
local n=0
v=v:gsub('(<select[^>]-id%s*=%s*["\']quicProtocol["\'][^>]*>)(.-)(</select%s*>)',function(a,b,z)
 local count0,count1=0,0
 b=b:gsub('(<option[^>]-value%s*=%s*["\']0["\'][^>]*>)(.-)(</option%s*>)',function(x,y,q) count0=count0+1; return x..'关闭（允许 QUIC）'..q end)
 b=b:gsub('(<option[^>]-value%s*=%s*["\']1["\'][^>]*>)(.-)(</option%s*>)',function(x,y,q) count1=count1+1; return x..'开启（限制 QUIC）'..q end)
 assert(count0==1 and count1==1,'QUIC 选项值不匹配'); n=n+1; return a..b..z
end)
assert(n==1,'未找到唯一 QUIC 选项控件')
-- Replace known label translations when present. Option labels are authoritative.
for _,label in ipairs({'Filter QUIC Protocol','Filter QUIC protocol','Filter QUIC','QUIC Protocol Filtering','过滤QUIC协议','过滤 QUIC 协议'}) do v=literal(v,label,'QUIC 协议拦截') end
-- Also append a visible Chinese explanation adjacent to the select; use independent marker.
if not v:find('TGEEK_QUIC_CN_V147',1,true) then
 local n2=0
 v=v:gsub('(<select[^>]-id%s*=%s*["\']quicProtocol["\'][^>]*>.-</select%s*>)',function(x) n2=n2+1; return x..'<span id="TGEEK_QUIC_CN_V147" style="display:block;color:#666;font-size:12px;">开启后，仅在 OAF 限制时段对受控设备限制外网 UDP 443（含 QUIC）；其他依赖该协议的应用可能受影响。</span>' end)
 assert(n2==1,'QUIC 中文说明插入失败')
end
if legacy~='1' then
 assert(not c:find('oaf_time_sync',1,true),'发现未知或半安装的时间补丁')
 for _,a in ipairs({'function set_app_filter_time','function get_app_filter_time'}) do assert(c:find(a,1,true),'原生时间接口缺失：'..a) end
 for _,a in ipairs({'function getTimeFormData','function renderTimeData','timeTableBody','start-time','end-time','submitHandle','timeMode','errorContainer','time_data'}) do assert(t:find(a,1,true),'时间页面不兼容：'..a) end
 assert(not t:find('TGEEK OAF',1,true),'发现未知时间页面补丁')
 local pos=assert(t:find('//]]></script>',1,true),'时间页面脚本结束标记不存在')
 t=t:sub(1,pos-1)..'\n'..read(frontend)..'\n'..t:sub(pos)
 c=c..[=[

-- TGEEK_OAF_TIME_V147 BEGIN
function set_app_filter_time()
    local json = require 'luci.jsonc'
    luci.http.prepare_content('application/json')
    local req = json.parse(luci.http.formvalue('data') or '')
    if type(req) ~= 'table' then luci.http.write_json({code=-1,message='提交内容无效'}); return end
    luci.http.write_json(require('luci.model.oaf_time_sync').set(req))
end
function get_app_filter_time()
    luci.http.prepare_content('application/json')
    luci.http.write_json(require('luci.model.oaf_time_sync').get())
end
-- TGEEK_OAF_TIME_V147 END
]=]
else
 assert(c:find('luci.model.oaf_time_sync',1,true) and t:find('TGEEK OAF TIME SYNC V2.1.1 BEGIN',1,true),'既有时间补丁不完整')
end
assert(c:find('TGEEK_OAF_V146',1,true),'缺少应用过滤兼容层')
assert((loadstring or load)(c), '控制器语法检查失败')
write(dir..'/controller',c); write(dir..'/view',v); write(dir..'/time',t)
TGEEK_V147_CN_TIME
OB=$BASE/oaf146
OH=/usr/libexec/tgeek-oaf-compat
OC=/usr/lib/lua/luci/controller/appfilter.lua
OV=/usr/lib/lua/luci/view/admin_network/app_filter.htm
OPATCH=0
OT=/usr/lib/lua/luci/view/admin_network/time.htm
OM=/usr/lib/lua/luci/model/oaf_time_sync.lua
OR=/usr/bin/oaf-time-sync-run
OI=/etc/init.d/oaf-time-sync
OS=/etc/oaf-time-sync.json
# One shared controller, one manifest. Original V146 backup is retained.
# Two verified releases of standalone V2.1.1 differ only in formatting of one Lua call.
# Keep the existing runtime byte-for-byte; never accept arbitrary modified files.
known_time_runtime(){
 if ! cmp -s "$OR" "$W/time-runner" || ! cmp -s "$OI" "$W/time-init"; then
  log '旧时间启动程序或服务定义校验不匹配'; sha256sum "$OM" "$OR" "$OI" >&2; return 1
 fi
 local h
 h=$(sha256sum "$OM" | awk '{print $1}') || return 1
 case "$h" in
  ad6a8137c16f4e0ed36c99d55786067193c6e2b9e69e968d8f7016b0144d27e8) log '识别旧时间模块：V2.1.1 原始版';;
  d9332281945ad177701191fbee1683e82d78783193405c66183c53febd2a9fcc) log '识别旧时间模块：V2.1.1 Linux 打包版';;
  *) log '旧时间 Lua 模块校验不匹配'; sha256sum "$OM" "$OR" "$OI" >&2; return 1;;
 esac
 lua -e "assert(loadfile('$OM'))" || return 1
}
prepare_oaf(){
 if [ ! -f /etc/config/appfilter ]; then log '跳过 OAF：安装原生 OAF 后执行 luci-install'; return 0; fi
 [ -f "$OC" ] && [ -f "$OV" ] && [ -f "$OT" ] || fail '找不到兼容的原生 LuCI 页面；未修改文件'
 command -v lua >/dev/null || fail '缺少 Lua 解释器'
 [ -z "$(uci changes appfilter)" ] || fail '请先保存或撤销未提交的 OAF 配置'
 [ "$(uci -q get appfilter.global)" = global ] && [ "$(uci -q get appfilter.rule)" = rule ] || fail '不支持此 OAF 配置布局'
 if [ -f "$OB/integrated147" ]; then
  sha256sum -c "$OB/patched.sha256" >/dev/null 2>&1 || fail 'LuCI 或时间模块已被外部修改；拒绝覆盖'
  [ -x "$OH" ] && [ -x "$OI" ] || fail '整合模块不完整'; OPATCH=3; return 0
 fi
 lua -e "require('luci.jsonc');require('nixio.fs');require('luci.util');require('nixio');assert(loadfile('$W/time-model'));assert(loadfile('$W/time-runner'))" || fail '缺少时间同步依赖'
 timeout 5 ubus call appfilter get_app_filter_time '{}' > "$W/time-rpc" || fail '原生时间接口不可用'
 grep -q '"data"[[:space:]]*:' "$W/time-rpc" || fail '原生时间接口返回异常'
 mkdir -p "$W/oaf-stage"
 sha256sum "$OC" "$OV" "$OT" > "$W/oaf-stage/original.sha256"
 if [ -f "$OB/installed" ]; then
  sha256sum -c "$OB/patched.sha256" >/dev/null 2>&1 || fail 'V1.4.6 页面已被外部修改；请保留现场，勿直接叠装旧时间补丁'
  [ -x "$OH" ] || fail '原 OAF 兼容程序缺失'
  ob=$(cat "$OB/backup.path"); [ -f "$ob/controller" ] && [ -f "$ob/view" ] || fail '原始 LuCI 备份缺失'
  cp -p "$OC" "$W/oaf-stage/controller"; cp -p "$OV" "$W/oaf-stage/view"; OPATCH=2
 else
  [ ! -e "$OH" ] || fail '存在未受管理的 OAF 兼容程序'
  lua "$W/oaf-patcher" "$OC" "$OV" "$W/oaf-stage" || fail '原生应用页面不兼容，未修改文件'; OPATCH=1
 fi
 LEGACY=0
 UI_LEGACY=0
 if grep -q 'TGEEK OAF TIME SYNC V2.1.1 BEGIN' "$OT"; then
  grep -q 'luci.model.oaf_time_sync' "$OC" || fail '旧时间补丁不完整'
  [ -f "$OM" ] && [ -x "$OR" ] && [ -x "$OI" ] || fail '旧时间模块不完整'
  known_time_runtime || fail '旧时间同步不是已知 V2.1.1；拒绝覆盖'
  if [ "$OPATCH" = 2 ]; then grep -q 'luci.model.oaf_time_sync' "$ob/controller" || fail '旧时间补丁与原 V146 备份顺序不一致'; fi
  LEGACY=1
  UI_LEGACY=1
  sha256sum "$OM" "$OR" "$OI" >> "$W/oaf-stage/original.sha256"
 else
  if [ -e "$OM" ] || [ -e "$OR" ] || [ -e "$OI" ] || [ -e "$OS" ]; then
   # Known standalone runtime with native UI overwritten (e.g. by an OAF update).
   # Never adopt unknown modules, missing components, or half-patched controllers.
   [ -f "$OM" ] && [ -x "$OR" ] && [ -x "$OI" ] || fail '旧时间模块不完整；保留现场'
   known_time_runtime || fail '旧时间模块不是已知 V2.1.1；拒绝覆盖'
   ! grep -q 'oaf_time_sync' "$OC" || fail '旧时间控制器部分残留；拒绝覆盖'
   ! grep -q 'TGEEK OAF' "$OT" || fail '旧时间页面部分残留；拒绝覆盖'
   if [ -e "$OS" ]; then
    [ -f "$OS" ] && lua -e "local f=require('nixio.fs');local j=require('luci.jsonc');local m=require('luci.model.oaf_time_sync');assert(m.validate(j.parse(assert(f.readfile('$OS')))))" || fail '旧独立星期规则无效；保留原文件'
   fi
   LEGACY=2
   sha256sum "$OM" "$OR" "$OI" >> "$W/oaf-stage/original.sha256"
   log '识别到完整 V2.1.1 后台及缺失时间界面：保留后台，恢复 LuCI 时间补丁'
  fi
 fi
 lua "$W/oaf-cn-time" "$W/oaf-stage" "$OT" "$W/time-front" "$UI_LEGACY" || fail '中文/时间页面预检不通过，原文件未修改'
 log '通过：OAF 中文界面与独立星期预检'
}
clear_luci(){ rm -f /tmp/luci-indexcache; rm -rf /tmp/luci-modulecache; }
replace_file(){ src=$1; dst=$2; perm=$3; cp "$src" "$dst.tgeek147.$$" && chmod "$perm" "$dst.tgeek147.$$" && mv -f "$dst.tgeek147.$$" "$dst"; }
apply_oaf(){
 [ "$OPATCH" != 0 ] || return 0
 [ "$OPATCH" != 3 ] || { log 'OAF 中文与时间整合已安装'; return 0; }
 mkdir -p /tmp/tgeek-oaf-v146
 exec 8>/tmp/tgeek-oaf-v146/lock
 local retries=0
 until flock -n 8; do retries=$((retries+1)); [ "$retries" -lt 15 ] || fail 'OAF 设置正在保存，请稍后重试'; sleep 1; done
 sha256sum -c "$W/oaf-stage/original.sha256" >/dev/null 2>&1 || fail '预检后文件发生变化，拒绝覆盖'
 mkdir -p "$OB"
 local txn="$OB/integration-$(date +%Y%m%d-%H%M%S)-$$"
 mkdir "$txn"
 cp -p "$OC" "$txn/controller"; cp -p "$OV" "$txn/view"; cp -p "$OT" "$txn/time"; cp -p /etc/config/appfilter "$txn/appfilter"
 if [ "$OPATCH" = 2 ]; then cp -p "$OH" "$txn/helper"; cp -p "$OB/patched.sha256" "$txn/manifest"; cp -p "$OB/backup.path" "$txn/backup.path"; fi
 if [ "$LEGACY" != 0 ]; then "$OI" enabled && touch "$txn/time-enabled" || :; "$OI" status >/dev/null 2>&1 && touch "$txn/time-running" || :; fi
 # Save current independent plan for emergency recovery only; never overwrite the live plan.
 if [ -e "$OS" ]; then cp -p "$OS" "$txn/schedule.json" || fail '无法备份独立星期规则'; fi
 local ok=1
 # Only add new time files if no preexisting standalone installation. Existing rules are never rewritten by installer.
 if [ "$LEGACY" = 0 ]; then
  replace_file "$W/time-model" "$OM" 644 && replace_file "$W/time-runner" "$OR" 755 && replace_file "$W/time-init" "$OI" 755 || ok=0
 fi
 if [ "$ok" = 1 ]; then
  replace_file "$W/oaf-helper" "$OH" 755 && replace_file "$W/oaf-stage/controller" "$OC" 644 && replace_file "$W/oaf-stage/view" "$OV" 644 && replace_file "$W/oaf-stage/time" "$OT" 644 || ok=0
 fi
 if [ "$ok" = 1 ]; then
  lua -e "assert(loadfile('$OC'));require('luci.model.oaf_time_sync')" && sha256sum "$OC" "$OV" "$OT" "$OM" "$OR" "$OI" > "$OB/patched.sha256.new" && mv "$OB/patched.sha256.new" "$OB/patched.sha256" || ok=0
 fi
 if [ "$ok" = 1 ]; then
  if [ "$OPATCH" = 1 ]; then printf '%s\n' "$txn" > "$OB/backup.path" || ok=0; fi
  printf '%s\n' "$txn" > "$OB/time-backup.path" && printf '%s\n' "$LEGACY" > "$OB/time-legacy" && touch "$OB/installed" "$OB/integrated147" || ok=0
 fi
 if [ "$ok" = 1 ]; then
  "$OI" enable || ok=0
  if [ "$ok" = 1 ] && ! "$OI" status >/dev/null 2>&1; then "$OI" start && sleep 2 || ok=0; fi
  "$OI" status >/dev/null 2>&1 || ok=0
 fi
 if [ "$ok" != 1 ]; then
  [ ! -x "$OI" ] || "$OI" stop >/dev/null 2>&1 || :
  cp -p "$txn/controller" "$OC"; cp -p "$txn/view" "$OV"; cp -p "$txn/time" "$OT"
  if [ "$LEGACY" = 0 ]; then [ ! -x "$OI" ] || "$OI" disable >/dev/null 2>&1 || :; rm -f "$OM" "$OR" "$OI"; else
   [ -f "$txn/time-enabled" ] || "$OI" disable >/dev/null 2>&1 || :
   [ ! -f "$txn/time-running" ] || "$OI" start >/dev/null 2>&1 || :
  fi
  if [ "$OPATCH" = 2 ]; then cp -p "$txn/helper" "$OH"; cp -p "$txn/manifest" "$OB/patched.sha256"; cp -p "$txn/backup.path" "$OB/backup.path"; else rm -f "$OH" "$OB/installed" "$OB/patched.sha256" "$OB/backup.path"; fi
  rm -f "$OB/integrated147" "$OB/time-backup.path" "$OB/time-legacy"; clear_luci
  fail "中文/时间模块安装失败，已尝试恢复安装前文件；备份=$txn"
 fi
 clear_luci
 exec 8>&-
 log "中文界面与时间同步已整合，备份=$txn；请刷新浏览器"
}
time_status(){
 if [ ! -f "$OB/integrated147" ]; then log '时间同步整合未安装'; return 1; fi
 echo "time_module=V2.1.1 legacy=$(cat "$OB/time-legacy")"
 case "$(cat "$OB/time-legacy")" in 2) echo '迁移模式：保留旧后台，恢复缺失的 LuCI 时间界面';; esac
 [ ! -e "$OS" ] || echo "独立星期规则：$OS"
 [ -e "$OS" ] || echo '独立星期规则：尚未保存（原生时间计划保持不变）'
 "$OI" status
}
time_verify(){
 time_status && sha256sum -c "$OB/patched.sha256" && "$OI" enabled && timeout 5 lua -e "local m=require('luci.model.oaf_time_sync'); local u=require('luci.util'); local j=require('luci.jsonc'); local f=require('nixio.fs'); local r=u.ubus('appfilter','get_app_filter_time',{}); assert(type(r)=='table' and type(r.data)=='table','时间接口异常'); local raw=f.readfile('/etc/oaf-time-sync.json'); if raw then local plan=m.validate(j.parse(raw)); local expected=m.compile(plan,tonumber(os.date('%w'))); assert(m.signature(expected)==m.signature(r.data),'今日规则尚未同步，稍后重试'); end; print('时间接口与当天规则读回正常')" || fail '时间同步自检失败' 
}
rollback_oaf(){
 [ -f "$OB/installed" ] || { log 'OAF LuCI 补丁未安装'; return 0; }
 sha256sum -c "$OB/patched.sha256" >/dev/null 2>&1 || fail 'LuCI 文件已变更，拒绝覆盖'
 local ob; ob=$(cat "$OB/backup.path"); [ -f "$ob/controller" ] && [ -f "$ob/view" ] || fail '原始备份缺失'
 local legacy=1 txn=''
 if [ -f "$OB/integrated147" ]; then
  legacy=$(cat "$OB/time-legacy"); txn=$(cat "$OB/time-backup.path"); [ -f "$txn/time" ] || fail '原时间页面备份缺失'
  # Restoring original UI without its weekly service would silently leave only today's compiled rules.
  if [ "$legacy" != 1 ] && [ -e "$OS" ]; then fail '存在独立星期规则，不能静默退回原生时间计划。请先在时间页面改用原生非固定时间模式并确认，再执行回滚。'; fi
 fi
 if [ -f /etc/config/appfilter ] && [ "$(uci -q get appfilter.global.tgeek_all_apps || :)" = 1 ]; then
  "$OH" base "$(uci -q get appfilter.global.enable)" "$(uci -q get appfilter.global.work_mode)" "$(uci -q get appfilter.global.record_enable)" "$(uci -q get appfilter.global.disable_quic)" 0 || fail '恢复指定应用名单失败，保留兼容层'
 fi
 if [ "$legacy" = 0 ]; then "$OI" stop && "$OI" disable || fail '停止时间服务失败'; fi
 replace_file "$ob/controller" "$OC" 644 && replace_file "$ob/view" "$OV" 644 || fail '恢复原应用页面失败'
 if [ "$legacy" != 1 ]; then replace_file "$txn/time" "$OT" 644 || fail '恢复原时间页面失败'; fi
 if [ "$legacy" = 0 ]; then rm -f "$OM" "$OR" "$OI"; fi
 rm -f "$OB/installed" "$OB/integrated147" "$OB/time-backup.path" "$OB/time-legacy" "$OH"; clear_luci
 log '已恢复原应用界面；原有独立时间同步（如有）保留，现有其他 OAF 配置保留'
}
chmod 755 "$W/core" "$W/smart" "$W/rrd"
core(){ sh "$W/core" "$@"; }
installed(){ [ -f "$BASE/v141.installed" ] && [ -x "$S" ] && [ -x "$R" ] || fail 'V1.4.8 not installed'; }
writeconf(){ printf 'mode=%s\nconnection=%s\n' "$1" "$2" > "$C.new"; mv "$C.new" "$C"; }
confval(){ sed -n "s/^$1=//p" "$C"; }
native(){ uci -q get "firewall.@defaults[0].$1" || :; }
lock(){ exec 7>/tmp/tgeek-v141-install.lock; flock -n 7 || fail 'another operation active'; }
stop_extra(){ [ ! -x "$I" ] || "$I" stop || :; nft delete table inet tgeek_smart_flow_v141 2>/dev/null || :; nft delete table inet tgeek_oaf_cut_v141 2>/dev/null || :; nft delete table inet tgeek_app_precision_v143 2>/dev/null || :; nft delete table inet tgeek_quic_guard_v145 2>/dev/null || :; }
check_native(){ [ -z "$(uci changes firewall)" ] || fail 'Commit or revert pending LuCI changes'; [ "$(native flow_offloading_hw)" != 1 ] || fail 'Disable hardware offloading first'; }
# Restore only the native software setting, never replace the whole current UCI file.
restore_native(){ case "$1" in 0|1) uci set "firewall.@defaults[0].flow_offloading=$1";; '') uci -q delete 'firewall.@defaults[0].flow_offloading' || :;; *) return 1;; esac; uci commit firewall; fw4 check && /etc/init.d/firewall reload; }
set_native_off(){ if [ "$(native flow_offloading)" = 1 ]; then uci set 'firewall.@defaults[0].flow_offloading=0'; uci commit firewall; fw4 check && /etc/init.d/firewall reload; fi; }
case "$A" in
 preview|dry-run) prepare_oaf; core preview; echo '===== Smart preview (native software=1 will be converted to managed mode) ====='; "$W/smart" preview || fail "Smart preview failed"; echo '===== RRD audit ====='; "$W/rrd" status || :; exit 0;;
 status|verify) installed; rc=0; core "$A" || rc=1; "$S" status || rc=1; if [ "$A" = verify ]; then "$S" feature-verify || rc=1; "$S" app-verify || rc=1; "$S" quic-verify || rc=1; if [ -x "$OH" ]; then "$OH" verify || rc=1; fi; if [ -f "$OB/integrated147" ]; then time_verify || rc=1; fi; fi; "$R" status || rc=1; "$I" enabled || rc=1; "$I" status || rc=1; for f in /tmp/tgeek-v141-smart.error /tmp/tgeek-v141-rrd.error; do [ ! -s "$f" ] || { cat "$f"; rc=1; }; done; exit "$rc";;
 oaf-status) core oaf-status; [ ! -x "$S" ] || "$S" status; exit 0;;
 compat-status) core compat-status; exit $?;;
 rrd-status) "$W/rrd" status; exit $?;;
 smart-status) installed; "$S" status; exit $?;;
 cut-status|app-status) installed; "$S" app-status; exit $?;;
 app-verify) installed; "$S" app-verify; exit $?;;
 app-stats) installed; "$S" app-stats "${2:-hits}"; exit $?;;
 health) installed; rc=0; echo 'TGEEK Firewall Fix V1.4.8'; "$S" feature-verify || rc=1; "$S" app-stats || rc=1; "$S" quic-stats || rc=1; if [ -x "$OH" ]; then "$OH" verify || rc=1; fi; if [ -f "$OB/integrated147" ]; then time_verify || rc=1; fi; "$I" status || rc=1; echo "health_rc=$rc (feature/LuCI/time/service checks; app and QUIC stats informational; use verify for full nft validation)"; exit "$rc";;
 feature-status|feature-verify|feature-backup|feature-restore|mark-audit) installed; "$S" "$A"; exit $?;;
 quic-status|quic-verify|quic-stats) installed; "$S" "$A"; exit $?;;
 luci-install) installed; lock; prepare_oaf; apply_oaf; exit 0;;
 luci-rollback) installed; lock; rollback_oaf; exit 0;;
 time-status) installed; time_status; exit $?;;
 time-verify) installed; time_verify; exit $?;;
 luci-status|luci-verify|luci-sync) installed; [ -x "$OH" ] || fail 'OAF compatibility not installed'; if [ "$A" = luci-sync ]; then "$S" feature-verify || fail 'Feature backup not verified; refusing automatic catalog sync'; fi; "$OH" "${A#luci-}"; exit $?;;
 rrd-fix) installed; rm -f "$BASE/rrd.disabled"; "$R" fix; exit $?;;
 rrd-rollback) installed; touch "$BASE/rrd.disabled"; "$R" rollback; exit $?;;
 compat-install) installed; rm -f "$BASE/rrd.disabled"; core compat-install; exit $?;;
 compat-rollback) installed; touch "$BASE/rrd.disabled"; "$R" rollback; core compat-rollback; exit $?;;
 sync) installed; rc=0; core sync || rc=1; "$S" sync || rc=1; if [ -x "$OH" ] && "$S" feature-verify >/dev/null 2>&1; then "$OH" sync || rc=1; fi; [ -f "$BASE/rrd.disabled" ] || "$R" fix || rc=1; exit "$rc";;
 test-cut) fail 'Bulk device interruption retired in V1.4.8; use sync and app-status';;
 flow-smart|flow-off|connection-on|connection-off)
    installed; lock; check_native; mode=$(confval mode); con=$(confval connection)
    case "$A" in flow-smart) mode=smart;; flow-off) mode=off;; connection-on) con=1;; connection-off) con=0;; esac
    stop_extra; set_native_off || fail 'Native offload reload failed'; writeconf "$mode" "$con"
    if [ "$con" = 0 ]; then rm -f /tmp/tgeek-smart-v141/active; fi
    "$I" start; log "mode=$mode connection=$con; service resumed"; exit 0;;
 rollback|uninstall)
    installed; lock; check_native; rollback_oaf; stop_extra; "$I" disable; core "$A"
    if [ -f "$BASE/v141.native.original" ]; then restore_native "$(cat "$BASE/v141.native.original")" || fail 'Native software setting restore failed'; fi
    rm -f "$BASE/v141.installed" "$BASE/v143.installed" "$BASE/v144.installed" "$BASE/v145.installed" "$BASE/v146.installed" "$BASE/v147.installed" "$BASE/v1471.installed" "$BASE/v1472.installed" "$BASE/v148.installed" "$I" "$S" "$R" /usr/libexec/tgeek-firewall-worker
    log 'Enhancements removed; RRD remains disabled, use rrd-rollback before uninstall if desired; Docker compatibility rollback separate.'; exit 0;;
 install|upgrade|install-all) ;;
 *) fail 'install | upgrade | install-all | preview | status | verify | version | sync | rrd-status | rrd-fix | rrd-rollback | smart-status | app-status | app-verify | app-stats [all] | health | feature-status | feature-verify | feature-backup | feature-restore | mark-audit | quic-status | quic-verify | quic-stats | luci-install | luci-rollback | luci-status | luci-verify | luci-sync | time-status | time-verify | flow-smart | flow-off | connection-on | connection-off | oaf-status | compat-install | compat-status | compat-rollback | rollback | uninstall';;
esac
for c in fw4 nft uci ubus jsonfilter ip awk sed cmp flock timeout sha256sum; do command -v "$c" >/dev/null || fail "Missing required tool: $c"; done
lock; check_native; fw4 check || fail 'Invalid current firewall'
prepare_oaf
# Read-only core validation first; avoid changing native offload if parsing fails.
core preview || fail 'Time Guard preview failed'
if [ ! -f "$BASE/v143.installed" ] && nft list table inet tgeek_app_precision_v143 >/dev/null 2>&1; then fail 'Unowned precision table already exists'; fi
if [ ! -f "$BASE/v145.installed" ] && nft list table inet tgeek_quic_guard_v145 >/dev/null 2>&1; then fail 'Unowned QUIC table already exists'; fi
"$W/smart" preview || fail 'Precision/QUIC preflight failed; old installation unchanged' 
mkdir -p "$BASE" "$P"
if [ ! -f "$BASE/v141.installed" ]; then
 for f in "$R" "$S" "$I" /usr/libexec/tgeek-firewall-worker; do [ ! -e "$f" ] || fail "Unowned file: $f"; done
fi
prev=$(native flow_offloading)
mode=off; con=1
[ "$prev" != 1 ] || mode=smart
if [ -f "$C" ]; then mode=$(confval mode); con=$(confval connection); [ "$prev" != 1 ] || mode=smart; fi
[ -f "$BASE/v143.installed" ] || con=1
case "$mode" in off|smart) ;; *) fail 'Invalid smart config';; esac
case "$con" in 0|1) ;; *) fail 'Invalid connection config';; esac
B="$BASE/v148-backup-$(date +%Y%m%d-%H%M%S)-$$"; mkdir "$B"
cp -p /etc/config/firewall "$B/firewall"; printf '%s\n' "$prev" > "$B/native"
for f in "$P/install.sh" "$R" "$S" "$I" "$C" /usr/libexec/tgeek-firewall-worker; do [ ! -f "$f" ] || cp -p "$f" "$B/$(basename "$f")"; done
[ -f "$BASE/v141.native.original" ] || cp "$B/native" "$BASE/v141.native.original"
stop_extra
if ! set_native_off; then restore_native "$prev" || :; fail 'Native software offload conversion failed'; fi
# Old core includes transaction rollback for Time Guard. On failure restore native and old extra service.
if ! core install; then
 restore_native "$prev" || log 'WARN: native setting restore failed'
 [ ! -f "$BASE/v141.installed" ] || "$I" start || :
 fail 'Time Guard install failed; inspect core log'
fi
writeconf "$mode" "$con"
cp "$W/rrd" "$R.new"; chmod 755 "$R.new"; mv "$R.new" "$R"
cp "$W/smart" "$S.new"; chmod 755 "$S.new"; mv "$S.new" "$S"
cat > /usr/libexec/tgeek-firewall-worker <<'WORKER'
#!/bin/sh
# TGEEK-FIREWALL-FIX-MANAGED
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
n=0
while :; do
  if /usr/libexec/tgeek-smart-guard sync >/tmp/tgeek-v141-smart.last 2>&1; then rm -f /tmp/tgeek-v141-smart.error; else r=$?; [ "$r" = 75 ] || cp /tmp/tgeek-v141-smart.last /tmp/tgeek-v141-smart.error; fi
  if [ "$n" = 0 ] && [ -x /usr/libexec/tgeek-oaf-compat ] && /usr/libexec/tgeek-smart-guard feature-verify >/dev/null 2>&1; then
    if /usr/libexec/tgeek-oaf-compat sync >/tmp/tgeek-oaf-v146-sync.last 2>&1; then rm -f /tmp/tgeek-oaf-v146-sync.error; else r=$?; [ "$r" = 75 ] || cp /tmp/tgeek-oaf-v146-sync.last /tmp/tgeek-oaf-v146-sync.error; fi
  fi
  if [ "$n" = 0 ] && [ ! -f "$BASE/rrd.disabled" ]; then
    if /usr/libexec/tgeek-rrd-guard fix >/tmp/tgeek-v141-rrd.last 2>&1; then rm -f /tmp/tgeek-v141-rrd.error; else r=$?; [ "$r" = 75 ] || cp /tmp/tgeek-v141-rrd.last /tmp/tgeek-v141-rrd.error; fi
  fi
  n=$(((n+1)%12)); sleep 5
done
WORKER
chmod 755 /usr/libexec/tgeek-firewall-worker
cat > "$I" <<'INIT'
#!/bin/sh /etc/rc.common
# TGEEK-FIREWALL-FIX-MANAGED
START=97
STOP=9
USE_PROCD=1
start_service(){
 procd_open_instance
 procd_set_param command /usr/libexec/tgeek-firewall-worker
 procd_set_param respawn 3600 5 0
 procd_close_instance
}
stop_service(){
 nft delete table inet tgeek_smart_flow_v141 2>/dev/null || :
 nft delete table inet tgeek_oaf_cut_v141 2>/dev/null || :
 nft delete table inet tgeek_app_precision_v143 2>/dev/null || :
 nft delete table inet tgeek_quic_guard_v145 2>/dev/null || :
}
INIT
chmod 755 "$I"
# Save wrapper before launching worker so management always uses correct version.
if [ "$0" != "$P/install.sh" ]; then cp "$0" "$P/install.sh.new"; chmod 755 "$P/install.sh.new"; mv "$P/install.sh.new" "$P/install.sh"; fi
touch "$BASE/v141.installed" "$BASE/v143.installed" "$BASE/v144.installed" "$BASE/v145.installed" "$BASE/v146.installed" "$BASE/v147.installed" "$BASE/v1471.installed" "$BASE/v1472.installed" "$BASE/v148.installed"
# Re-evaluate OAF on first v1.4.6 startup; existing RRD and native backups retained.
rm -f /tmp/tgeek-smart-v141/active /tmp/tgeek-smart-v141/last-cut.nft /tmp/tgeek-smart-v141/precision.layout /tmp/tgeek-smart-v141/precision.policy /tmp/tgeek-smart-v141/precision.status /tmp/tgeek-smart-v141/feature.hash /tmp/tgeek-smart-v141/direct.total /tmp/tgeek-smart-v141/proxy.total /tmp/tgeek-smart-v141/proxy.offset /tmp/tgeek-smart-v141/selected.catalog /tmp/tgeek-smart-v141/quic.layout /tmp/tgeek-smart-v141/quic.status
# Preserve explicit rrd-rollback across upgrade.
# First pass RRD, then background service. Only targeted application handling when active.
rc=0
[ -f "$BASE/rrd.disabled" ] || "$R" fix || rc=2
if [ "$A" = install-all ]; then core compat-install || rc=2; fi
if [ -f /etc/config/appfilter ] && [ ! -e "$BASE/feature-v148/current" ]; then
  # Seed only from a stable, validated snapshot via the runtime two-sample guard.
  log 'Feature Guard will initialize its backup after two valid samples; feature-backup can explicitly approve the current library.'
fi
"$I" enable || fail "Could not enable Firewall Guard; backup=$B"
"$I" start || fail "Could not start Firewall Guard; backup=$B"
apply_oaf
log "Installed. mode=$mode connection=$con; backup=$B"
log 'Run verify and inspect logs; code 2 means compatibility warnings remain.'
exit "$rc"
