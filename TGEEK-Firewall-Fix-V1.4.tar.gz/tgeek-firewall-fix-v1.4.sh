#!/bin/sh
# TGEEK Firewall Fix V1.4 (2026-11-25)
# Retain V1.3 state paths and table names for safe in-place upgrades.
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
SELF=/usr/libexec/tgeek-time-guard
INIT=/etc/init.d/tgeek-time-guard
OLD=/etc/nftables.d/90-tgeek-time-guard.nft
INC=tgeek_time_guard_v13
log(){ echo "[TGEEK V1.4] $*"; }
fail(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Run as root'
mkdir -p "$BASE" /usr/libexec
ACTION=${1:-install}
MANAGED=/usr/share/tgeek-firewall-fix
CLI=/usr/bin/tgeek-firewall-fix
case "$ACTION" in
 version) echo 'TGEEK Firewall Fix V1.4'; exit 0;;
 oaf-status)
    echo '===== OAF ====='
    if [ -d /proc/sys/oaf ]; then
        for k in version enable lan_ifname tcp_rst test_mode user_mode work_mode; do
            [ ! -r /proc/sys/oaf/$k ] || { printf '%s=' "$k"; cat /proc/sys/oaf/$k; }
        done
        uci -q show appfilter.time || :
        uci -q show appfilter.global || :
        ubus -v list appfilter || :
    else echo 'OAF driver not loaded'; fi
    echo '===== FW4 forward ====='; nft list chain inet fw4 forward
    echo '===== Nikki hooks ====='; nft list table inet nikki 2>/dev/null | grep -E 'hook|tproxy|redirect' || :
    echo 'OAF application classification is independent of Time Guard; test the specific app.'
    exit 0;;
 verify) fw4 check; [ -x "$SELF" ] || fail 'Time Guard not installed'; "$SELF" preview; "$SELF" status; "$INIT" enabled || fail 'Boot service disabled'; "$INIT" status; exit $?;;
 install-all) sh "$0" install; sh "$0" compat-install; exit $?;;
esac
W=$(mktemp -d /tmp/tgeek-v13.XXXXXX)
trap 'rm -rf "$W"' EXIT
trap 'exit 1' HUP INT TERM
cat > "$W/guard" <<'TGEEK_TIME_MODULE'
#!/bin/sh
# TGEEK time guard: runtime FW4 rules are authoritative.
set -eu
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/time-guard
TABLE=tgeek_time_guard_v13
SELF=/usr/libexec/tgeek-time-guard
INIT=/etc/init.d/tgeek-time-guard
INC=tgeek_time_guard_v13
OLD=/etc/nftables.d/90-tgeek-time-guard.nft
LOCK=/tmp/tgeek-time-guard.lock
log(){ echo "[TGEEK TIME] $*"; }
fail(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'root required'
for c in nft uci ubus jsonfilter ip awk sed cmp flock; do command -v "$c" >/dev/null || fail "missing $c"; done
mkdir -p "$BASE"
work(){ W=$(mktemp -d /tmp/tgeek-time.XXXXXX); trap 'rm -rf "$W"' EXIT; trap 'exit 1' INT TERM HUP; }
lock(){ exec 9>"$LOCK"; flock -n 9 || exit 75; work; }
# Capture only supported timed MAC WAN-deny rules. Do not reinterpret arbitrary rules.
render(){
  LAN=$(ubus call network.interface.lan status | jsonfilter -e '@.l3_device')
  case "$LAN" in ''|*[!a-zA-Z0-9_.:-]*) fail 'LAN device unavailable or unsupported';; esac
  nft list chain inet fw4 forward > "$W/forward" || return 1
  nft list chain inet fw4 forward_lan > "$W/forward_lan" || return 1
  nft list chain inet fw4 reject_to_wan > "$W/reject" || return 1
  # Extract the actual destination device match from the FW4 zone chain.
  WAN=$(awk '/^[ \t]*oifname .*jump handle_reject/ {s=$0; sub(/^[ \t]*oifname /,"",s); sub(/ counter packets [0-9]+ bytes [0-9]+.*/,"",s); sub(/ jump handle_reject.*/,"",s); print s}' "$W/reject")
  [ -n "$WAN" ] || fail 'WAN device match not found'
  # Flatten simple quoted interface names or a quoted set, validate before reuse.
  printf '%s\n' "$WAN" | tr '{},' '   ' | tr ' ' '\n' | sed '/^$/d;s/^"//;s/"$//' | sort -u > "$W/wan"
  [ -s "$W/wan" ] || fail 'No WAN devices'
  if grep -Eq '[^a-zA-Z0-9_.:+-]' "$W/wan"; then fail 'Unsupported WAN device expression'; fi
  cp "$W/wan" "$W/route"
  if ip link show dev nikki >/dev/null 2>&1; then echo nikki >> "$W/route"; fi
  sort -u "$W/route" > "$W/route.sorted"
  ROUTE=$(awk 'BEGIN{printf "{ "} {if(NR>1)printf ", ";printf "\"%s\"",$0} END{print " }"}' "$W/route.sorted")
  # Only copy literal MAC + time/day, optional simple family/protocol.
  # Unknown match conditions are reported, never silently broadened.
  awk -v skip="$W/skipped" -v lan="$LAN" '
  /meta (hour|day)/ && /jump (reject|drop)_to_wan/ {
    original=$0; s=$0; sub(/^[ \t]+/,"",s); sub(/ counter packets [0-9]+ bytes [0-9]+.*/,"",s);
    sub(/ jump (reject|drop)_to_wan.*/,"",s);
    if (s !~ /ether saddr / || s !~ /meta hour /) {print original >>skip;next}
    family=""; proto="";
    if (s ~ /^iifname /) {prefix="iifname \"" lan "\" "; if(index(s,prefix)!=1){print original >>skip;next}; s=substr(s,length(prefix)+1)}
    if (s ~ /^meta nfproto (ipv4|ipv6) /) {split(s,a," ");family=a[3]; sub(/^meta nfproto (ipv4|ipv6) /,"",s)}
    if (s ~ /^meta l4proto (tcp|udp|ip) /) {split(s,a," ");proto=a[3];sub(/^meta l4proto (tcp|udp|ip) /,"",s)}
    if (s !~ /^ether saddr /) {print original >>skip;next}
    sub(/^ether saddr /,"",s); mac=s;sub(/ .*/,"",mac);sub(/^[^ ]+ /,"",s)
    if (mac !~ /^[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]:[0-9a-fA-F][0-9a-fA-F]$/) {print original >>skip;next}
    if (s !~ /^meta hour "[0-9][0-9]:[0-9][0-9](:[0-9][0-9])?"-"[0-9][0-9]:[0-9][0-9](:[0-9][0-9])?"( meta day ("[A-Za-z]+"|\{ "[A-Za-z]+"(, "[A-Za-z]+")* \}))?$/) {print original >>skip;next}
    if (proto=="ip") {print "WARNING: meta l4proto ip (protocol 0, not IPv4): " original >>skip;next}
    print tolower(mac) "|" family "|" proto "|" s
  }' "$W/forward" "$W/forward_lan" > "$W/rules.raw" || return 1
  sort -u "$W/rules.raw" > "$W/rules"
  if [ -s "$W/skipped" ] && [ "${1:-}" = preview ]; then cat "$W/skipped" >&2; fi
  ip -4 neigh show dev "$LAN" > "$W/neigh4" || return 1
  ip -6 neigh show dev "$LAN" > "$W/neigh6" || return 1
  : > "$W/pre"; : > "$W/fwd"
  while IFS='|' read -r mac family proto schedule; do
    [ -n "$mac" ] || continue
    fam=''; pr=''; [ -z "$family" ] || fam="meta nfproto $family "; [ -z "$proto" ] || pr="meta l4proto $proto "
    printf '        iifname "%s" %s%sether saddr %s fib daddr oifname %s %s counter drop\n' "$LAN" "$fam" "$pr" "$mac" "$ROUTE" "$schedule" >> "$W/pre"
    printf '        iifname "%s" oifname %s %s%sether saddr %s %s counter drop\n' "$LAN" "$ROUTE" "$fam" "$pr" "$mac" "$schedule" >> "$W/fwd"
    for v in 4 6; do
      [ "$v" != 4 ] || [ "$family" != ipv6 ] || continue
      [ "$v" != 6 ] || [ "$family" != ipv4 ] || continue
      p=ip; [ "$v" = 4 ] || p=ip6
      awk -v m="$mac" 'tolower($0) ~ ("lladdr " m " ") && $0 !~ /FAILED|INCOMPLETE/ {print $1}' "$W/neigh$v" | sort -u > "$W/addresses"
      while IFS= read -r addr; do
        [ -n "$addr" ] || continue
        case "$addr" in *[!0-9a-fA-F:.]*) continue;; esac
        # Link-local IPv6 is not WAN traffic.
        case "$addr" in fe80:*|FE80:*) continue;; esac
        printf '        iifname %s oifname "%s" %s%s daddr %s %s counter drop\n' "$ROUTE" "$LAN" "$pr" "$p" "$addr" "$schedule" >> "$W/fwd"
      done < "$W/addresses"
    done
  done < "$W/rules"
  {
    echo "table inet $TABLE {"
    echo '    chain prerouting { type filter hook prerouting priority -160; policy accept;'
    cat "$W/pre"; echo '    }'
    echo '    chain forward { type filter hook forward priority -10; policy accept;'
    cat "$W/fwd"; echo '    }'
    echo '}'
  } > "$W/table"
}
apply(){
  for opt in flow_offloading flow_offloading_hw; do
    [ "$(uci -q get firewall.@defaults[0].$opt || :)" != 1 ] || fail "Disable $opt; guard may be bypassed"
  done
  nft list flowtables > "$W/flowtables" || return 1
  if grep -q "flowtable " "$W/flowtables"; then fail "Active flowtable: disable offloading"; fi
  render || return 1
  # Preserve counters when nothing has changed. Runtime table may have disappeared after flush.
  if [ -s "$W/skipped" ]; then
    cmp -s "$W/skipped" /tmp/tgeek-time-guard.skipped || cp "$W/skipped" /tmp/tgeek-time-guard.skipped
  else rm -f /tmp/tgeek-time-guard.skipped; fi
  if [ -f /tmp/tgeek-time-guard.applied ] && cmp -s "$W/table" /tmp/tgeek-time-guard.applied && nft list table inet "$TABLE" >/dev/null 2>&1; then return 0; fi
  : > "$W/transaction"
  if nft list table inet "$TABLE" >/dev/null 2>&1; then echo "delete table inet $TABLE" >> "$W/transaction"; fi
  cat "$W/table" >> "$W/transaction"
  nft -c -f "$W/transaction" || return 1
  nft -f "$W/transaction" || return 1
  cp "$W/table" /tmp/tgeek-time-guard.applied
  cp "$W/rules" /tmp/tgeek-time-guard.active-rules
  log "Applied $(wc -l < "$W/rules") timed MAC rules (IPv4/IPv6 where family permits)."
}
case "${1:-status}" in
 preview) lock; render preview; : > "$W/check"; if nft list table inet "$TABLE" >/dev/null 2>&1; then echo "delete table inet $TABLE" >> "$W/check"; fi; cat "$W/table" >> "$W/check"; nft -c -f "$W/check"; cat "$W/rules"; cat "$W/table"; [ ! -s "$W/skipped" ] || log 'WARNING: unsupported rules listed above';;
 sync) lock; apply;;
 loop) while :; do if "$SELF" sync >/tmp/tgeek-time-guard.last 2>&1; then rm -f /tmp/tgeek-time-guard.error; else rc=$?; [ "$rc" = 75 ] || cp /tmp/tgeek-time-guard.last /tmp/tgeek-time-guard.error; fi; sleep 15; done;;
 status) nft list table inet "$TABLE"; [ ! -f /tmp/tgeek-time-guard.error ] || { cat /tmp/tgeek-time-guard.error >&2; exit 1; }; [ ! -f /tmp/tgeek-time-guard.skipped ] || cat /tmp/tgeek-time-guard.skipped; [ ! -f /tmp/tgeek-time-guard.last ] || cat /tmp/tgeek-time-guard.last;;
 remove-runtime) lock; nft delete table inet "$TABLE" 2>/dev/null || :; rm -f /tmp/tgeek-time-guard.applied;;
 *) fail 'preview | sync | loop | status | remove-runtime';;
esac
TGEEK_TIME_MODULE
cat > "$W/compat" <<'TGEEK_COMPAT_MODULE'
#!/bin/sh
# TGEEK Firewall Fix V1.3 - optional Docker and wrtbwmon modules
set -u
umask 077
BASE=/root/tgeek-firewall-fix-v1.3
log(){ printf '[TGEEK] %s\n' "$*"; }
die(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || die 'Run as root'
command -v fw4 >/dev/null || die 'firewall4 missing'
command -v uci >/dev/null || die 'uci missing'
ACTION=${1:-install}
case "$ACTION" in install|fix|status|check|rollback) ;; *) die 'Usage: install | status | rollback';; esac
mkdir -p "$BASE" || exit 1
LOCK=/tmp/tgeek-firewall-fix-v1.3.lock
mkdir "$LOCK" 2>/dev/null || die 'Another execution active'
trap 'rmdir "$LOCK" 2>/dev/null || :' EXIT
trap 'exit 1' HUP INT TERM
cat > "$BASE/rrd.sh" <<'TGEEK_RRD_MODULE'
#!/bin/sh
# TGEEK firewall compatibility cleanup v1.1
set -eu
BASE=/root/tgeek-firewall-fix-v1.3/rrd-backups
ACTION=${1:-fix}
umask 077
log() { printf '[TGEEK] %s\n' "$*"; }
fail() { log "ERROR: $*"; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Run as root'
mkdir -p "$BASE"
case "$ACTION" in
install|fix) ACTION=fix;;
status|check) ACTION=status;;
rollback) ;;
*) fail 'Usage: sh script [install|fix|status|rollback]';;
esac
for c in iptables-save ip6tables-save fw4; do command -v "$c" >/dev/null || fail "Missing $c"; done
report() {
    V4=$(iptables-save) || fail 'Cannot read IPv4 rules'
    V6=$(ip6tables-save) || fail 'Cannot read IPv6 rules'
    printf '%s\n' "$V4" "$V6" | awk '/^-A / {n[$2]++} END {for (c in n) print n[c],c}'
    if printf '%s\n' "$V4" "$V6" | grep -q '^-A '; then
        log 'WARN: iptables rules remain; inspect chain counts above.'
    else
        log 'PASS: No IPv4/IPv6 iptables append rules remain.'
    fi
    if command -v uci >/dev/null; then
        uci -q show dockerd.globals | grep -E 'ip6?tables=' || :
    fi
    fw4 check || fail 'Firewall validation failed'
}
if [ "$ACTION" = status ]; then report; exit 0; fi
if [ ! -x /etc/init.d/wrtbwmon ]; then
    [ "$ACTION" != rollback ] || fail 'wrtbwmon absent; service rollback not applicable'
    log 'SKIP: wrtbwmon not installed; no service or rules changed.'
    report
    if printf '%s\n' "$V4" "$V6" | grep -q '^-A '; then
        log 'No automatic deletion: rule owner must be identified on this device.'
        exit 2
    fi
    exit 0
fi
case "$ACTION" in
rollback)
    [ -f "$BASE/latest" ] || fail 'No backup found'
    B=$(cat "$BASE/latest")
    [ -d "$B" ] || fail 'Backup missing'
    if [ "$(cat "$B/enabled")" = 1 ]; then /etc/init.d/wrtbwmon enable; else /etc/init.d/wrtbwmon disable; fi
    for f in usage.db usage.46.db usage.6.db; do if [ -f "$B/$f" ] && [ ! -e "/tmp/$f" ]; then cp -p "$B/$f" "/tmp/$f"; fi; done
    if [ "$(cat "$B/running")" = 1 ]; then /etc/init.d/wrtbwmon start; fi
    log 'Original wrtbwmon service state restored; live counters may restart.'
    exit 0;;
fix) ;;
*) fail 'Invalid action';;
esac
for c in iptables ip6tables iptables-save ip6tables-save fw4; do command -v "$c" >/dev/null || fail "Missing $c"; done
fw4 check || fail 'Existing firewall configuration invalid'
B="$BASE/$(date +%Y%m%d-%H%M%S)-$$"
mkdir "$B"
iptables-save -c > "$B/iptables.txt"
ip6tables-save -c > "$B/ip6tables.txt"
for f in /tmp/usage.db /tmp/usage.46.db /tmp/usage.6.db /etc/wrtbwmon.user /etc/config/wrtbwmon; do [ ! -f "$f" ] || cp -p "$f" "$B/"; done
if /etc/init.d/wrtbwmon enabled; then echo 1 > "$B/enabled"; else echo 0 > "$B/enabled"; fi
if pidof wrtbwmon >/dev/null 2>&1 || ps w | grep -q '[/]usr/sbin/wrtbwmon -'; then echo 1 > "$B/running"; else echo 0 > "$B/running"; fi
# Preserve the original active-state backup across repeated runs.
if [ ! -f "$BASE/latest" ] || [ "$(cat "$B/running")" = 1 ] || [ "$(cat "$B/enabled")" = 1 ]; then printf '%s\n' "$B" > "$BASE/latest"; fi
log "Backup: $B"
/etc/init.d/wrtbwmon stop || fail 'Could not stop wrtbwmon'
/etc/init.d/wrtbwmon disable || fail 'Could not disable wrtbwmon'
sleep 2
if pidof wrtbwmon >/dev/null 2>&1 || ps w | grep -q '[/]usr/sbin/wrtbwmon -'; then fail 'wrtbwmon still running; no manual rules removed'; fi
for IPT in iptables ip6tables; do
    for CHAIN in INPUT FORWARD OUTPUT; do
        TARGET="RRDIPT_$CHAIN"
        while "$IPT" -w 5 -t mangle -C "$CHAIN" -j "$TARGET" 2>/dev/null; do
            "$IPT" -w 5 -t mangle -D "$CHAIN" -j "$TARGET" || fail "Cannot detach $TARGET"
        done
        if "$IPT" -w 5 -t mangle -S "$TARGET" >/dev/null 2>&1; then
            "$IPT" -w 5 -t mangle -F "$TARGET" || fail "Cannot flush $TARGET"
            "$IPT" -w 5 -t mangle -X "$TARGET" || fail "Cannot delete $TARGET"
        fi
    done
done
iptables-save > "$B/after-v4.txt"
ip6tables-save > "$B/after-v6.txt"
if grep -q RRDIPT "$B/after-v4.txt" "$B/after-v6.txt"; then fail 'RRDIPT rules remain'; fi
fw4 check || fail 'Firewall validation failed'
if grep -h '^-A ' "$B/after-v4.txt" "$B/after-v6.txt"; then log 'RRDIPT removed, but other iptables rules remain; LuCI warning may persist.'; else log 'PASS: No IPv4/IPv6 iptables append rules remain.'; fi
if command -v docker >/dev/null; then docker ps || log 'Docker status unavailable'; fi
log 'Done. Refresh LuCI. Old traffic monitor is disabled; no router or Docker restart.'
log "Rollback: sh $0 rollback"
if grep -q '^-A ' "$B/after-v4.txt" "$B/after-v6.txt"; then exit 2; fi

TGEEK_RRD_MODULE
cat > "$BASE/docker.sh" <<'TGEEK_DOCKER_MODULE'
#!/bin/sh
# TGEEK Firewall Fix 1.2 - OpenWrt fw4 / Docker host-only migration
set -eu
set -f
umask 077
BASE=/root/tgeek-firewall-fix-v1.3/docker-backups
LOCK=/tmp/tgeek-firewall-fix-v1.2.lock
INIT=/etc/init.d/dockerd
log(){ printf '[TGEEK] %s\n' "$*"; }
die(){ log "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || die 'Run as root.'
for c in uci fw4 nft docker iptables ip6tables iptables-save ip6tables-save jsonfilter; do command -v "$c" >/dev/null || die "Missing $c"; done
[ -x "$INIT" ] || die 'dockerd service not found.'
mkdir "$LOCK" 2>/dev/null || die 'Another execution is active (check lock).'
CHANGED=0
B=''
wait_docker(){ i=0; until docker info >/dev/null 2>&1; do i=$((i+1)); [ "$i" -lt 45 ] || return 1; sleep 1; done; }
start_previous(){ while IFS= read -r id; do [ -n "$id" ] || continue; docker start "$id" >/dev/null || return 1; done < "$B/running"; }
restore(){
  log "Restoring $B (firewall and dockerd config; later edits to these files will be overwritten)."
  "$INIT" stop || return 1
  uci -q revert firewall || :; uci -q revert dockerd || :
  cp -p "$B/firewall" /etc/config/firewall || return 1
  cp -p "$B/dockerd" /etc/config/dockerd || return 1
  fw4 check && /etc/init.d/firewall reload || return 1
  "$INIT" start && wait_docker && start_previous || return 1
  log 'Rollback complete.'
}
finish(){ rc=$?; trap - EXIT HUP INT TERM; if [ "$CHANGED" = 1 ]; then log 'Migration failed; attempting rollback.'; restore || log 'ERROR: automatic rollback failed; use backup path above.'; fi; rmdir "$LOCK" 2>/dev/null || :; exit "$rc"; }
trap finish EXIT
trap 'exit 1' HUP INT TERM
status(){
  uci show dockerd.globals | grep -E 'iptables|ip6tables' || :
  if [ -f /tmp/dockerd/daemon.json ]; then for key in iptables ip6tables; do printf '%s=' "$key"; jsonfilter -i /tmp/dockerd/daemon.json -e "@.$key" || :; done; fi
  uci -q show firewall.docker || :
  docker ps -a || :
  for s in iptables-save ip6tables-save; do log "$s rule counts:"; "$s" | awk '/^-A /{n[$2]++} END{for(k in n)print n[k],k}'; done
  fw4 check
}
case "${1:-install}" in
 status) status; exit;;
 rollback) [ -s "$BASE/latest" ] || die 'No backup'; B=$(cat "$BASE/latest"); [ -f "$B/firewall" ] && [ -f "$B/dockerd" ] || die 'Invalid backup'; restore || die 'Rollback failed'; exit;;
 install) ;;
 *) die 'Usage: install | status | rollback';;
esac
# Scope: host/none containers only, standard empty docker0 bridge. No generic port migration.
[ -z "$(uci changes firewall)$(uci changes dockerd)" ] || die 'Commit or revert pending UCI changes first.'
[ -z "$(uci -q get dockerd.globals.alt_config_file || :)" ] || die 'Custom daemon configuration requires manual migration.'
fw4 check || die 'Existing firewall invalid.'
wait_docker || die 'Docker unavailable.'
[ "$(uci -q get firewall.docker.name || :)" = docker ] || die 'Expected existing firewall.docker zone.'
[ "$(docker network inspect -f '{{index .Options "com.docker.network.bridge.name"}}' bridge)" = docker0 ] || die 'Nonstandard default bridge.'
[ "$(docker network inspect -f '{{range .IPAM.Config}}{{.Subnet}}{{end}}' bridge)" = 172.17.0.0/16 ] || die 'Nonstandard subnet.'
[ "$(docker network inspect -f '{{.EnableIPv6}}' bridge)" = false ] || die 'IPv6-enabled bridge requires separate design.'
for n in $(docker network ls --format '{{.Name}}'); do case "$n" in bridge|host|none) ;; *) die "Custom network $n requires manual migration";; esac; done
for id in $(docker ps -aq); do
  mode=$(docker inspect -f '{{.HostConfig.NetworkMode}}' "$id")
  case "$mode" in host|none) ;; *) die "Container $id uses $mode; migrate its ports and networks first";; esac
done
# Require WAN masquerade and a restrictive WAN policy; do not change WAN settings.
WAN=''; for z in $(uci show firewall | sed -n 's/^firewall\.\([^=]*\)=zone$/\1/p'); do
  if [ "$(uci -q get "firewall.$z.name" || :)" = wan ]; then WAN=$z; fi
done
[ -n "$WAN" ] || die 'WAN zone absent.'
[ "$(uci -q get "firewall.$WAN.masq" || :)" = 1 ] || die 'WAN masquerade is not enabled.'
case "$(uci -q get "firewall.$WAN.input" || :)" in REJECT|DROP) ;; *) die 'WAN input is not restrictive.';; esac
case "$(uci -q get "firewall.$WAN.forward" || :)" in REJECT|DROP) ;; *) die 'WAN forwarding is not restrictive.';; esac
# Generate a deletion plan for known Docker 27.3 empty-default-bridge rules only.
# Unknown/custom rules mentioning Docker cause a preflight failure, not deletion.
plan(){
 awk '
 /^\*/ {t=substr($0,2)}
 /^:FORWARD DROP/ && t=="filter" {bad=1; print "FORWARD policy DROP requires review" > "/dev/stderr"}
 /^-A / {
   if ($0 !~ /DOCKER|docker0/ && $0 !~ /172\.17\.0\.0\/16/) next
   ok=0
   if(t=="nat" && ($0=="-A PREROUTING -m addrtype --dst-type LOCAL -j DOCKER" || $0=="-A OUTPUT ! -d 127.0.0.0/8 -m addrtype --dst-type LOCAL -j DOCKER" || $0=="-A POSTROUTING -s 172.17.0.0/16 ! -o docker0 -j MASQUERADE" || $0=="-A DOCKER -i docker0 -j RETURN")) ok=1
   if(t=="filter" && ($0=="-A FORWARD -j DOCKER-USER" || $0=="-A FORWARD -j DOCKER-ISOLATION-STAGE-1" || $0=="-A FORWARD -o docker0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT" || $0=="-A FORWARD -o docker0 -j DOCKER" || $0=="-A FORWARD -i docker0 ! -o docker0 -j ACCEPT" || $0=="-A FORWARD -i docker0 -o docker0 -j ACCEPT" || $0=="-A DOCKER-ISOLATION-STAGE-1 -i docker0 ! -o docker0 -j DOCKER-ISOLATION-STAGE-2" || $0=="-A DOCKER-ISOLATION-STAGE-1 -j RETURN" || $0=="-A DOCKER-ISOLATION-STAGE-2 -o docker0 -j DROP" || $0=="-A DOCKER-ISOLATION-STAGE-2 -j RETURN" || $0=="-A DOCKER-USER -j RETURN" || $0 ~ /^-A DOCKER-USER -i [a-zA-Z0-9_.:-]+ -o docker0 -j REJECT( --reject-with icmp-port-unreachable)?$/)) ok=1
   if(!ok){bad=1;print "Unrecognized Docker-related rule: " $0 > "/dev/stderr"} else {sub(/^-A /,"-D "); print t, $0}
 }
 END{exit bad?1:0}' "$1" > "$2"
}
mkdir -p "$BASE"
B="$BASE/$(date +%Y%m%d-%H%M%S)-$$"; mkdir "$B"
cp -p /etc/config/firewall "$B/firewall"; cp -p /etc/config/dockerd "$B/dockerd"
docker ps -q > "$B/running"
iptables-save > "$B/iptables"; ip6tables-save > "$B/ip6tables"
nft list ruleset > "$B/nftables"
plan "$B/iptables" "$B/plan" || die 'Unsafe to clean automatically.'
# This device has no Docker IPv6 chains. Refuse unexpected IPv6 Docker rules.
if grep -Eq 'DOCKER|docker0' "$B/ip6tables"; then die 'Unexpected IPv6 Docker rules; manual review required.'; fi
printf '%s\n' "$B" > "$BASE/latest"
log "Backup: $B"
CHANGED=1
# Keep existing Docker network association. Add explicit device binding.
uci -q del_list firewall.docker.device=docker0 || :
uci add_list firewall.docker.device=docker0
# Dedicated prefix for future explicitly named Docker bridges; never match br-lan.
uci -q del_list firewall.docker.device=tgd-+ || :
uci add_list firewall.docker.device=tgd-+
uci set firewall.docker.input=REJECT
uci set firewall.docker.output=ACCEPT
uci set firewall.docker.forward=REJECT
# Permit DNS to router; preserve existing explicit LAN/WAN rules.
uci set firewall.tgeek_docker_dns=rule
uci set firewall.tgeek_docker_dns.name='TGEEK-Docker-DNS'
uci set firewall.tgeek_docker_dns.src=docker
uci set firewall.tgeek_docker_dns.proto='tcp udp'
uci set firewall.tgeek_docker_dns.dest_port=53
uci set firewall.tgeek_docker_dns.target=ACCEPT
uci set firewall.tgeek_docker_wan=forwarding
uci set firewall.tgeek_docker_wan.src=docker
uci set firewall.tgeek_docker_wan.dest=wan
uci commit firewall
fw4 check
/etc/init.d/firewall reload
log 'Restarting Docker; running containers will be restored.'
"$INIT" stop
# Remove only known leftover rules, if Docker did not remove them on stop.
iptables-save > "$B/after-stop"
plan "$B/after-stop" "$B/cleanup" || die 'Unexpected rule after stopping Docker.'
while IFS= read -r line; do [ -n "$line" ] || continue; set -- $line; table=$1; shift; iptables -t "$table" "$@" || die 'Targeted cleanup failed'; done < "$B/cleanup"
for t in filter nat; do
  for c in DOCKER DOCKER-USER DOCKER-ISOLATION-STAGE-1 DOCKER-ISOLATION-STAGE-2; do
    if iptables -t "$t" -S "$c" >/dev/null 2>&1; then iptables -t "$t" -X "$c" || die "Nonempty or referenced chain $t/$c"; fi
  done
done
uci set dockerd.globals.iptables=0
uci set dockerd.globals.ip6tables=0
uci commit dockerd
"$INIT" start
wait_docker || die 'Docker did not restart.'
start_previous || die 'Previous running container could not start.'
for key in iptables ip6tables; do [ "$(jsonfilter -i /tmp/dockerd/daemon.json -e "@.$key")" = false ] || die "Effective $key not false"; done
/etc/init.d/firewall reload
fw4 check
nft list chain inet fw4 forward_docker | grep -q accept_to_wan || die 'Docker WAN forwarding missing.'
iptables-save > "$B/final-ipv4"; ip6tables-save > "$B/final-ipv6"
if grep -Eq 'DOCKER|docker0|172\.17\.0\.0/16' "$B/final-ipv4" "$B/final-ipv6"; then die 'Docker-related rules remain.'; fi
while IFS= read -r id; do [ -z "$id" ] || [ "$(docker inspect -f '{{.State.Running}}' "$id")" = true ] || die "Container $id not running"; done < "$B/running"
CHANGED=0
if grep -q '^-A ' "$B/final-ipv4" "$B/final-ipv6"; then log 'WARN: other iptables rules remain; not modified.'; else log 'PASS: no iptables append rules remain.'; fi
log 'PASS: Docker firewall disabled; fw4 owns default bridge forwarding/NAT.'
log 'For new custom bridges: name them tgd-* or explicitly add device to firewall zone; publish ports via LuCI DNAT or host INPUT rules.'
docker ps

TGEEK_DOCKER_MODULE

report(){
  result=0
  for cmd in iptables-save ip6tables-save; do
    if ! command -v "$cmd" >/dev/null; then log "SKIP: $cmd unavailable; cannot verify this family"; result=2; continue; fi
    out=$("$cmd") || { log "ERROR: $cmd failed"; result=2; continue; }
    if printf '%s\n' "$out" | grep -q '^-A '; then
      log "WARN: $cmd rules remain"; printf '%s\n' "$out" | awk '/^-A /{n[$2]++} END{for(k in n)print n[k],k}'; result=2
    else log "PASS: $cmd has no append rules"; fi
  done
  if command -v docker >/dev/null; then
    uci -q show dockerd.globals | grep -E 'ip6?tables=' || :
    docker ps || result=2
  else log 'SKIP: Docker CLI absent'; fi
  fw4 check || return 1
  return "$result"
}
if [ "$ACTION" = status ] || [ "$ACTION" = check ]; then report; exit $?; fi
if [ "$ACTION" = rollback ]; then
  rc=0
  for module in rrd docker; do
    if [ -f "$BASE/$module.applied" ]; then
      if sh "$BASE/$module.sh" rollback; then rm -f "$BASE/$module.applied"; else rc=1; fi
    fi
  done
  log 'Rollback restores module configuration snapshots; Docker rollback overwrites subsequent firewall edits.'
  exit "$rc"
fi
fw4 check || die 'Existing firewall invalid'
rc=0
if command -v docker >/dev/null && [ -x /etc/init.d/dockerd ]; then
  if [ "$(uci -q get dockerd.globals.iptables)" = 0 ] && [ "$(uci -q get dockerd.globals.ip6tables)" = 0 ] && command -v jsonfilter >/dev/null && [ "$(jsonfilter -i /tmp/dockerd/daemon.json -e '@.iptables' 2>/dev/null)" = false ] && [ "$(jsonfilter -i /tmp/dockerd/daemon.json -e '@.ip6tables' 2>/dev/null)" = false ]; then
    log 'SKIP: Docker automatic firewall already disabled; existing migration not modified.'
  elif [ -f "$BASE/docker.applied" ]; then
    log 'WARN: Docker previously migrated; rollback before a new migration.'; rc=2
  else
    if sh "$BASE/docker.sh" install; then touch "$BASE/docker.applied"; else log 'WARN: Docker migration refused or failed; inspect module output.'; rc=2; fi
  fi
elif command -v docker >/dev/null || [ -x /etc/init.d/dockerd ]; then
  log 'WARN: incomplete Docker installation; no Docker changes.'; rc=2
else log 'SKIP: Docker not installed'; fi
if [ -x /etc/init.d/wrtbwmon ]; then
  if [ -f "$BASE/rrd.applied" ]; then log 'SKIP: wrtbwmon already processed; rollback before repeating.'
  else
    # Module may return 2 when unrelated rules remain, after successful cleanup.
    sh "$BASE/rrd.sh" install; r=$?
    if [ "$r" = 0 ] || [ "$r" = 2 ]; then touch "$BASE/rrd.applied"; else log 'WARN: wrtbwmon cleanup failed; inspect backup and service state.'; [ ! -s "$BASE/rrd-backups/latest" ] || touch "$BASE/rrd.applied"; rc=2; fi
  fi
else log 'SKIP: wrtbwmon not installed; no RRD rules removed'; fi
report; r=$?
[ "$r" = 0 ] || rc=$r
log "Finished (code $rc). No router reboot. Unknown rules are not removed."
exit "$rc"
TGEEK_COMPAT_MODULE
chmod 755 "$W/guard" "$W/compat"
case "$ACTION" in
 compat-install) sh "$W/compat" install; exit $?;;
 compat-status) sh "$W/compat" status; exit $?;;
 compat-rollback) sh "$W/compat" rollback; exit $?;;
 preview|dry-run) "$W/guard" preview; exit $?;;
 status) [ -x "$SELF" ] || fail 'Time Guard not installed'; "$SELF" status; exit $?;;
 sync) [ -x "$SELF" ] || fail 'Time Guard not installed'; "$SELF" sync; exit $?;;
 install|upgrade|rollback|uninstall) ;;
 *) fail 'install | install-all | upgrade | preview | status | sync | verify | version | oaf-status | rollback | uninstall | compat-install | compat-status | compat-rollback';;
esac
[ -z "$(uci changes firewall)" ] || fail 'Save or revert pending firewall edits in LuCI first'
MLOCK=/tmp/tgeek-v13-install.lock
mkdir "$MLOCK" 2>/dev/null || fail 'Another install active'
trap 'rm -rf "$W"; rmdir "$MLOCK" 2>/dev/null || :' EXIT
if [ "$ACTION" = rollback ] || [ "$ACTION" = uninstall ]; then
    [ -f "$BASE/installed" ] || fail 'No managed installation'
    [ ! -x "$INIT" ] || { "$INIT" stop || :; "$INIT" disable || :; }
    uci -q delete "firewall.$INC" || :
    uci commit firewall
    if [ -f "$BASE/original-legacy.nft" ]; then cp -p "$BASE/original-legacy.nft" "$OLD"; fi
    fw4 check && /etc/init.d/firewall reload || fail 'Rollback reload failed; inspect fw4 check'
    "$SELF" remove-runtime || fail 'Runtime cleanup failed; retry rollback'
    rm -f "$SELF" "$INIT" "$BASE/installed"
    log 'Time Guard removed; original LuCI rules and Docker configuration retained. Compatibility rollback is separate.'
    exit 0
fi
# Do not overwrite unowned files or an unrelated include.
if [ ! -f "$BASE/installed" ]; then
    [ ! -e "$SELF" ] && [ ! -e "$INIT" ] || fail 'Existing unowned Time Guard files'
    [ -z "$(uci -q get firewall.$INC || :)" ] || fail 'Include name already exists'
fi
fw4 check || fail 'Existing firewall invalid'
"$W/guard" preview > "$W/preview" || fail 'Cannot render rules'
cat "$W/preview"
# Refuse active flow offload: established offloaded flows can skip hooks.
for opt in flow_offloading flow_offloading_hw; do
    [ "$(uci -q get firewall.@defaults[0].$opt || :)" != 1 ] || fail "Disable $opt in LuCI before installing"
done
if nft list flowtables | grep -q 'flowtable '; then fail 'Active flowtable detected'; fi
B="$BASE/backup-$(date +%Y%m%d-%H%M%S)-$$"
mkdir "$B"
cp -p /etc/config/firewall "$B/firewall"
for f in "$SELF" "$INIT" "$OLD"; do [ ! -f "$f" ] || cp -p "$f" "$B/$(basename "$f")"; done
if [ -f "$OLD" ]; then
    # Only replace the earlier TGEEK sample, not other custom firewall content.
    awk 'NF && $0 !~ /^[ \t]*#/ {if ($0 ~ /^chain tgeek_time_forward \{/ || $0 ~ /^[ \t]*type filter hook forward priority -10; policy accept;/ || $0 ~ /^[ \t]*iifname .*meta hour .*counter drop[ \t]*$/ || $0 ~ /^[ \t]*}[ \t]*$/) next; bad=1} END{exit bad}' "$OLD" || fail 'Legacy file contains unknown rules; inspect manually'
    grep -q '^chain tgeek_time_forward {' "$OLD" || fail 'Legacy file not recognized'
fi
rollback_install(){
    log "Install failed; restoring $B"
    [ ! -x "$INIT" ] || { "$INIT" stop || :; "$INIT" disable || :; }
    uci -q revert firewall || :
    cp -p "$B/firewall" /etc/config/firewall
    if [ -f "$B/$(basename "$OLD")" ]; then cp -p "$B/$(basename "$OLD")" "$OLD"; fi
    if [ -f "$B/$(basename "$SELF")" ]; then cp -p "$B/$(basename "$SELF")" "$SELF"; else rm -f "$SELF"; fi
    if [ -f "$B/$(basename "$INIT")" ]; then cp -p "$B/$(basename "$INIT")" "$INIT"; else rm -f "$INIT"; fi
    fw4 check && /etc/init.d/firewall reload || log 'ERROR: restore reload failed'
    if [ -f "$BASE/installed" ]; then "$INIT" enable && "$INIT" start || :; else nft delete table inet tgeek_time_guard_v13 2>/dev/null || :; fi
}
# Every failure after this point triggers rollback, including interrupted install.
DONE=0
trap 'r=$?; trap - EXIT; if [ "$DONE" = 0 ]; then rollback_install; fi; rm -rf "$W"; rmdir "$MLOCK" 2>/dev/null || :; exit "$r"' EXIT
[ ! -x "$INIT" ] || "$INIT" stop
cp "$W/guard" "$SELF"; chmod 755 "$SELF"
cat > "$INIT" <<'TGEEK_PROCD'
#!/bin/sh /etc/rc.common
START=96
STOP=10
USE_PROCD=1
start_service(){
    procd_open_instance
    procd_set_param command /usr/libexec/tgeek-time-guard loop
    procd_set_param respawn 3600 5 0
    procd_close_instance
}
TGEEK_PROCD
chmod 755 "$INIT"
"$SELF" sync
uci set "firewall.$INC=include"
uci set "firewall.$INC.type=script"
uci set "firewall.$INC.path=$SELF"
# fw4 invokes script with no arguments, so use dedicated entry wrapper instead.
cat > "$BASE/reload.sh" <<'TGEEK_RELOAD'
#!/bin/sh
/usr/libexec/tgeek-time-guard sync || logger -t tgeek-time-guard 'Reload sync deferred to service'
TGEEK_RELOAD
chmod 755 "$BASE/reload.sh"
uci set "firewall.$INC.path=$BASE/reload.sh"
uci set "firewall.$INC.fw4_compatible=1"
uci commit firewall
if [ -f "$OLD" ]; then
    [ -f "$BASE/original-legacy.nft" ] || cp -p "$OLD" "$BASE/original-legacy.nft"
    rm -f "$OLD"
fi
fw4 check
/etc/init.d/firewall reload
"$SELF" sync
"$INIT" enable
"$INIT" start
# Remove only previous named test table after successful replacement.
if nft list table inet tgeek_time_guard >/dev/null 2>&1; then nft delete table inet tgeek_time_guard; fi
touch "$BASE/installed"
DONE=1
mkdir -p "$MANAGED"
if [ "$0" != "$MANAGED/install.sh" ]; then
    cp "$0" "$MANAGED/install.sh.new"
    chmod 755 "$MANAGED/install.sh.new"
    mv -f "$MANAGED/install.sh.new" "$MANAGED/install.sh"
fi
if [ ! -e "$CLI" ] || grep -q 'TGEEK-FIREWALL-FIX-MANAGED' "$CLI"; then
    cat > "$CLI" <<'TGEEK_CLI'
#!/bin/sh
# TGEEK-FIREWALL-FIX-MANAGED
exec /usr/share/tgeek-firewall-fix/install.sh "$@"
TGEEK_CLI
    chmod 755 "$CLI"
else log "WARN: $CLI already exists; use $MANAGED/install.sh"; fi
log "PASS: Time Guard installed. Backup: $B"
"$SELF" status
